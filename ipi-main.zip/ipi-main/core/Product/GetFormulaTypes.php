<?php

namespace IPI\Core\Product;

use App\Models\FormulaType as EloquentFormulaType;
use Illuminate\Database\Eloquent\Collection as EloquentCollection;
use Illuminate\Support\Collection as SupportCollection;
use IPI\Core\DTO\IndexFilter;
use IPI\Core\Entities\FormulaType;
use IPI\Core\Filters\EloquentIndexQueryBuilder;
use IPI\Core\General\EloquentResponseMetaBuilder;

class GetFormulaTypes
{
    public function getFormulaTypes(IndexFilter $data): array
    {
        $eloquentFormulaTypeQuery = EloquentFormulaType::query();
        $queryBuilder = new EloquentIndexQueryBuilder($eloquentFormulaTypeQuery);
        $eloquentQueryBuilder = $queryBuilder->execute($data, 'formula_types');

        if ($data->paginateResult) {
            $formulas = $eloquentQueryBuilder->paginate($data->perPage);
            $responseMetaBuilder = new EloquentResponseMetaBuilder($formulas);

            return [
                $this->prepareFormulaTypes($formulas->getCollection()),
                $responseMetaBuilder->execute()
            ];
        }

        $formulas = $eloquentQueryBuilder->get();
        $formulas = $this->prepareFormulaTypes($formulas);

        return [$formulas, []];
    }

    private function prepareFormulaTypes(EloquentCollection|SupportCollection $collection): array
    {
        $formulaTypes = [];

        foreach ($collection as $item) {
            $formulaType = new FormulaType($item->id);
            $formulaType->setFromArray($item->toArray());

            $formulaTypes[] = $formulaType;
        }

        return $formulaTypes;
    }
}
