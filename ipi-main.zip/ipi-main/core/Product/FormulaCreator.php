<?php

namespace IPI\Core\Product;

use App\Models\Checkpoint as EloquentCheckpoint;
use App\Models\Formula as EloquentFormula;
use App\Models\FormulaType;
use App\Models\IngredientList as EloquentIngredientList;
use App\Models\IngredientListItem;
use App\Models\Module;
use Illuminate\Support\Facades\DB;
use IPI\Core\DTO\CreateFormulaCheckpointData;
use IPI\Core\DTO\CreateFormulaData;
use IPI\Core\DTO\CreateIngredientItemData;
use IPI\Core\DTO\CreateIngredientListsData;
use IPI\Core\DTO\CreateNotificationData;
use IPI\Core\DTO\CreateProductData;
use IPI\Core\Entities\Checkpoint;
use IPI\Core\Entities\Formula;
use IPI\Core\Entities\IngredientItem;
use IPI\Core\Entities\IngredientList;
use IPI\Core\Entities\Product;
use IPI\Core\General\NotificationCreator;

class FormulaCreator
{
    private ProductCreator $productCreator;
    private NotificationCreator $notificationCreator;

    public function __construct(ProductCreator $productCreator, NotificationCreator $notificationCreator)
    {
        $this->productCreator = $productCreator;
        $this->notificationCreator = $notificationCreator;
    }

    public function createFormula(CreateFormulaData $data): Formula
    {
        return DB::transaction(function () use ($data) {
            $totalCost = $this->calculateTotalCost($data->ingredientLists);
            $productData = $this->prepareProductData($data, $totalCost);
            $product = $this->productCreator->createProduct($productData, false, true);

            $formulaEloquent = new EloquentFormula([
                'remark' => $data->remark,
                'total_cost' => $totalCost,
            ]);
            $formulaEloquent->product()->associate($product->id);
            $formulaEloquent->engineer()->associate($data->engineerId);
            $formulaEloquent->formulaType()->associate($data->formulaTypeId);
            $formulaEloquent->save();

            $formulaEloquent->formulaTags()->sync([$data->formulaTagId]);

            $checkpoints = $this->createCheckpoints($data->checkpoints, $formulaEloquent->id);
            $checkpointEntities = [];

            foreach ($checkpoints as $checkpoint) {
                $checkpointEntity = new Checkpoint($checkpoint->id);
                $checkpointEntity->setFromArray($checkpoint->toArray());
                $checkpointEntities[] = $checkpointEntity;
            }

            $ingredients = $this->createIngredients($data->ingredientLists, $formulaEloquent->id);
            $ingredientEntities = [];

            foreach ($ingredients as $ingredient) {
                $ingredientEntity = new IngredientList($ingredient->id);
                $ingredientEntity->remark = $ingredient->remark;
                $ingredientEntity->totalCost = $ingredient->total_cost;
                $ingredientEntity->position = $ingredient->position;

                $ingredientItems = [];
                foreach ($ingredient->ingredientListItems as $ingredientListItem) {
                    $ingredientItem = new IngredientItem($ingredientListItem->id);
                    $ingredientItem->totalCost = $ingredientListItem->total_cost;
                    $ingredientItem->percentage = $ingredientListItem->percentage;
                    $ingredientItem->remark = $ingredientListItem->remark;

                    $ingredientItems[] = $ingredientItem;
                }

                $ingredientEntity->ingredientItems = $ingredientItems;
                $ingredientEntities[] = $ingredientEntity;
            }

            $formula = new Formula($formulaEloquent->id);
            $formula->uuid = $formulaEloquent->uuid;
            $formula->remark = $formulaEloquent->remark;
            $formula->totalCost = $formulaEloquent->total_cost;
            $formula->product = $product;
            $formula->formulaTagId = $data->formulaTagId;
            $formula->checkpoints = $checkpointEntities;
            $formula->ingredientLists = $ingredientEntities;

            $this->generateNotification($formula, $product->type);

            return $formula;
        });
    }

    private function prepareProductData(CreateFormulaData $data, int $totalCost): CreateProductData
    {
        $productCode = $this->generateProductCode($data->formulaTypeId);
        $createProductData = new CreateProductData();
        $createProductData->requesterCustomerId = $data->requesterCustomerId;
        $createProductData->type = $data->type;
        $createProductData->quantity = 0;
        $createProductData->name = $data->productName;
        $createProductData->description = $data->remark;
        $createProductData->productCode = $productCode;
        $createProductData->unitCost = $totalCost;

        return $createProductData;
    }

    /**
     * @param CreateIngredientListsData[] $ingredientList
     *
     * @return int
     */
    private function calculateTotalCost(array $ingredientList): int
    {
        $totalCost = 0;

        foreach ($ingredientList as $item) {
            foreach ($item->createIngredientItems as $createIngredientItem) {
                $totalCost += $createIngredientItem->totalCost;
            }
        }

        return $totalCost;
    }

    private function generateProductCode(int $formulaTypeId): string
    {
        $formula = FormulaType::query()->find($formulaTypeId);
        $prefix = strtoupper($formula->type);
        $latestTypeFormula = EloquentFormula::query()
            ->leftJoin('products', 'products.id', '=', 'formulas.product_id')
            ->where('formula_type_id', $formulaTypeId)
            ->select(['products.product_code'])
            ->orderBy('formulas.id', 'desc')
            ->first();

        if ($latestTypeFormula === null) {
            $runningNumber = sprintf("%06d", 1);

            return strtoupper("{$prefix}{$runningNumber}");
        }

        $currentNumber = (int)substr($latestTypeFormula->product_code, -6);
        $runningNumber = sprintf("%06d", $currentNumber + 1);

        return strtoupper("{$prefix}{$runningNumber}");
    }

    /**
     * @param CreateFormulaCheckpointData[] $checkpointsData
     * @param int $formulaId
     *
     * @return array
     */
    private function createCheckpoints(array $checkpointsData, int $formulaId): array
    {
        $checkpoints = [];
        foreach ($checkpointsData as $item) {
            $checkpoint = new EloquentCheckpoint([
                'type' => $item->type,
                'range_min' => $item->rangeMin,
                'range_max' => $item->rangeMax,
                'tolerance_max' => $item->toleranceMin,
                'tolerance_min' => $item->toleranceMax,
                'equipment' => $item->equipment,
                'remark' => $item->remark,
            ]);
            $checkpoint->formula()->associate($formulaId);
            $checkpoint->save();

            $checkpoints[] = $checkpoint;
        }

        return $checkpoints;
    }

    /**
     * @param CreateIngredientListsData[] $ingredientLists
     * @param int $formulaId
     *
     * @return array
     */
    private function createIngredients(array $ingredientLists, int $formulaId): array
    {
        $ingredients = [];

        foreach ($ingredientLists as $key => $item) {
            $ingredient = new EloquentIngredientList([
                'remark' => $item->remark,
                'total_cost' => $this->calculateIngredientListTotalCost($item->createIngredientItems),
                'position' => $key + 1,
            ]);
            $ingredient->formula()->associate($formulaId);
            $ingredient->save();

            foreach ($item->createIngredientItems as $createIngredientItem) {
                $ingredientItem = new IngredientListItem([
                    'total_cost' => $createIngredientItem->totalCost,
                    'percentage' => $createIngredientItem->percentage,
                    'remark' => $createIngredientItem->remark,
                ]);
                $ingredientItem->ingredientList()->associate($ingredient);
                $ingredientItem->product()->associate($createIngredientItem->productId);
                $ingredientItem->save();
            }

            $ingredient->loadMissing('ingredientListItems');
            $ingredients[] = $ingredient;
        }

        return $ingredients;
    }

    /**
     * @param CreateIngredientItemData[] $ingredientListItems
     *
     * @return int
     */
    private function calculateIngredientListTotalCost(array $ingredientListItems): int
    {
        $total = 0;

        foreach ($ingredientListItems as $ingredientListItem) {
            $total += $ingredientListItem->totalCost;
        }

        return $total;
    }

    private function generateNotification(Formula $formula, string $productType): void
    {
        $prefix = $productType === Product::TYPE_FORMULA_SAMPLE ? 'Sample Formula' : 'Formula';
        $moduleIds = Module::query()->where('slug', Module::FORMULA)->pluck('id')->toArray();
        $createNotificationData = new CreateNotificationData();
        $createNotificationData->description = "$prefix {$formula->product->productCode} is created.";
        $createNotificationData->viewActionLink = route('formula.details', ['uuid' => $formula->uuid]);
        $createNotificationData->moduleIds = $moduleIds;
        $createNotificationData->approvalAction = route('api.formulas.approve', $formula->uuid);
        $createNotificationData->rejectionAction = route('api.formulas.reject', $formula->uuid);

        $this->notificationCreator->createNotification($createNotificationData);
    }
}
