<?php

namespace IPI\Core\Product;

use App\Models\Formula;

class UpdateProductTotalCost
{
    public function handle(array $productIds)
    {
        foreach ($productIds as $productId) {
            $formulas = Formula::query()
                ->with(
                    ['product', 'ingredientLists.ingredientListItems.product']
                )
                ->whereHas(
                    'ingredientLists',
                    function ($query) use ($productId) {
                        return $query->whereHas(
                            'ingredientListItems',
                            function ($query) use ($productId) {
                                return $query->where('product_id', $productId);
                            }
                        );
                    }
                )
                ->get();

            foreach ($formulas as $formula) {
                $totalCost = $this->calculateCost($formula);
                logger($totalCost);

                if ($formula->total_cost !== $totalCost) {
                    $formula->total_cost = $totalCost;
                    $formula->save();

                    $formula->product->unit_cost = $totalCost;
                    $formula->product->save();
                }
            }
        }
    }

    public function calculateCost($formula): int
    {
        $totalCost = 0;

        foreach ($formula->ingredientLists as $ingredientList) {
            $ingredientListCost = 0;

            foreach (
                $ingredientList->ingredientListItems as $ingredientListItem
            ) {
                $newCost = (float)($this->roundingNumber(($ingredientListItem->product->unit_cost / 100
                    * ($ingredientListItem->percentage / 100)), 3)) * 100;
                $ingredientListCost += (int)$newCost;
                logger($newCost);

                if ($newCost !== $ingredientListItem->total_cost) {
                    $ingredientListItem->total_cost = (int)$newCost;
                    $ingredientListItem->save();
                }
            }

            $totalCost += $ingredientListCost;
            logger($ingredientListCost);

            if ($ingredientListCost !== $ingredientList->total_cost) {
                $ingredientList->total_cost = $ingredientListCost;
                $ingredientList->save();
            }
            
            logger($totalCost);
        }
        
        logger($totalCost);

        return $totalCost;
    }

    public function roundingNumber($number, $dp)
    {
        if ($number > 0 && $number < 0.01) {
            $number = 0.01;
        }

        $threeDp = number_format($number, 3);
        $lastDigitArray = str_split($threeDp);
        $lastDigit = array_pop($lastDigitArray);

        if ((int)$lastDigit > 0) {
            $stringNumber = (string)((float)$threeDp + 0.01);
            $numberArray = str_split($stringNumber);
            $totalCurrentDp = strlen(explode('.', $stringNumber)[1]);
            $counter = 0;

            while ($counter < ($totalCurrentDp - $dp)) {
                array_pop($numberArray);
                $counter++;
            }

            return implode('', $numberArray);
        }

        return number_format((float)$threeDp, $dp);
    }
}
