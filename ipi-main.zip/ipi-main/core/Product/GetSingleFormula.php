<?php

namespace IPI\Core\Product;

use App\Models\Formula as FormulaEloquent;
use Carbon\Carbon;
use IPI\Core\Entities\Checkpoint;
use IPI\Core\Entities\Formula;
use IPI\Core\Entities\IngredientItem;
use IPI\Core\Entities\IngredientList;
use IPI\Core\Entities\Product;

class GetSingleFormula
{
    public function getFormula(string $uuid): Formula
    {
        $eloquentQueryBuilder = FormulaEloquent::query()->with([
            'engineer',
            'product' => function ($query) {
                return $query->withTrashed()->with('requesterCustomer');
            },
            'formulaType',
            'formulaTags',
            'ingredientLists.ingredientListItems' => function ($query) {
                return $query->with([
                    'product' => function ($query) {
                        return $query->withTrashed()->with('requesterCustomer');
                    },
                ]);
            },
            'checkpoints',
        ]);
        $formula = $eloquentQueryBuilder->where('uuid', $uuid)->withCreator()->first();

        return $this->prepareFormula($formula);
    }

    private function prepareFormula(FormulaEloquent $item): Formula
    {
        $formulaTag = $item->formulaTags()->first();
        $formulaType = $item->formulaType;

        $formula = new Formula($item->id);
        $formula->uuid = $item->uuid;
        $formula->createdAt = Carbon::parse($item->created_at);
        $formula->updatedAt = Carbon::parse($item->updated_at);
        $formula->formulaTypeId = $formulaType->id;
        $formula->formulaTagId = $formulaTag->id;
        $formula->engineerId = $item->engineer->id;
        $formula->engineerName = $item->engineer->name;
        $formula->formulaTag = $formulaTag->name ?? null;
        $formula->creatorName = $item->creator ?? null;
        $formula->totalCost = $item->total_cost;
        $formula->remark = $item->remark;

        $product = new Product($item->product->id);
        $product->setFromArray($item->product->toArray());
        $product->requesterCustomerId = $item->product->requester_customer_id;
        $formula->product = $product;

        $ingredientLists = [];

        foreach ($item->ingredientLists as $ingredientListEloquent) {
            $ingredientList = new IngredientList($ingredientListEloquent->id);
            $ingredientList->totalCost = $ingredientListEloquent->total_cost;
            $ingredientList->position = $ingredientListEloquent->position;
            $ingredientList->remark = $ingredientListEloquent->remark;

            $ingredientListItems = [];

            foreach ($ingredientListEloquent->ingredientListItems as $ingredientListItemEloquent) {
                $ingredientListItem = new IngredientItem($ingredientListItemEloquent->id);
                $ingredientListItem->totalCost = $ingredientListItemEloquent->total_cost;
                $ingredientListItem->remark = $ingredientListItemEloquent->remark;
                $ingredientListItem->percentage = $ingredientListItemEloquent->percentage;
                $ingredientListItem->productId = $ingredientListItemEloquent->product_id;
                $ingredientListItem->productCode = $ingredientListItemEloquent->product->product_code;

                $ingredientListItems[] = $ingredientListItem;
            }

            $ingredientList->ingredientItems = $ingredientListItems;
            $ingredientLists[] = $ingredientList;
        }

        $checkpoints = [];
        foreach ($item->checkpoints as $checkpointEloquent) {
            $checkpoint = new Checkpoint($checkpointEloquent->id);
            $checkpoint->setFromArray($checkpointEloquent->toArray());

            $checkpoints[] = $checkpoint;
        }

        $formula->checkpoints = $checkpoints;
        $formula->ingredientLists = $ingredientLists;

        return $formula;
    }
}
