<?php

namespace IPI\Core\Product;

use App\Models\Formula as EloquentFormula;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection as EloquentCollection;
use Illuminate\Support\Collection as SupportCollection;
use IPI\Core\DTO\IndexFilter;
use IPI\Core\Entities\Formula;
use IPI\Core\Entities\Product;
use IPI\Core\Filters\EloquentIndexQueryBuilder;
use IPI\Core\General\EloquentResponseMetaBuilder;

class GetFormulas
{
    public function getFormulas(IndexFilter $data): array
    {
        $eloquentFormulaQuery = EloquentFormula::query()->withCreator()->with($data->relationships);
        $queryBuilder = new EloquentIndexQueryBuilder($eloquentFormulaQuery);
        $eloquentQueryBuilder = $queryBuilder->execute($data, 'formulas');

        if (isset($data->type)) {
            $eloquentQueryBuilder->leftJoin('products', 'products.id', '=', 'formulas.product_id')
                ->where('products.type', $data->type);
        }

        if ($data->paginateResult) {
            $formulas = $eloquentQueryBuilder->paginate($data->perPage);
            $responseMetaBuilder = new EloquentResponseMetaBuilder($formulas);

            return [
                $this->prepareFormulas($formulas->getCollection()),
                $responseMetaBuilder->execute()
            ];
        }

        $formulas = $eloquentQueryBuilder->get();
        $formulas = $this->prepareFormulas($formulas);

        return [$formulas, []];
    }

    private function prepareFormulas(EloquentCollection|SupportCollection $collection): array
    {
        $formulas = [];

        foreach ($collection as $item) {
            $formula = new Formula($item->id);
            $formula->uuid = $item->uuid;
            $formula->createdAt = Carbon::parse($item->created_at);
            $formula->updatedAt = Carbon::parse($item->updated_at);
            $formula->formulaTag = $item->formulaTags()->first()->name ?? null;
            $formula->creatorName = $item->creator ?? null;
            $formula->approvedAt = Carbon::parse($item->approved_at);
            $formula->rejectedAt = Carbon::parse($item->rejected_at);
            $formula->status = $item->approved_at !== null ? Formula::APPROVED :
                ($item->rejected_at !== null ? Formula::REJECTED : Formula::PENDING);

            $product = new Product($item->product->id);
            $product->setFromArray($item->product->toArray());
            $product->requesterCustomerId = $item->product->requester_customer_id;
            $formula->product = $product;

            $formulas[] = $formula;
        }

        return $formulas;
    }
}
