<?php

namespace IPI\Core\Product;

use App\Models\FormulaType as FormulaTypeEloquent;
use IPI\Core\DTO\CreateFormulaTypeData;
use IPI\Core\Entities\FormulaType;

class FormulaTypeCreator
{
    public function execute(CreateFormulaTypeData $data): FormulaType
    {
        $formulaTypeEloquent = new FormulaTypeEloquent([
            'type' => strtoupper($data->name),
            'display_text' => $data->name
        ]);
        $formulaTypeEloquent->save();

        $formulaType = new FormulaType($formulaTypeEloquent->id);
        $formulaType->setFromArray($formulaTypeEloquent->toArray());

        return $formulaType;
    }
}
