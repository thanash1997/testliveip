<?php

namespace IPI\Core\Product;

use App\Models\Formula as FormulaEloquent;
use App\Models\IngredientListItem as IngredientListItemEloquent;
use IPI\Core\DTO\UpdateFormulaData;
use IPI\Core\Entities\Formula;

class UpdateSingleFormula
{
    public function updateFormula(UpdateFormulaData $data, string $uuid): Formula
    {
        $formulaEloquent = FormulaEloquent::query()->where('uuid', $uuid)
            ->with([
                'product',
                'checkpoints',
                'ingredientLists.ingredientListItems',
            ])
            ->first();
        $product = $formulaEloquent->product;

        if (isset($data->remark)) {
            $formulaEloquent->remark = $data->remark;
            $product->description = $data->remark;
        }

        if (isset($data->engineerId)) {
            $formulaEloquent->engineer()->associate($data->engineerId);
        }

        if (isset($data->formulaTypeId)) {
            $formulaEloquent->formulaType()->associate($data->formulaTypeId);
        }

        if ($formulaEloquent->isDirty()) {
            $formulaEloquent->save();
        }

        if (isset($data->formulaTagId)) {
            $formulaEloquent->formulaTags()->sync([$data->formulaTagId]);
        }

        if (isset($data->productName)) {
            $product->name = $data->productName;
        }

        if (isset($data->requesterCustomerId)) {
            $product->requesterCustomer()->associate($data->requesterCustomerId);
        }

        if ($product->isDirty()) {
            $product->save();
        }

        $this->updateIngredients($data->ingredientLists, $formulaEloquent);
        $this->updateCheckpoints($data->checkpoints, $formulaEloquent);

        $formula = new Formula($formulaEloquent->id);
        $formula->uuid = $formulaEloquent->uuid;
        $formula->remark = $formulaEloquent->remark;
        $formula->totalCost = $formulaEloquent->total_cost;
        $formula->formulaTagId = $formulaEloquent->formulaTags()->first()->id;

        return $formula;
    }

    private function updateCheckpoints(array $checkpointsData, $formulaEloquent): void
    {
        foreach ($checkpointsData as $item) {
            $formulaEloquent->checkpoints()->updateOrCreate(
                [
                    'type' => $item->type,
                ],
                [
                    'range_min' => $item->rangeMin,
                    'range_max' => $item->rangeMax,
                    'tolerance_max' => $item->toleranceMin,
                    'tolerance_min' => $item->toleranceMax,
                    'equipment' => $item->equipment,
                    'remark' => $item->remark,
                ]
            );
        }
    }

    private function updateIngredients(array $ingredientLists, $formulaEloquent): void
    {
        foreach ($ingredientLists as $key => $item) {
            $formulaEloquent->ingredientLists()->where('id', $item->id)->update([
                'remark' => $item->remark,
                'total_cost' => $this->calculateIngredientListTotalCost($item->createIngredientItems),
                'position' => $key + 1,
            ]);

            foreach ($item->createIngredientItems as $createIngredientItem) {
                $ingredientItem = IngredientListItemEloquent::query()->find($createIngredientItem->id);
                $ingredientItem->total_cost = $createIngredientItem->totalCost;
                $ingredientItem->percentage = $createIngredientItem->percentage;
                $ingredientItem->remark = $createIngredientItem->remark;

                if (isset($createIngredientItem->productId)) {
                    $ingredientItem->product()->associate($createIngredientItem->productId);
                }

                if ($ingredientItem->isDirty()) {
                    $ingredientItem->save();
                }
            }
        }
    }

    private function calculateIngredientListTotalCost(array $ingredientListItems): int
    {
        $total = 0;

        foreach ($ingredientListItems as $ingredientListItem) {
            $total += $ingredientListItem->totalCost;
        }

        return $total;
    }
}
