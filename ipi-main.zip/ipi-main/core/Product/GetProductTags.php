<?php

namespace IPI\Core\Product;

use App\Models\ProductTag as EloquentProductTag;
use Illuminate\Database\Eloquent\Collection as EloquentCollection;
use Illuminate\Support\Collection as SupportCollection;
use IPI\Core\DTO\IndexFilter;
use IPI\Core\Entities\ProductTag;
use IPI\Core\Filters\EloquentIndexQueryBuilder;
use IPI\Core\General\EloquentResponseMetaBuilder;

class GetProductTags
{
    public function getProductTags(IndexFilter $data): array
    {
        $eloquentProductTagQuery = EloquentProductTag::query();
        $queryBuilder = new EloquentIndexQueryBuilder($eloquentProductTagQuery);
        $eloquentQueryBuilder = $queryBuilder->execute($data, 'product_tags');

        if ($data->paginateResult) {
            $productTags = $eloquentQueryBuilder->paginate($data->perPage);
            $responseMetaBuilder = new EloquentResponseMetaBuilder($productTags);

            return [
                $this->prepareProductTags($productTags->getCollection()),
                $responseMetaBuilder->execute()
            ];
        }

        $productTags = $eloquentQueryBuilder->get();
        $productTags = $this->prepareProductTags($productTags);

        return [$productTags, []];
    }

    private function prepareProductTags(EloquentCollection|SupportCollection $collection): array
    {
        $productTags = [];

        foreach ($collection as $item) {
            $productTag = new ProductTag();
            $productTag->id = $item->id;
            $productTag->name = $item->name;
            $productTag->slug = $item->slug;

            $productTags[] = $productTag;
        }

        return $productTags;
    }
}
