<?php

namespace IPI\Core\Product;

use App\Models\Company as EloquentCompany;
use App\Models\PurchaseOrder;
use Illuminate\Database\Eloquent\Collection as EloquentCollection;
use Illuminate\Support\Collection as SupportCollection;
use IPI\Core\DTO\IndexFilter;
use IPI\Core\Entities\Company;
use IPI\Core\Entities\Procurement;
use IPI\Core\Filters\EloquentIndexQueryBuilder;
use IPI\Core\General\EloquentResponseMetaBuilder;

class GetProcurements
{
    public function getProcurements(IndexFilter $data): array
    {
        $eloquentQueryBuilder = PurchaseOrder::query()->with($data->relationships);
        $queryBuilder = new EloquentIndexQueryBuilder($eloquentQueryBuilder);
        $eloquentQueryBuilder = $queryBuilder->execute($data, 'purchase_orders');

        if (isset($data->companyUuid)) {
            $company = EloquentCompany::query()->where('uuid', $data->companyUuid)->first();

            $eloquentQueryBuilder->where('supplier_id', $company->id);
        }

        if ($data->paginateResult) {
            $purchaseOrders = $eloquentQueryBuilder->paginate($data->perPage);
            $responseMetaBuilder = new EloquentResponseMetaBuilder($purchaseOrders);

            return [
                $this->prepareProcurements($purchaseOrders->getCollection()),
                $responseMetaBuilder->execute()
            ];
        }

        $purchaseOrders = $eloquentQueryBuilder->get();
        $purchaseOrders = $this->prepareProcurements($purchaseOrders);

        return [$purchaseOrders, []];
    }

    private function prepareProcurements(EloquentCollection|SupportCollection $collection): array
    {
        $purchaseOrders = [];

        foreach ($collection as $item) {
            $procurement = new Procurement($item->id);
            $procurement->setFromArray($item->toArray());

            $supplier = new Company();
            $supplier->id = $item->supplier->id;
            $supplier->uuid = $item->supplier->uuid;
            $supplier->name = $item->supplier->name;
            $supplier->companyCode = $item->supplier->company_code;

            $procurement->supplier = $supplier;

            $purchaseOrders[] = $procurement;
        }

        return $purchaseOrders;
    }
}
