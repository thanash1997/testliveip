<?php

namespace IPI\Core\Product;

use App\Models\ProductRequisition as ProductRequisitionEloquent;
use Illuminate\Database\Eloquent\Collection as EloquentCollection;
use Illuminate\Support\Collection as SupportCollection;
use IPI\Core\DTO\IndexFilter;
use IPI\Core\Entities\ProductRequisition;
use IPI\Core\Filters\EloquentIndexQueryBuilder;
use IPI\Core\General\EloquentResponseMetaBuilder;

class GetProductRequisitions
{
    public function getProductRequisitions(IndexFilter $data): array
    {
        $eloquentProductRequisitionsQuery = ProductRequisitionEloquent::query()->withCreator()->with($data->relationships);
        $queryBuilder = new EloquentIndexQueryBuilder($eloquentProductRequisitionsQuery);
        $eloquentQueryBuilder = $queryBuilder->execute($data, 'product_requisitions');

        if ($data->paginateResult) {
            $productRequisitions = $eloquentQueryBuilder->paginate($data->perPage);
            $responseMetaBuilder = new EloquentResponseMetaBuilder($productRequisitions);

            return [
                $this->prepareProductRequisitions($productRequisitions->getCollection()),
                $responseMetaBuilder->execute()
            ];
        }

        $productRequisitions = $eloquentQueryBuilder->get();
        $productRequisitions = $this->prepareProductRequisitions($productRequisitions);

        return [$productRequisitions, []];
    }

    private function prepareProductRequisitions(EloquentCollection|SupportCollection $collection): array
    {
        $productRequisitions = [];

        foreach ($collection as $item) {
            $productRequisition = new ProductRequisition($item->id);
            $productRequisition->setFromArray($item->toArray());
            $productRequisition->setItemsFromArray($item->productRequisitionItems->toArray());

            $productRequisitions[] = $productRequisition;
        }

        return $productRequisitions;
    }
}
