<?php

namespace IPI\Core\Product;

use App\Models\Product as EloquentProduct;
use IPI\Core\Entities\Product;

class GetSingleProduct
{
    public function getProduct(string $uuid, int $inventoryId): Product
    {
        $eloquentQueryBuilder = EloquentProduct::query()->with(['requesterCustomer', 'inventories', 'productTags', 'audits.user']);
        $eloquentQueryBuilder->whereInventoryIs($inventoryId);
        $eloquentQueryBuilder->select(['products.*', 'inventory_products.quantity']);

        $productEloquent = $eloquentQueryBuilder->where('uuid', $uuid)->withCreator()->first();

        return $this->prepareProduct($productEloquent);
    }

    private function prepareProduct(EloquentProduct $productEloquent): Product
    {
        $product = new Product($productEloquent->id);
        $product->setFromArray($productEloquent->toArray());
        $product->setProductTags($productEloquent->productTags->toArray());
        $product->setAudits($productEloquent->audits->toArray());

        return $product;
    }
}
