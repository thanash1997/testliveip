<?php

namespace IPI\Core\Product;

use App\Models\FormulaTag as EloquentFormulaTag;
use Illuminate\Database\Eloquent\Collection as EloquentCollection;
use Illuminate\Support\Collection as SupportCollection;
use IPI\Core\DTO\IndexFilter;
use IPI\Core\Entities\FormulaTag;
use IPI\Core\Filters\EloquentIndexQueryBuilder;
use IPI\Core\General\EloquentResponseMetaBuilder;

class GetFormulaTags
{
    public function getFormulaTags(IndexFilter $data): array
    {
        $eloquentFormulaTagQuery = EloquentFormulaTag::query();
        $queryBuilder = new EloquentIndexQueryBuilder($eloquentFormulaTagQuery);
        $eloquentQueryBuilder = $queryBuilder->execute($data, 'formula_tags');

        if ($data->paginateResult) {
            $formulaTags = $eloquentQueryBuilder->paginate($data->perPage);
            $responseMetaBuilder = new EloquentResponseMetaBuilder($formulaTags);

            return [
                $this->prepareFormulaTags($formulaTags->getCollection()),
                $responseMetaBuilder->execute()
            ];
        }

        $formulaTags = $eloquentQueryBuilder->get();
        $formulaTags = $this->prepareFormulaTags($formulaTags);

        return [$formulaTags, []];
    }

    private function prepareFormulaTags(EloquentCollection|SupportCollection $collection): array
    {
        $formulaTags = [];

        foreach ($collection as $item) {
            $formulaTag = new FormulaTag($item->id);
            $formulaTag->setFromArray($item->toArray());

            $formulaTags[] = $formulaTag;
        }

        return $formulaTags;
    }
}
