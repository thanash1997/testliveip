<?php

namespace IPI\Core\Product;

use App\Models\Notification;
use App\Models\Product as ProductEloquent;
use App\Models\ProductRequisition as ProductRequisitionEloquent;
use App\Models\ProductRequisitionItem as ProductRequisitionItemEloquent;
use Illuminate\Support\Facades\DB;
use IPI\Core\DTO\CreateProductData;
use IPI\Core\DTO\UpdateProductRequisitionData;
use IPI\Core\Entities\Product;
use IPI\Core\Entities\ProductRequisition;
use IPI\Core\Order\GenerateInternalDeliveryOrder;

class UpdateSingleProductRequisition
{
    private ProductCreator $productCreator;
    private GenerateInternalDeliveryOrder $generateInternalDeliveryOrder;
    private const UPDATABLE
        = [
            'usage',
            'origin',
            'flag_reason',
            'status',
            'is_flagged',
        ];

    public function __construct(
        ProductCreator $productCreator,
        GenerateInternalDeliveryOrder $generateInternalDeliveryOrder
    ) {
        $this->productCreator = $productCreator;
        $this->generateInternalDeliveryOrder = $generateInternalDeliveryOrder;
    }

    /**
     * @param  UpdateProductRequisitionData  $data
     * @param  string                        $uuid
     *
     * @return ProductRequisition
     */
    public function updateProductRequisition(
        UpdateProductRequisitionData $data,
        string $uuid
    ): ProductRequisition {
        $productRequisitionEloquent = ProductRequisitionEloquent::query()
            ->where('uuid', $uuid)->first();
        $previousState = new ProductRequisition(
            $productRequisitionEloquent->id
        );
        $previousState->setFromArray($productRequisitionEloquent->toArray());

        return DB::transaction(
            function () use (
                $data,
                $previousState,
                $productRequisitionEloquent
            ) {
                $values = get_object_vars($data);
                $newlyApproved = null;

                foreach ($values as $key => $value) {
                    if ($value === null) {
                        continue;
                    }

                    $key = $this->formatKey($key);
                    if (in_array($key, self::UPDATABLE)) {
                        if ($key === 'status'
                            && $value === ProductRequisition::PENDING
                        ) {
                            $productRequisitionEloquent->approved_at = null;
                            $productRequisitionEloquent->rejected_at = null;
                            continue;
                        }

                        if ($key === 'status'
                            && $value === ProductRequisition::APPROVED
                            && $previousState->status
                            === ProductRequisition::PENDING
                        ) {
                            $newlyApproved = now();
                            continue;
                        }

                        [$modelKey, $value] = $this->formatValue($key, $value);
                        $productRequisitionEloquent->$modelKey = $value;
                    }
                }

                if (isset($data->destinationId)) {
                    $productRequisitionEloquent->destination()->associate(
                        $data->destinationId
                    );
                }

                $productRequisitionEloquent->save();

                if (isset($data->remark)) {
                    $productRequisitionEloquent->remarks()->create(
                        ['body' => $data->remark]
                    );
                }

                foreach ($data->createProductRequisitionItemData as $item) {
                    $existingProductId = $item->productId ??
                        ProductEloquent::query()->where(
                            'product_code',
                            $item->productCode
                        )->first()->id ?? null;

                    if ($existingProductId) {
                        $productRequisitionItemEloquent = $item->id
                            ? $productRequisitionEloquent->productRequisitionItems(
                            )->where('id', $item->id)->first()
                            : $productRequisitionEloquent->productRequisitionItems(
                            )->where('product_id', $existingProductId)->first();

                        if ($productRequisitionItemEloquent) {
                            $productRequisitionItemEloquent->update([
                                'quantity' => $item->quantity,
                                'packaging_size' => $item->packagingSize,
                                'description' => $item->description,
                            ]);
                        } else {
                            $productRequisitionItemEloquent
                                = new ProductRequisitionItemEloquent([
                                'quantity' => $item->quantity,
                                'packaging_size' => $item->packagingSize,
                                'description' => $item->description,
                            ]);
                            $productRequisitionItemEloquent->productRequisition(
                            )->associate($productRequisitionEloquent->id);
                            $productRequisitionItemEloquent->product()
                                ->associate($existingProductId);
                            $productRequisitionItemEloquent->save();
                        }
                    } else {
                        $createProductData = new CreateProductData();
                        $createProductData->productCode = $item->productCode;
                        $createProductData->quantity = $item->quantity;
                        $createProductData->packagingSize
                            = $item->packagingSize;
                        $createProductData->description = $item->description;
                        $createProductData->unitCost = 0;
                        $createProductData->quantity = 0;
                        $createProductData->type
                            = Product::TYPE_AWAITING_PROCUREMENT;

                        $product = $this->productCreator->createProduct(
                            $createProductData
                        );

                        $productRequisitionItemEloquent
                            = new ProductRequisitionItemEloquent([
                            'quantity' => $item->quantity,
                            'packaging_size' => $item->packagingSize,
                            'description' => $item->description,
                        ]);
                        $productRequisitionItemEloquent->productRequisition()
                            ->associate($productRequisitionEloquent->id);
                        $productRequisitionItemEloquent->product()->associate(
                            $product->id
                        );
                        $productRequisitionItemEloquent->save();
                    }
                }

                $productRequisitionEloquent->loadMissing(
                    ['productRequisitionItems.product', 'order']
                );

                $productRequisition = new ProductRequisition(
                    $productRequisitionEloquent->id
                );
                $productRequisition->setFromArray(
                    $productRequisitionEloquent->toArray()
                );
                $productRequisition->setItemsFromArray(
                    $productRequisitionEloquent->productRequisitionItems->toArray(
                    )
                );

                if ($newlyApproved !== null) {
                    $this->generateInternalDeliveryOrder->generate(
                        $productRequisition
                    );
                    $actionUrl = route(
                        'api.imr.approve',
                        $productRequisition->uuid
                    );
                    $productRequisitionEloquent->update([
                        'approved_at' => $newlyApproved,
                    ]);

                    Notification::query()->where('approval_action', $actionUrl)
                        ->update([
                            'read_at' => now(),
                            'action_taken_at' => now(),
                        ]);
                }

                return $productRequisition;
            }
        );
    }

    private function formatValue(string $key, $value)
    {
        if ($key === 'is_flagged') {
            if ($value === true) {
                return ['flagged_at', now()];
            }

            return ['flagged_at', null];
        }

        if ($key === 'status') {
            $hashMap = [
                ProductRequisition::APPROVED => 'approved_at',
                ProductRequisition::REJECTED => 'rejected_at',
            ];

            return [$hashMap[$value], now()];
        }

        return [$key, $value];
    }

    private function formatKey(string $key): string
    {
        return strtolower(
            preg_replace(
                [
                    '#([A-Z][a-z]*)(\d+[A-Z][a-z]*\d+)#',
                    '#([A-Z]+\d*)([A-Z])#',
                    '#([a-z]+\d*)([A-Z])#',
                    '#([^_\d])([A-Z][a-z])#',
                ],
                '$1_$2',
                $key
            )
        );
    }
}
