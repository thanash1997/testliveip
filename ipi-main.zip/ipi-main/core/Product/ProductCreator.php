<?php

namespace IPI\Core\Product;

use App\Models\Inventory;
use App\Models\Product as ProductEloquent;
use Illuminate\Support\Facades\DB;
use IPI\Core\DTO\CreateProductData;
use IPI\Core\Entities\Product;

class ProductCreator
{
    public function createProduct(
        CreateProductData $data,
        bool $forWarehouse = true,
        bool $forProduction = false
    ): Product {
        return DB::transaction(function () use ($data, $forWarehouse, $forProduction) {
            $product = new ProductEloquent([
                'product_code' => str_replace(' ', '', strtoupper($data->productCode)),
                'description' => $data->description,
                'name' => $data->name ?? null,
                'unit_cost' => $data->unitCost ?? null,
                'threshold' => $data->threshold ?? null,
                'type_code' => $data->typeCode ?? null,
                'packaging_size' => $data->packagingSize ?? null,
                'type' => $data->type,
            ]);

            $hasProductTag = isset($data->productTagId);
            $hasRequester = isset($data->requesterCustomerId);

            if ($hasRequester) {
                $product->requesterCustomer()->associate($data->requesterCustomerId);
            }

            $product->save();

            if ($hasProductTag) {
                $product->productTags()->sync([$data->productTagId]);
            }

            $warehouseQuantity = 0;
            $productQuantity = 0;

            if ($forWarehouse) {
                $warehouseQuantity = $data->quantity;
            }

            if ($forProduction) {
                $productQuantity = $data->quantity;
            }

            $warehouseInventory = Inventory::query()->where('slug', Inventory::WAREHOUSE)->first();
            $productionInventory = Inventory::query()->where('slug', Inventory::PRODUCTION)->first();

            $product->inventories()->sync([
                $warehouseInventory->id => [
                    'quantity' => $warehouseQuantity,
                ],
                $productionInventory->id => [
                    'quantity' => $productQuantity,
                ],
            ]);

            $productEntity = new Product($product->id);
            $productEntity->setFromArray($product->toArray());
            $productEntity->setProductTags($product->productTags()->get()->toArray());

            return $productEntity;
        });
    }
}
