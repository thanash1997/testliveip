<?php

namespace IPI\Core\Product;

use App\Models\Inventory;
use App\Models\Product as ProductEloquent;
use App\Models\PurchaseOrder;
use App\Models\PurchaseOrderItem;
use Illuminate\Support\Facades\DB;
use IPI\Core\DTO\CreateProcurementData;
use IPI\Core\DTO\CreateProductData;
use IPI\Core\Entities\Procurement;
use IPI\Core\Entities\Product;

class ProcurementCreator
{
    private ProductCreator $productCreator;

    public function __construct(ProductCreator $productCreator)
    {
        $this->productCreator = $productCreator;
    }

    public function createProcurement(CreateProcurementData $data): Procurement
    {
        return DB::transaction(function () use ($data) {
            $purchaseOrder = new PurchaseOrder([
                'usage' => $data->usage,
                'po_number' => $data->poNumber,
                'total_cost' => $data->totalCost,
                'flag_reason' => $data->isFlagged ? $data->flagReason : null,
                'expected_receive_date' => $data->expectedReceiveDate,
                'cancelled_at' => $data->status === Procurement::CANCELLED ? now() : null,
                'fulfilled_at' => $data->status === Procurement::FULFILLED ? now() : null,
                'flagged_at' => $data->isFlagged ? now() : null,
            ]);
            $purchaseOrder->supplier()->associate($data->supplierId);
            $purchaseOrder->destination()->associate($data->destinationId);
            $purchaseOrder->save();

            if (isset($data->remark)) {
                $purchaseOrder->remarks()->create(['body' => $data->remark]);
            }

            $newPurchaseOrderItems = [];
            $productsQuantity = [];

            foreach ($data->purchaseOrderItems as $purchaseOrderItem) {
                $isExistingProduct = isset($purchaseOrderItem->productId);
                $newPurchaseOrderItem = new PurchaseOrderItem([
                    'quantity' => $purchaseOrderItem->quantity,
                    'packaging_size' => $purchaseOrderItem->packagingSize,
                    'description' => $purchaseOrderItem->description,
                    'total_cost' => $purchaseOrderItem->totalCost,
                    'unit_cost' => $purchaseOrderItem->unitCost,
                ]);

                if ($isExistingProduct) {
                    $newPurchaseOrderItem->product()->associate($purchaseOrderItem->productId);
                    $productsQuantity[$purchaseOrderItem->productId] = $purchaseOrderItem->quantity;
                }

                if (!$isExistingProduct) {
                    $existingProduct =
                        ProductEloquent::query()->where('product_code', $purchaseOrderItem->productCode)->first();

                    if ($existingProduct) {
                        $newPurchaseOrderItem->product()->associate($existingProduct->id);
                        $productsQuantity[$purchaseOrderItem->productId] = $purchaseOrderItem->quantity;
                    } else {
                        $createProductData = new CreateProductData();
                        $createProductData->productCode = $purchaseOrderItem->productCode;
                        $createProductData->quantity = $purchaseOrderItem->quantity;
                        $createProductData->packagingSize = $purchaseOrderItem->packagingSize;
                        $createProductData->description = $purchaseOrderItem->description;
                        $createProductData->unitCost = $purchaseOrderItem->unitCost;
                        $createProductData->quantity = 0;
                        $createProductData->type = Product::TYPE_AWAITING_PROCUREMENT;

                        $product = $this->productCreator->createProduct($createProductData, false);
                        $newPurchaseOrderItem->product()->associate($product->id);
                        $productsQuantity[$product->id] = $purchaseOrderItem->quantity;
                    }
                }

                $newPurchaseOrderItem->purchaseOrder()->associate($purchaseOrder);
                $newPurchaseOrderItem->save();

                $newPurchaseOrderItem->load('product');
                array_push($newPurchaseOrderItems, $newPurchaseOrderItem->toArray());
            }

            if ($data->status === Procurement::FULFILLED) {
                $inventory = Inventory::query()->where('slug', Inventory::WAREHOUSE)->first();

                foreach ($productsQuantity as $productId => $quantity) {
                    $inventory->products()->where('product_id', $productId)->increment('quantity', $quantity);
                    ProductEloquent::query()->where('id', $productId)->update([
                        'type' => Product::TYPE_MATERIAL,
                    ]);
                }
            }

            $procurement = new Procurement($purchaseOrder->id);
            $procurement->setFromArray($purchaseOrder->toArray());
            $procurement->setProcurementItemFromArray($newPurchaseOrderItems);

            return $procurement;
        });
    }
}
