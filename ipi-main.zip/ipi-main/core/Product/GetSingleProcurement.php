<?php

namespace IPI\Core\Product;

use App\Models\PurchaseOrder;
use IPI\Core\Entities\Company;
use IPI\Core\Entities\Procurement;

class GetSingleProcurement
{
    public function getProcurement(string $uuid, bool $withDeleted = false): Procurement
    {
        $eloquentQueryBuilder = PurchaseOrder::query()->with([
            'supplier',
            'purchaseOrderItems.product',
            'destination',
            'audits.user',
            'remarks' => function ($query) {
                $query->withCreator();
            },
        ]);
        
        if ($withDeleted === true) {
            $eloquentQueryBuilder->withTrashed();
        }

        $purchaseOrder = $eloquentQueryBuilder->where('uuid', $uuid)->withCreator()->first();

        return $this->prepareProcurement($purchaseOrder);
    }

    private function prepareProcurement(PurchaseOrder $purchaseOrder): Procurement
    {
        $procurement = new Procurement($purchaseOrder->id);
        $procurement->setFromArray($purchaseOrder->toArray());
        $procurement->setProcurementItemFromArray($purchaseOrder->purchaseOrderItems->toArray());
        $procurement->setAudits($purchaseOrder->audits->toArray());
        $procurement->setRemarks($purchaseOrder->remarks->toArray());

        $supplier = new Company();
        $supplier->id = $purchaseOrder->supplier->id;
        $supplier->uuid = $purchaseOrder->supplier->uuid;
        $supplier->name = $purchaseOrder->supplier->name;
        $supplier->companyCode = $purchaseOrder->supplier->company_code;

        $procurement->supplier = $supplier;

        return $procurement;
    }
}
