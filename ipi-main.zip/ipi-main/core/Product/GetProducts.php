<?php

namespace IPI\Core\Product;

use App\Models\Product as EloquentProduct;
use Illuminate\Database\Eloquent\Collection as EloquentCollection;
use Illuminate\Support\Collection as SupportCollection;
use IPI\Core\DTO\IndexFilter;
use IPI\Core\Entities\Product;
use IPI\Core\Filters\EloquentIndexQueryBuilder;
use IPI\Core\General\EloquentResponseMetaBuilder;

class GetProducts
{
    public function getProducts(IndexFilter $data, int $inventoryId): array
    {
        $eloquentProductQuery = EloquentProduct::query()->withCreator()->with($data->relationships);
        $queryBuilder = new EloquentIndexQueryBuilder($eloquentProductQuery);
        $eloquentQueryBuilder = $queryBuilder->execute($data, 'products');

        if ($data->type) {
            $eloquentQueryBuilder->where('type', $data->type);
        } else {
            $eloquentQueryBuilder->where('type', '!=', Product::TYPE_AWAITING_PROCUREMENT);
        }

        if ($inventoryId !== 0) {
            $eloquentQueryBuilder->whereInventoryIs($inventoryId);
            $eloquentQueryBuilder->addSelect('quantity', 'inventory_products.quantity');

            if ($data->type === 'material') {
                $eloquentQueryBuilder->where('quantity', '>', 0);
            }
        }

        if ($data->paginateResult) {
            $purchaseOrders = $eloquentQueryBuilder->paginate($data->perPage);
            $responseMetaBuilder = new EloquentResponseMetaBuilder($purchaseOrders);

            return [
                $this->prepareProducts($purchaseOrders->getCollection()),
                $responseMetaBuilder->execute()
            ];
        }

        $purchaseOrders = $eloquentQueryBuilder->get();
        $purchaseOrders = $this->prepareProducts($purchaseOrders);

        return [$purchaseOrders, []];
    }

    private function prepareProducts(EloquentCollection|SupportCollection $collection): array
    {
        $products = [];

        foreach ($collection as $item) {
            $product = new Product($item->id);
            $product->setFromArray($item->toArray());
            $product->setProductTags($item->productTags->toArray());

            $products[] = $product;
        }

        return $products;
    }
}
