<?php

namespace IPI\Core\Product;

use App\Models\Product as ProductEloquent;
use IPI\Core\DTO\UpdateProductData;
use IPI\Core\Entities\Product;

class UpdateSingleProduct
{
    private VerifyInventoryProductThreshold $inventoryProductThreshold;
    private const UPDATABLE = [
        'product_code',
        'description',
        'type_code',
        'packaging_size',
        'name',
        'unit_cost',
        'threshold',
    ];

    public function __construct(VerifyInventoryProductThreshold $inventoryProductThreshold)
    {
        $this->inventoryProductThreshold = $inventoryProductThreshold;
    }

    public function updateProduct(UpdateProductData $data, string $uuid, int $inventoryId): Product
    {
        $productEloquent = ProductEloquent::query()->where('uuid', $uuid)->first();
        $values = get_object_vars($data);

        foreach ($values as $key => $value) {
            if ($value === null) {
                continue;
            }

            $key = $this->formatKey($key);
            if (in_array($key, self::UPDATABLE)) {
                [$modelKey, $value] = $this->formatValue($key, $value);
                $productEloquent->$modelKey = $value;
            }
        }

        if (isset($data->quantity)) {
            $productEloquent->inventories()->where('inventories.id', $inventoryId)->update([
                'quantity' => $data->quantity
            ]);
        }

        if (isset($data->productTagId)) {
            $productEloquent->productTags()->sync([$data->productTagId]);
        }

        if (isset($data->requesterCustomerId)) {
            $productEloquent->requesterCustomer()->associate($data->requesterCustomerId);
        }

        $productEloquent->save();
        $this->inventoryProductThreshold->verify($productEloquent->id, $inventoryId);

        $product = new Product($productEloquent->id);
        $product->setFromArray($productEloquent->toArray());

        return $product;
    }

    private function formatValue(string $key, $value): array
    {
        return [$key, $value];
    }

    private function formatKey(string $key): string
    {
        return strtolower(
            preg_replace(
                [
                    '#([A-Z][a-z]*)(\d+[A-Z][a-z]*\d+)#',
                    '#([A-Z]+\d*)([A-Z])#',
                    '#([a-z]+\d*)([A-Z])#',
                    '#([^_\d])([A-Z][a-z])#'
                ],
                '$1_$2',
                $key
            )
        );
    }
}
