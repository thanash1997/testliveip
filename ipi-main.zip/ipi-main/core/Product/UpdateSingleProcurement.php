<?php

namespace IPI\Core\Product;

use App\Models\Product as ProductEloquent;
use App\Models\PurchaseOrder;
use App\Models\PurchaseOrderItem;
use Illuminate\Support\Facades\DB;
use IPI\Core\DTO\CreateProductData;
use IPI\Core\DTO\UpdateProcurementData;
use IPI\Core\Entities\Procurement;
use IPI\Core\Entities\Product;

class UpdateSingleProcurement
{
    private ProductCreator $productCreator;
    private UpdateProductTotalCost $updateCost;

    private const UPDATABLE
        = [
            'usage',
            'po_number',
            'total_cost',
            'flag_reason',
            'expected_receive_date',
            'status',
            'is_flagged',
        ];

    public function __construct(
        ProductCreator $productCreator,
        UpdateProductTotalCost $updateCost
    ) {
        $this->productCreator = $productCreator;
        $this->updateCost = $updateCost;
    }

    public function updateProcurement(
        UpdateProcurementData $data,
        string $uuid
    ): Procurement {
        $purchaseOrder = PurchaseOrder::query()->where('uuid', $uuid)->first();
        $previousStatus = $purchaseOrder->cancelled_at !== null
            ? Procurement::CANCELLED
            : (
            $purchaseOrder->fulfilled_at !== null ? Procurement::FULFILLED
                : Procurement::PENDING
            );

        return DB::transaction(
            function () use ($purchaseOrder, $previousStatus, $data) {
                $values = get_object_vars($data);

                foreach ($values as $key => $value) {
                    if ($value === null) {
                        continue;
                    }

                    $key = $this->formatKey($key);
                    if (in_array($key, self::UPDATABLE)) {
                        if ($key === 'status' && $value === 'pending') {
                            $purchaseOrder->cancelled_at = null;
                            $purchaseOrder->fulfilled_at = null;
                            continue;
                        }

                        if ($key === 'status' && $value === 'fulfilled'
                            && $previousStatus === Procurement::CANCELLED
                        ) {
                            $purchaseOrder->cancelled_at = null;
                        }

                        [$modelKey, $value] = $this->formatValue($key, $value);
                        $purchaseOrder->$modelKey = $value;
                    }
                }

                if (isset($data->supplierId)) {
                    $purchaseOrder->supplier()->associate($data->supplierId);
                }

                if (isset($data->destinationId)) {
                    $purchaseOrder->destination()->associate(
                        $data->destinationId
                    );
                }

                $purchaseOrder->save();

                if (isset($data->remark)) {
                    $purchaseOrder->remarks()->create(['body' => $data->remark]
                    );
                }

                $newPurchaseOrderItems = [];
                $productsQuantity = [];
                $productsUnitCost = [];

                foreach ($data->purchaseOrderItems as $purchaseOrderItem) {
                    $existingProductId = $purchaseOrderItem->productId ??
                        ProductEloquent::query()->where(
                            'product_code',
                            $purchaseOrderItem->productCode
                        )->first()->id ?? null;

                    if ($existingProductId) {
                        $newPurchaseOrderItem
                            = $purchaseOrder->purchaseOrderItems()->where(
                            'product_id',
                            $existingProductId
                        )->first();

                        if ($newPurchaseOrderItem) {
                            $newPurchaseOrderItem->update([
                                'quantity' => $purchaseOrderItem->quantity,
                                'packaging_size' => $purchaseOrderItem->packagingSize,
                                'description' => $purchaseOrderItem->description,
                                'total_cost' => $purchaseOrderItem->totalCost,
                                'unit_cost' => $purchaseOrderItem->unitCost,
                            ]);
                        } else {
                            $newPurchaseOrderItem = new PurchaseOrderItem([
                                'quantity' => $purchaseOrderItem->quantity,
                                'packaging_size' => $purchaseOrderItem->packagingSize,
                                'description' => $purchaseOrderItem->description,
                                'total_cost' => $purchaseOrderItem->totalCost,
                                'unit_cost' => $purchaseOrderItem->unitCost,
                            ]);

                            $newPurchaseOrderItem->product()->associate(
                                $existingProductId
                            );
                            $newPurchaseOrderItem->purchaseOrder()->associate(
                                $purchaseOrder
                            );
                            $newPurchaseOrderItem->save();
                        }

                        $productsQuantity[$existingProductId]
                            = $purchaseOrderItem->quantity;
                        $productsUnitCost[$existingProductId]
                            = $purchaseOrderItem->unitCost;
                    } else {
                        $createProductData = new CreateProductData();
                        $createProductData->productCode
                            = $purchaseOrderItem->productCode;
                        $createProductData->quantity
                            = $purchaseOrderItem->quantity;
                        $createProductData->packagingSize
                            = $purchaseOrderItem->packagingSize;
                        $createProductData->description
                            = $purchaseOrderItem->description;
                        $createProductData->unitCost
                            = $purchaseOrderItem->unitCost;
                        $createProductData->quantity = 0;
                        $createProductData->type
                            = Product::TYPE_AWAITING_PROCUREMENT;

                        $product = $this->productCreator->createProduct(
                            $createProductData,
                            false
                        );

                        $newPurchaseOrderItem = new PurchaseOrderItem([
                            'quantity' => $purchaseOrderItem->quantity,
                            'packaging_size' => $purchaseOrderItem->packagingSize,
                            'description' => $purchaseOrderItem->description,
                            'total_cost' => $purchaseOrderItem->totalCost,
                            'unit_cost' => $purchaseOrderItem->unitCost,
                        ]);
                        $newPurchaseOrderItem->product()->associate(
                            $product->id
                        );
                        $newPurchaseOrderItem->purchaseOrder()->associate(
                            $purchaseOrder
                        );
                        $newPurchaseOrderItem->save();

                        $productsQuantity[$product->id]
                            = $purchaseOrderItem->quantity;
                        $productsUnitCost[$product->id]
                            = $purchaseOrderItem->unitCost;
                    }

                    $newPurchaseOrderItem->load('product');
                    array_push(
                        $newPurchaseOrderItems,
                        $newPurchaseOrderItem->toArray()
                    );
                }

                if (!empty($data->status)) {
                    if ($previousStatus === Procurement::FULFILLED
                        && $data->status !== Procurement::FULFILLED
                    ) {
                        $inventory = $purchaseOrder->destination;

                        foreach ($productsQuantity as $productId => $quantity) {
                            $inventory->products()
                                ->where('product_id', $productId)
                                ->decrement('quantity', $quantity);
                            $product = ProductEloquent::query()
                                ->where('id', $productId)
                                ->first();
                            $previousState = $product->audits()
                                ->whereJsonContains(
                                    'new_values',
                                    ['unit_cost' => $productsUnitCost[$productId]]
                                )
                                ->latest()
                                ->first();

                            $product->update([
                                'type' => !empty($previousState)
                                    ? ($previousState->old_values['type'] ??
                                        Product::TYPE_MATERIAL)
                                    : Product::TYPE_AWAITING_PROCUREMENT,
                                'unit_cost' => !empty($previousState)
                                    ? $previousState->old_values['unit_cost']
                                    : $productsUnitCost[$productId],
                            ]);
                        }
                    } else {
                        if ($data->status === Procurement::FULFILLED
                            && $previousStatus !== Procurement::FULFILLED
                        ) {
                            $inventory = $purchaseOrder->destination;

                            foreach (
                                $productsQuantity as $productId => $quantity
                            ) {
                                $inventory->products()->where(
                                    'product_id',
                                    $productId
                                )
                                    ->increment('quantity', $quantity);
                                $product = ProductEloquent::query()->where(
                                    'id',
                                    $productId
                                )->first();
                                $product->update([
                                    'type' => Product::TYPE_MATERIAL,
                                    'unit_cost' => $productsUnitCost[$productId],
                                ]);
                            }
                        }
                    }
                }
                $this->updateCost->handle(array_keys($productsQuantity));

                $procurement = new Procurement($purchaseOrder->id);
                $procurement->setFromArray($purchaseOrder->toArray());
                $procurement->setProcurementItemFromArray(
                    $newPurchaseOrderItems
                );

                return $procurement;
            }
        );
    }

    private function formatValue(string $key, $value)
    {
        if ($key === 'is_flagged') {
            if ($value === true) {
                return ['flagged_at', now()];
            }

            return ['flagged_at', null];
        }

        if ($key === 'status') {
            $hashMap = [
                Procurement::CANCELLED => 'cancelled_at',
                Procurement::FULFILLED => 'fulfilled_at',
            ];

            return [$hashMap[$value], now()];
        }

        return [$key, $value];
    }

    private function formatKey(string $key): string
    {
        return strtolower(
            preg_replace(
                [
                    '#([A-Z][a-z]*)(\d+[A-Z][a-z]*\d+)#',
                    '#([A-Z]+\d*)([A-Z])#',
                    '#([a-z]+\d*)([A-Z])#',
                    '#([^_\d])([A-Z][a-z])#',
                ],
                '$1_$2',
                $key
            )
        );
    }
}
