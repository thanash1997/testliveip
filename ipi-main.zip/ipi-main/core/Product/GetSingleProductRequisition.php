<?php

namespace IPI\Core\Product;

use App\Models\ProductRequisition as EloquentProductRequisition;
use IPI\Core\Entities\ProductRequisition;

class GetSingleProductRequisition
{
    public function getProductRequisition(string $uuid): ProductRequisition
    {
        $eloquentQueryBuilder = EloquentProductRequisition::query()->with([
            'destination',
            'productRequisitionItems.product',
            'order',
            'audits.user',
            'remarks' => function ($query) {
                $query->withCreator();
            },
        ]);
        $productRequisitionEloquent = $eloquentQueryBuilder->where('uuid', $uuid)->withCreator()->first();

        return $this->prepareProductRequisition($productRequisitionEloquent);
    }

    private function prepareProductRequisition(EloquentProductRequisition $productRequisitionEloquent): ProductRequisition
    {
        $productRequisition = new ProductRequisition($productRequisitionEloquent->id);
        $productRequisition->setFromArray($productRequisitionEloquent->toArray());
        $productRequisition->setItemsFromArray($productRequisitionEloquent->productRequisitionItems->toArray());
        $productRequisition->setAudits($productRequisitionEloquent->audits->toArray());
        $productRequisition->setRemarks($productRequisitionEloquent->remarks->toArray());

        return $productRequisition;
    }
}
