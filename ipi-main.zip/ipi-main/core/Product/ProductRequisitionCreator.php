<?php

namespace IPI\Core\Product;

use App\Models\ProductRequisition as ProductRequisitionEloquent;
use App\Models\ProductRequisitionItem as ProductRequisitionItemEloquent;
use Illuminate\Support\Facades\DB;
use IPI\Core\DTO\CreateProductRequisitionData;
use IPI\Core\Entities\ProductRequisition;

class ProductRequisitionCreator
{
    public function createProductRequisition(CreateProductRequisitionData $data): ProductRequisition
    {
        return DB::transaction(function () use ($data) {
            $productRequisitionEloquent = new ProductRequisitionEloquent([
                'material_requisition_no' => $this->generateRequisitionNumber(),
                'origin' => $data->origin,
                'flag_reason' => $data->isFlagged ? $data->flagReason : null,
                'usage' => $data->usage,
                'flagged_at' => $data->isFlagged ? now() : null,
            ]);
            $productRequisitionEloquent->destination()->associate($data->destinationId);
            $productRequisitionEloquent->order()->associate($data->orderId);
            $productRequisitionEloquent->save();

            $products = [];

            foreach ($data->createProductRequisitionItemData as $item) {
                $products[$item->productId] = [
                    'quantity' => !empty($products[$item->productId])
                        ? $item->quantity + $products[$item->productId]['quantity']
                        : $item->quantity,
                    'packaging_size' => $item->packagingSize,
                    'description' => $item->description,
                ];
            }

            foreach ($products as $productId => $product) {
                $productRequisitionItemEloquent = new ProductRequisitionItemEloquent([
                    'quantity' => $product['quantity'],
                    'packaging_size' => $product['packaging_size'],
                    'description' => $product['description'],
                ]);
                $productRequisitionItemEloquent->productRequisition()->associate($productRequisitionEloquent->id);
                $productRequisitionItemEloquent->product()->associate($productId);
                $productRequisitionItemEloquent->save();
            }

            $productRequisition = new ProductRequisition($productRequisitionEloquent->id);
            $productRequisition->setFromArray($productRequisitionEloquent->toArray());

            return $productRequisition;
        });
    }

    private function generateRequisitionNumber(): string
    {
        $prefix = 'IMR';
        $latestProductRequisition = ProductRequisitionEloquent::query()->orderBy('id', 'desc')->first();

        if ($latestProductRequisition === null) {
            $runningNumber = sprintf("%06d", 1);

            return strtoupper("{$prefix}{$runningNumber}");
        }

        $currentNumber = (int)substr($latestProductRequisition->material_requisition_no, -6);
        $runningNumber = sprintf("%06d", $currentNumber + 1);

        return strtoupper("{$prefix}{$runningNumber}");
    }
}
