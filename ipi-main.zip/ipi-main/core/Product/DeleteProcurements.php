<?php

namespace IPI\Core\Product;

use App\Models\Inventory;
use App\Models\PurchaseOrder;
use Illuminate\Support\Facades\DB;
use IPI\Core\DTO\DeleteResourcesData;

class DeleteProcurements
{
    public function deleteProcurements(DeleteResourcesData $data): array
    {
        $procurements = PurchaseOrder::query()
            ->with(['purchaseOrderItems'])
            ->whereIn('uuid', $data->ids)
            ->get();
        $inventories = Inventory::query()->get();
        $errors = [];

        foreach ($procurements as $procurement) {
            $inventory = $inventories->where('id', $procurement->destination_id)->first();

            foreach ($procurement->purchaseOrderItems as $purchaseOrderItem) {
                $errorExists = DB::table('inventory_products')
                    ->where('product_id', $purchaseOrderItem->product_id)
                    ->where('inventory_id', $inventory->id)
                    ->where('quantity', '<', $purchaseOrderItem->quantity)
                    ->exists();

                if ($errorExists) {
                    $errors[] = "Products from procurement {$procurement->uuid} is already used.";
                }
            }
        }

        if (!empty($errors)) {
            return [['errors' => $errors], 422];
        }

        foreach ($procurements as $procurement) {
            $inventory = $inventories->where('id', $procurement->destination_id)->first();

            foreach ($procurement->purchaseOrderItems as $purchaseOrderItem) {
                DB::table('inventory_products')
                    ->where('product_id', $purchaseOrderItem->product_id)
                    ->where('inventory_id', $inventory->id)
                    ->decrement('quantity', $purchaseOrderItem->quantity);
            }
        }

        foreach ($data->ids as $id) {
            $procurement = PurchaseOrder::query()->where('uuid', $id)->first();
            $procurement->delete();
        }

        return [[], 204];
    }
}
