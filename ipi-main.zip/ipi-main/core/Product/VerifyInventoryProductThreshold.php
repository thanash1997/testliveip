<?php

namespace IPI\Core\Product;

use App\Models\Inventory;
use App\Models\Module;
use App\Models\Product as ProductEloquent;
use IPI\Core\Entities\Product;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use IPI\Core\DTO\CreateNotificationData;
use IPI\Core\General\NotificationCreator;

class VerifyInventoryProductThreshold
{
    private NotificationCreator $notificationCreator;

    public function __construct(NotificationCreator $notificationCreator)
    {
        $this->notificationCreator = $notificationCreator;
    }

    public function verify(int $productId, int $inventoryId): void
    {
        $productQuantity = DB::table('inventory_products')->where('product_id', $productId)
                ->where('inventory_id', $inventoryId)->value('quantity') ?? 0;
        $product = ProductEloquent::query()->where('id', $productId)->first();

        if ($productQuantity <= $product->threshold && $product->type === Product::TYPE_MATERIAL) {
            $this->sendNotification($product, $inventoryId);
        }
    }

    private function sendNotification(Model $product, int $inventoryId): void
    {
        $inventorySlug = Inventory::query()->where('id', $inventoryId)->value('slug');
        $productCode = $product->product_code;
        $description = "$productCode is low in stock, the item is below the threshold.";

        if ($inventorySlug === Inventory::PRODUCTION) {
            $module = Module::PRODUCTION;
            $viewName = 'production.sub.details';
        } else {
            $module = Module::WAREHOUSE;
            $viewName = 'warehouse.main.details';
        }

        $moduleIds = Module::query()->where('slug', $module)->pluck('id')->toArray();

        $createNotificationData = new CreateNotificationData();
        $createNotificationData->description = $description;
        $createNotificationData->viewActionLink = route($viewName, ['uuid' => $product->uuid]);
        $createNotificationData->moduleIds = $moduleIds;

        $this->notificationCreator->createNotification($createNotificationData);
    }
}
