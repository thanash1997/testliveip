<?php

namespace IPI\Core\Entities;

use Carbon\Carbon;

class ProductRequisition
{
    public const PENDING = 'pending';
    public const APPROVED = 'approved';
    public const REJECTED = 'rejected';
    public const ALL_STATUSES = [
        self::PENDING,
        self::APPROVED,
        self::REJECTED,
    ];

    public int $id;
    public ?int $destinationId;
    public ?int $orderId;
    public ?string $destinationName;
    public ?string $creatorName;
    public ?string $orderBatchNo;
    public string $uuid;
    public string $materialRequisitionNo;
    public string $status;
    public string $usage;
    public string $origin;
    public bool $isFlagged = false;
    public ?string $flagReason;
    public ?int $totalQuantity;
    public Carbon $createdAt;
    public ?Carbon $flaggedAt;
    public ?Carbon $approvedAt;
    public ?Carbon $rejectedAt;

    /** @var Audit[] $audits */
    public ?array $audits = [];

    /** @var Remark[] $remarks */
    public ?array $remarks = [];
    
    /** @var ProductRequisitionItem[] $productRequisitionItems */
    public array $productRequisitionItems;

    public function __construct(int $id)
    {
        $this->id = $id;
    }

    public function setFromArray(array $data): void
    {
        $this->destinationId = $data['destination_id'] ?? null;
        $this->destinationName = isset($data['destination']) ? $data['destination']['display_name'] : null;
        $this->uuid = $data['uuid'];
        $this->materialRequisitionNo = $data['material_requisition_no'];
        $this->usage = $data['usage'];
        $this->origin = $data['origin'];
        $this->isFlagged = isset($data['flagged_at']);
        $this->flagReason = $data['flag_reason'] ?? null;
        $this->creatorName = $data['creator'] ?? null;
        $this->createdAt = Carbon::parse($data['created_at']);
        $this->flaggedAt = isset($data['flagged_at']) ? Carbon::parse($data['flagged_at']) : null;
        $this->approvedAt = isset($data['approved_at']) ? Carbon::parse($data['approved_at']) : null;
        $this->rejectedAt = isset($data['rejected_at']) ? Carbon::parse($data['rejected_at']) : null;
        $this->status = isset($data['rejected_at']) ? self::REJECTED : (isset($data['approved_at']) ?
            self::APPROVED : self::PENDING);
        $this->orderId = isset($data['order']) ? $data['order']['id'] : null;
        $this->orderBatchNo = isset($data['order']) ? $data['order']['batch_no'] : null;
    }

    public function setItemsFromArray(array $data): void
    {
        $productRequisitionItems = [];
        $totalQuantity = 0;

        foreach ($data as $item) {
            $productRequisitionItem = new ProductRequisitionItem($item['id']);
            $productRequisitionItem->setFromArray($item);
            $totalQuantity += $item['quantity'];

            $productRequisitionItems[] = $productRequisitionItem;
        }

        $this->totalQuantity = $totalQuantity;
        $this->productRequisitionItems = $productRequisitionItems;
    }

    public function setAudits(array $audits): void
    {
        foreach ($audits as $audit) {
            $newAudit = new Audit();
            $newAudit->event = $audit['event'];
            $newAudit->userName = $audit['user']['name'];
            $newAudit->createdAt = Carbon::parse($audit['created_at']);
            $newAudit->newValue = $audit['new_values'];
            $newAudit->oldValue = $audit['old_values'];

            $this->audits[] = $newAudit;
        }
    }

    public function setRemarks(array $remarks): void
    {
        foreach ($remarks as $remark) {
            $newRemark = new Remark();
            $newRemark->body = $remark['body'];
            $newRemark->createdAt = Carbon::parse($remark['created_at']);
            $newRemark->userName = $remark['creator'];

            $this->remarks[] = $newRemark;
        }
    }
}
