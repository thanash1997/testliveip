<?php

namespace IPI\Core\Entities;

class Checkpoint
{
    public int $id;
    public string $type;
    public ?string $rangeMin;
    public ?string $rangeMax;
    public ?string $toleranceMin;
    public ?string $toleranceMax;
    public ?string $equipment;
    public ?string $remark;

    public function __construct(int $id)
    {
        $this->id = $id;
    }

    public function setFromArray(array $data): void
    {
        $this->type = $data['type'];
        $this->rangeMin = $data['range_min'] ?? null;
        $this->rangeMax = $data['range_max'] ?? null;
        $this->toleranceMin = $data['tolerance_min'] ?? null;
        $this->toleranceMax = $data['tolerance_max'] ?? null;
        $this->equipment = $data['equipment'] ?? null;
        $this->remark = $data['remark'] ?? null;
    }
}
