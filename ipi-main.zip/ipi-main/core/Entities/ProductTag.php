<?php

namespace IPI\Core\Entities;

class ProductTag
{
    public const FAST_MOVING = 'fast-moving';
    public const NORMAL = 'normal';
    public const UNUSED = 'unused';
    public const UNMOVED = 'unmoved';
    public const ALL_TAGS = [
        self::FAST_MOVING,
        self::NORMAL,
        self::UNUSED,
        self::UNMOVED,
    ];

    public int $id;
    public string $name;
    public string $slug;
}
