<?php

namespace IPI\Core\Entities;

use App\Models\Courier;
use Carbon\Carbon;
use Illuminate\Support\Facades\URL;

class ActivityLog
{
    public const SUB_MODULES = [
        'App\Models\User' => 'User',
        'App\Models\Formula' => 'Formula',
        'App\Models\Product' => 'Inventory',
        'App\Models\Order' => 'Order',
        'App\Models\PurchaseOrder' => 'Procurement',
        'App\Models\Company' => [
            'customer' => 'Customer',
            'supplier' => 'Supplier',
        ],
        'App\Models\ProductRequisition' => 'Internal Material Requisition',
        'App\Models\ExternalDeliveryOrder' => 'External Delivery Order',
        'App\Models\InternalDeliveryOrder' => 'Internal Delivery Order',
        'App\Models\Courier' => 'Courier',
    ];
    private const ACTION_VIEW_URL = [
        'App\Models\User' => '/admin/users/',
        'App\Models\Formula' => '/admin/formulas/',
        'App\Models\Product' => '/admin/warehouse/main/',
        'App\Models\Order' => '/admin/production/orders/',
        'App\Models\PurchaseOrder' => '/admin/warehouse/procurement/',
        'App\Models\Company' => [
            'customer' => '/admin/customers/',
            'supplier' => '/admin/suppliers/',
        ],
        'App\Models\ProductRequisition' => '/admin/production/product-requisitions/',
        'App\Models\ExternalDeliveryOrder' => '/admin/warehouse/external-delivery-orders/',
        'App\Models\InternalDeliveryOrder' => '/admin/warehouse/internal-delivery-orders/',
        'App\Models\Courier' => '/admin/couriers',
    ];
    private const ACTION_VIEW_NAMED_ROUTE = [
        'App\Models\User' => 'user.details',
        'App\Models\Formula' => 'formula.details',
        'App\Models\Product' => [
            'warehouse' => 'warehouse.main.details',
            'production' => 'production.sub.details',
            'sales' => 'production.sub.details',
            'admin' => 'production.sub.details',
        ],
        'App\Models\Order' => 'production.order.details',
        'App\Models\PurchaseOrder' => [
            'warehouse' => 'warehouse.procurement.details',
            'production' => 'production.procurement.details',
            'sales' => 'production.procurement.details',
            'admin' => 'production.procurement.details',
        ],
        'App\Models\Company' => [
            'customer' => 'customer.details',
            'supplier' => 'supplier.details',
        ],
        'App\Models\ProductRequisition' => [
            'warehouse' => 'warehouse.product-requisitions.details',
            'production' => 'production.product-requisitions.details',
            'sales' => 'production.product-requisitions.details',
            'admin' => 'production.product-requisitions.details',
        ],
        'App\Models\ExternalDeliveryOrder' => 'warehouse.external-do.details',
        'App\Models\InternalDeliveryOrder' => [
            'warehouse' => 'warehouse.internal-do.details',
            'production' => 'production.internal-do.details',
            'sales' => 'production.internal-do.details',
            'admin' => 'production.internal-do.details',
        ],
        'App\Models\Courier' => 'couriers.update',
    ];
    public const EVENTS_DESCRIPTION = [
        'created' => 'Add New',
        'updated' => 'Edit',
        'deleted' => 'Delete',
    ];
    public const EVENTS_NAME = [
        'created' => 'create',
        'updated' => 'edit',
        'deleted' => 'delete',
    ];
    public ?string $userName;
    public ?string $userRole;
    public ?string $department;
    public string $subModule;
    public string $event;
    public ?string $actionSourceUrl;
    public Carbon $createdAt;

    public function setFromArray(array $data, $departmentName): void
    {
        $model = $data['auditable_type'];
        $hasSoftDelete = in_array('Illuminate\Database\Eloquent\SoftDeletes', class_uses($model));
        $modelData = $hasSoftDelete
            ? $model::query()->withTrashed()->find($data['auditable_id'])
            : $model::query()->find($data['auditable_id']);
        $uuid = $modelData->uuid ?? null;
        $type = $model === 'App\Models\Company' ? $modelData->type : null;
        $routeName = $type
            ? self::ACTION_VIEW_NAMED_ROUTE[$data['auditable_type']][$type]
            : (
            $departmentName
                ? self::ACTION_VIEW_NAMED_ROUTE[$data['auditable_type']][$departmentName] ??
                self::ACTION_VIEW_NAMED_ROUTE[$data['auditable_type']]
                : self::ACTION_VIEW_NAMED_ROUTE[$data['auditable_type']]
            );
        $fullUrl = null;

        if ($hasSoftDelete && $modelData->trashed()) {
            $fullUrl = URL::temporarySignedRoute(
                $routeName, now()->addMinutes(30), ['uuid' => $uuid]
            );
        } elseif ($uuid !== null) {
            $fullUrl = route($routeName, ['uuid' => $uuid]);
        } elseif ($model === Courier::class) {
            $fullUrl = route($routeName, ['id' => $modelData->id]);
        }

        $eventModule = $type
            ? self::SUB_MODULES[$data['auditable_type']][$type]
            : (self::SUB_MODULES[$data['auditable_type']] ?? '');
        $eventDescription = self::EVENTS_DESCRIPTION[$data['event']] ?? '';

        $this->userName = $data['user']['name'] ?? null;
        $this->userRole = $data['user']['roles'][0]['name'] ?? null;
        $this->createdAt = Carbon::parse($data['created_at']);
        $this->event = self::EVENTS_NAME[$data['event']];
        $this->department = $data['user']['department']['name'] ?? null;
        $this->subModule = "$eventDescription $eventModule";
        $this->actionSourceUrl = $fullUrl;
    }
}
