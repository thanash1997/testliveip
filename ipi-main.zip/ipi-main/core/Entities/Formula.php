<?php

namespace IPI\Core\Entities;

use Carbon\Carbon;

class Formula
{
    public const PENDING = 'pending';
    public const APPROVED = 'approved';
    public const REJECTED = 'rejected';

    public int $id;
    public int $engineerId;
    public int $formulaTagId;
    public int $formulaTypeId;
    public string $uuid;
    public int $totalCost;
    public ?string $creatorName;
    public ?string $engineerName;
    public ?string $formulaTag;
    public ?string $remark;
    public ?Carbon $createdAt;
    public ?Carbon $updatedAt;
    public ?Carbon $approvedAt;
    public ?Carbon $rejectedAt;
    public string $status;

    public Product $product;

    /** @var Checkpoint[] $checkpoints */
    public array $checkpoints;

    /** @var IngredientList[] $ingredientLists */
    public array $ingredientLists;

    public function __construct(int $id)
    {
        $this->id = $id;
    }
}
