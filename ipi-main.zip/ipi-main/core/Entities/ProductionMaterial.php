<?php

namespace IPI\Core\Entities;

class ProductionMaterial
{
    public int $id;
    public int $productId;
    public string $productCode;
    public float $totalCost;
    public float $percentage;
    public float $quantity;

    public function __construct(int $id)
    {
        $this->id = $id;
    }
}
