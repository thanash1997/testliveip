<?php

namespace IPI\Core\Entities;

use Carbon\Carbon;

class FormulaTag
{
    public int $id;
    public string $name;
    public string $slug;
    public ?Carbon $createdAt;

    public function __construct(int $id)
    {
        $this->id = $id;
    }

    public function setFromArray(array $data): void
    {
        $this->name = $data['name'];
        $this->slug = $data['slug'];
        $this->createdAt = isset($data['created_at']) ? Carbon::parse($data['created_at']) : null;
    }
}
