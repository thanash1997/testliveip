<?php

namespace IPI\Core\Entities;

class File
{
    public string $uuid;
    public string $fileName;

    public function setFromArray(array $data)
    {
        $this->uuid = $data['uuid'];
        $this->fileName = $data['file_name'];
    }
}
