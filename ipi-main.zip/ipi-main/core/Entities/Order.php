<?php

namespace IPI\Core\Entities;

use Carbon\Carbon;

class Order
{
    public const STATUS_PENDING = 'pending';
    public const STATUS_PENDING_MATERIAL = 'pending_material';
    public const STATUS_PENDING_PLANNING = 'pending_planning';
    public const STATUS_IN_PRODUCTION = 'in_production';
    public const STATUS_COMPLETED = 'completed';
    public const STATUS_CANCELLED = 'cancelled';
    public const STATUS_HALTED = 'halted';
    public const ALL_STATUSES = [
        self::STATUS_PENDING,
        self::STATUS_PENDING_MATERIAL,
        self::STATUS_PENDING_PLANNING,
        self::STATUS_IN_PRODUCTION,
        self::STATUS_COMPLETED,
        self::STATUS_CANCELLED,
        self::STATUS_HALTED,
    ];
    public const STARTING_STATUSES = [
        self::STATUS_PENDING,
        self::STATUS_PENDING_MATERIAL,
        self::STATUS_PENDING_PLANNING,
    ];
    public const CANCELLING_STATUSES = [
        self::STATUS_CANCELLED,
        self::STATUS_HALTED,
    ];

    public int $id;
    public int $picId;
    public int $shipmentId;
    public int $contactPersonId;
    public ?string $creatorName;
    public ?string $picName;
    public string $uuid;
    public int $totalCost;
    public string $batchNo;
    public string $status = self::STATUS_PENDING;
    public ?string $description;
    public Company $customer;
    public Carbon $estimatedDeliveredAt;
    public Carbon $createdAt;
    public Shipment $shipment;

    /** @var Audit[] $audits */
    public ?array $audits = [];

    /** @var OrderItem[] $orderItems */
    public array $orderItems;

    /** @var File[] $files */
    public array $files = [];

    public function __construct(int $id)
    {
        $this->id = $id;
    }

    public function setFromArray(array $data)
    {
        $this->uuid = $data['uuid'];
        $this->picId = $data['pic_id'];
        $this->picName = isset($data['person_in_charge']) ? $data['person_in_charge']['name'] : null;
        $this->shipmentId = $data['shipment_id'];
        $this->contactPersonId = $data['contact_person_id'];
        $this->totalCost = $data['total_cost'];
        $this->batchNo = $data['batch_no'];
        $this->description = $data['description'] ?? null;
        $this->status = $this->getStatus($data);
        $this->creatorName = $data['creator'] ?? null;
        $this->estimatedDeliveredAt = Carbon::parse($data['estimated_delivered_at']);
        $this->createdAt = Carbon::parse($data['created_at']);
    }

    public function setAudits(array $audits): void
    {
        foreach ($audits as $audit) {
            $newAudit = new Audit();
            $newAudit->event = $audit['event'];
            $newAudit->userName = $audit['user']['name'];
            $newAudit->createdAt = Carbon::parse($audit['created_at']);
            $newAudit->newValue = $audit['new_values'];
            $newAudit->oldValue = $audit['old_values'];

            $this->audits[] = $newAudit;
        }
    }

    private function getStatus($data): string
    {
        if (isset($data['cancelled_at'])) {
            return self::STATUS_CANCELLED;
        }

        if (isset($data['completed_at'])) {
            return self::STATUS_COMPLETED;
        }

        if (isset($data['halted_at'])) {
            return self::STATUS_HALTED;
        }

        if (isset($data['production_started_at'])) {
            return self::STATUS_IN_PRODUCTION;
        }

        if (isset($data['scheduled_for_planning_at'])) {
            return self::STATUS_PENDING_PLANNING;
        }

        if (isset($data['pending_for_material_at'])) {
            return self::STATUS_PENDING_MATERIAL;
        }

        return self::STATUS_PENDING;
    }
}
