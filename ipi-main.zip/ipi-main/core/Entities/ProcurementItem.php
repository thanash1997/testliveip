<?php

namespace IPI\Core\Entities;

class ProcurementItem
{
    public int $id;
    public string $productCode;
    public int $productId;
    public float $quantity;
    public string $packagingSize;
    public string $description;
    public int $totalCost;
    public int $unitCost;
}
