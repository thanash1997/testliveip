<?php

namespace IPI\Core\Entities;

class Company
{
    public int $id;
    public string $uuid;
    public string $name;
    public string $companyCode;
}
