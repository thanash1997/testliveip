<?php

namespace IPI\Core\Entities;

use Carbon\Carbon;

class Notification
{
    public int $id;
    public string $description;
    public ?string $viewActionLink;
    public ?string $approvalAction;
    public ?string $rejectionAction;
    public Carbon $createdAt;
    public ?Carbon $readAt;
    public ?Carbon $actionTakenAt;
    public ?string $moduleName;

    public function __construct(int $id)
    {
        $this->id = $id;
    }

    public function setFromArray(array $data, string $type = 'with-approval'): void
    {
        $this->description = $data['description'];
        $this->createdAt = Carbon::parse($data['created_at']);
        $this->readAt = isset($data['read_at']) ? Carbon::parse($data['read_at']) : null;
        $this->actionTakenAt = isset($data['action_taken_at']) ? Carbon::parse($data['action_taken_at']) : null;
        $this->viewActionLink = $data['view_action_link'];
        $this->moduleName = isset($data['modules']) && count($data['modules']) > 0 ? $data['modules'][0]['name'] : null;

        if ($type === 'with-approval') {
            $this->approvalAction = $data['approval_action'];
            $this->rejectionAction = $data['rejection_action'];
        }
    }
}
