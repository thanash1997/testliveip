<?php

namespace IPI\Core\Entities;

use Carbon\Carbon;

class ExternalDeliveryOrder
{
    public const STATUS_PENDING = 'pending';
    public const STATUS_CANCELLED = 'cancelled';
    public const STATUS_FULFILLED = 'fulfilled';
    public const ALL_STATUSES = [
        self::STATUS_PENDING,
        self::STATUS_CANCELLED,
        self::STATUS_FULFILLED,
    ];

    public int $id;
    public string $uuid;
    public string $deliveryOrderNo;
    public ?int $customerId;
    public ?string $customerName;
    public ?int $addressId;
    public ?string $addressName;
    public ?string $creatorName;
    public ?string $batchNo;
    public ?string $courierName;
    public ?string $vehicleNo;
    public ?string $trackingNo;
    public ?string $receiptNo;
    public ?string $description;
    public ?string $flagReason;
    public bool $isFlagged;
    public Carbon $createdAt;
    public Carbon $estimatedDeliveryDate;
    public ?Carbon $deliveredAt;
    public ?Carbon $fulfilledAt;
    public ?Carbon $flaggedAt;
    public string $status;

    /** @var Audit[] $audits */
    public ?array $audits = [];

    /** @var Remark[] $remarks */
    public ?array $remarks = [];

    /** @var ExternalDeliveryOrderItem[] $externalDeliveryOrderItems */
    public array $externalDeliveryOrderItems = [];

    public function __construct(int $id)
    {
        $this->id = $id;
    }

    public function setFromArray(array $data): void
    {
        $this->customerId = $data['customer_id'] ?? null;
        $this->addressId = $data['address_id'] ?? null;
        $this->uuid = $data['uuid'];
        $this->batchNo = $data['batch_no'] ?? null;
        $this->courierName = $data['courier_name'] ?? null;
        $this->vehicleNo = $data['vehicle_no'] ?? null;
        $this->trackingNo = $data['tracking_no'] ?? null;
        $this->receiptNo = $data['receipt_no'] ?? null;
        $this->deliveryOrderNo = $data['delivery_order_no'];
        $this->flagReason = $data['flag_reason'] ?? null;
        $this->description = $data['description'] ?? null;
        $this->estimatedDeliveryDate = Carbon::parse($data['estimated_delivery_date']);
        $this->deliveredAt = isset($data['delivered_at']) ? Carbon::parse($data['delivered_at']) : null;
        $this->fulfilledAt = isset($data['fulfilled_at']) ? Carbon::parse($data['fulfilled_at']) : null;
        $this->flaggedAt = isset($data['flagged_at']) ? Carbon::parse($data['flagged_at']) : null;
        $this->createdAt = Carbon::parse($data['created_at']);
        $this->isFlagged = isset($data['flagged_at']);
        $this->status = isset($data['cancelled_at'])
            ? ExternalDeliveryOrder::STATUS_CANCELLED
            : (isset($data['fulfilled_at']) ? ExternalDeliveryOrder::STATUS_FULFILLED
                : ExternalDeliveryOrder::STATUS_PENDING);
        $this->creatorName = $data['creator'] ?? null;
        $this->customerName = $data['customer']['name'] ?? null;
        $this->addressName = $data['address']['name'] ?? null;
    }

    public function setExternalDeliveryOrderItemFromArray(array $items): void
    {
        $newExternalDeliveryOrderItems = [];
        foreach ($items as $item) {
            $externalDeliveryOrderItem = new ExternalDeliveryOrderItem();
            $externalDeliveryOrderItem->id = $item['id'];
            $externalDeliveryOrderItem->productId = $item['product_id'];
            $externalDeliveryOrderItem->quantity = $item['quantity'];
            $externalDeliveryOrderItem->packagingSize = $item['packaging_size'];
            $externalDeliveryOrderItem->description = $item['description'];
            $externalDeliveryOrderItem->productCode = $item['product']['product_code'];
            $externalDeliveryOrderItem->orderId = $item['order_id'] ?? null;
            $externalDeliveryOrderItem->batchTicketNo = $item['order']['batch_no'] ?? null;

            array_push($newExternalDeliveryOrderItems, $externalDeliveryOrderItem);
        }

        $this->externalDeliveryOrderItems = $newExternalDeliveryOrderItems;
    }

    public function setAudits(array $audits): void
    {
        foreach ($audits as $audit) {
            $newAudit = new Audit();
            $newAudit->event = $audit['event'];
            $newAudit->userName = $audit['user']['name'];
            $newAudit->createdAt = Carbon::parse($audit['created_at']);
            $newAudit->newValue = $audit['new_values'];
            $newAudit->oldValue = $audit['old_values'];

            $this->audits[] = $newAudit;
        }
    }

    public function setRemarks(array $remarks): void
    {
        foreach ($remarks as $remark) {
            $newRemark = new Remark();
            $newRemark->body = $remark['body'];
            $newRemark->createdAt = Carbon::parse($remark['created_at']);
            $newRemark->userName = $remark['creator'];

            $this->remarks[] = $newRemark;
        }
    }
}
