<?php

namespace IPI\Core\Entities;

class ExternalDeliveryOrderItem
{
    public int $id;
    public string $productCode;
    public int $productId;
    public ?int $orderId;
    public ?string $batchTicketNo;
    public float $quantity;
    public string $packagingSize;
    public string $description;
}
