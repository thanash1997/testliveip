<?php

namespace IPI\Core\Entities;

use Carbon\Carbon;

class Remark
{
    public string $body;
    public string $userName;
    public Carbon $createdAt;
}
