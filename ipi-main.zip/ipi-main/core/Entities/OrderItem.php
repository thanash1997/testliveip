<?php

namespace IPI\Core\Entities;

class OrderItem
{
    public int $id;
    public int $productId;
    public string $productCode;
    public float $quantity;
    public float $remainingQuantity;
    public int $totalCost;

    /** @var ProductionMaterial[] */
    public array $productionMaterials = [];

    public function __construct(int $id)
    {
        $this->id = $id;
    }

    public function setFromArray(array $data)
    {
        $this->productId = $data['product_id'];
        $this->quantity = $data['quantity'];
        $this->remainingQuantity = $data['remaining_quantity'];
        $this->totalCost = $data['total_cost'];
        $this->productCode = $data['product']['product_code'];
    }
}
