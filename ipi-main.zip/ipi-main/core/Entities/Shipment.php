<?php

namespace IPI\Core\Entities;

class Shipment
{
    public int $id;
    public string $name;
    public ?string $receiverName;
    public ?string $email;

    public function __construct(int $id)
    {
        $this->id = $id;
    }
}
