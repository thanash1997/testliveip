<?php

namespace IPI\Core\Entities;

class IngredientList
{
    public int $id;
    public int $totalCost;
    public int $position;
    public ?string $remark;

    /** @var IngredientItem[] $ingredientItems */
    public array $ingredientItems;

    public function __construct(int $id)
    {
        $this->id = $id;
    }
}
