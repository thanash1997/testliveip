<?php

namespace IPI\Core\Entities;

use Carbon\Carbon;

class InternalDeliveryOrder
{
    public const PENDING = 'pending';
    public const DELIVERED = 'delivered';
    public const FULFILLED = 'fulfilled';
    public const ALL_STATUSES = [
        self::PENDING,
        self::DELIVERED,
        self::FULFILLED,
    ];

    public int $id;
    public ?int $picId;
    public ?int $inventoryId;
    public ?int $destinationId;
    public string $uuid;
    public string $usage;
    public ?string $creatorName;
    public ?string $picName;
    public ?string $destinationName;
    public ?string $description;
    public ?string $batchNo;
    public string $deliveryOrderNo;
    public ?string $flagReason;
    public bool $isFlagged;
    public string $status;
    public Carbon $createdAt;
    public Carbon $estimatedDeliveryDate;
    public ?Carbon $deliveredAt;
    public ?Carbon $fulfilledAt;
    public ?Carbon $flaggedAt;

    /** @var Audit[] $audits */
    public ?array $audits = [];

    /** @var Remark[] $remarks */
    public ?array $remarks = [];

    /** @var InternalDeliveryOrderItem[] $internalDeliveryOrderItems */
    public array $internalDeliveryOrderItems = [];

    public function __construct(int $id)
    {
        $this->id = $id;
    }

    public function setFromArray(array $data): void
    {
        $this->destinationId = $data['destination_id'] ?? null;
        $this->uuid = $data['uuid'];
        $this->usage = $data['usage'];
        $this->batchNo = $data['batch_no'] ?? null;
        $this->deliveryOrderNo = $data['delivery_order_no'];
        $this->flagReason = $data['flag_reason'] ?? null;
        $this->description = $data['description'] ?? null;
        $this->estimatedDeliveryDate = Carbon::parse($data['estimated_delivery_date']);
        $this->deliveredAt = isset($data['delivered_at']) ? Carbon::parse($data['delivered_at']) : null;
        $this->fulfilledAt = isset($data['fulfilled_at']) ? Carbon::parse($data['fulfilled_at']) : null;
        $this->flaggedAt = isset($data['flagged_at']) ? Carbon::parse($data['flagged_at']) : null;
        $this->createdAt = Carbon::parse($data['created_at']);
        $this->isFlagged = isset($data['flagged_at']);
        $this->status = isset($data['fulfilled_at']) ? InternalDeliveryOrder::FULFILLED :
            (isset($data['delivered_at']) ? InternalDeliveryOrder::DELIVERED : InternalDeliveryOrder::PENDING);
        $this->creatorName = $data['creator'] ?? null;
        $this->picId = isset($data['person_in_charge']) ? $data['person_in_charge']['id'] : null;
        $this->picName = isset($data['person_in_charge']) ? $data['person_in_charge']['name'] : null;
        $this->destinationName = isset($data['destination']) ? $data['destination']['display_name'] : null;
    }

    public function setInternalDeliveryOrderItemFromArray(array $items): void
    {
        $newInternalDeliveryOrderItems = [];
        foreach ($items as $item) {
            $internalDeliveryOrderItem = new InternalDeliveryOrderItem();
            $internalDeliveryOrderItem->id = $item['id'];
            $internalDeliveryOrderItem->productId = $item['product_id'];
            $internalDeliveryOrderItem->quantity = $item['quantity'];
            $internalDeliveryOrderItem->packagingSize = $item['packaging_size'];
            $internalDeliveryOrderItem->description = $item['description'];
            $internalDeliveryOrderItem->productCode = $item['product']['product_code'];

            array_push($newInternalDeliveryOrderItems, $internalDeliveryOrderItem);
        }

        $this->internalDeliveryOrderItems = $newInternalDeliveryOrderItems;
    }

    public function setAudits(array $audits): void
    {
        foreach ($audits as $audit) {
            $newAudit = new Audit();
            $newAudit->event = $audit['event'];
            $newAudit->userName = $audit['user']['name'];
            $newAudit->createdAt = Carbon::parse($audit['created_at']);
            $newAudit->newValue = $audit['new_values'];
            $newAudit->oldValue = $audit['old_values'];

            $this->audits[] = $newAudit;
        }
    }

    public function setRemarks(array $remarks): void
    {
        foreach ($remarks as $remark) {
            $newRemark = new Remark();
            $newRemark->body = $remark['body'];
            $newRemark->createdAt = Carbon::parse($remark['created_at']);
            $newRemark->userName = $remark['creator'];

            $this->remarks[] = $newRemark;
        }
    }
}
