<?php

namespace IPI\Core\Entities;

class ProductRequisitionItem
{
    public int $id;
    public string $productCode;
    public int $productId;
    public float $quantity;
    public string $packagingSize;
    public ?string $description;

    public function __construct(int $id)
    {
        $this->id = $id;
    }

    public function setFromArray(array $data): void
    {
        $this->productCode = $data['product']['product_code'];
        $this->productId = $data['product']['id'];
        $this->quantity = $data['quantity'];
        $this->packagingSize = $data['packaging_size'];
        $this->description = $data['description'];
    }
}
