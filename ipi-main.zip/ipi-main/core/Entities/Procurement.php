<?php

namespace IPI\Core\Entities;

use Carbon\Carbon;

class Procurement
{
    public const PENDING = 'pending';
    public const CANCELLED = 'cancelled';
    public const FULFILLED = 'fulfilled';
    public const ALL_STATUSES = [
        self::PENDING,
        self::CANCELLED,
        self::FULFILLED,
    ];

    public int $id;
    public ?int $destinationId;
    public ?string $destinationName;
    public string $uuid;
    public string $usage;
    public string $poNumber;
    public ?string $flagReason;
    public ?string $creatorName;
    public bool $isFlagged;
    public int $totalCost;
    public string $status;
    public Carbon $createdAt;
    public Carbon $expectedReceiveDate;
    public ?Carbon $cancelledAt;
    public ?Carbon $fulfilledAt;
    public ?Carbon $flaggedAt;
    public Company $supplier;

    /** @var Audit[] $audits */
    public ?array $audits = [];

    /** @var Remark[] $remarks */
    public ?array $remarks = [];

    /** @var ProcurementItem[] $purchaseOrderItems */
    public array $procurementItems = [];

    public function __construct(int $id)
    {
        $this->id = $id;
    }

    public function setFromArray(array $data): void
    {
        $this->destinationId = $data['destination_id'] ?? null;
        $this->uuid = $data['uuid'];
        $this->usage = $data['usage'];
        $this->poNumber = $data['po_number'];
        $this->totalCost = $data['total_cost'];
        $this->flagReason = $data['flag_reason'];
        $this->expectedReceiveDate = Carbon::parse($data['expected_receive_date']);
        $this->cancelledAt = isset($data['cancelled_at']) ? Carbon::parse($data['cancelled_at']) : null;
        $this->fulfilledAt = isset($data['fulfilled_at']) ? Carbon::parse($data['fulfilled_at']) : null;
        $this->flaggedAt = isset($data['flagged_at']) ? Carbon::parse($data['flagged_at']) : null;
        $this->createdAt = Carbon::parse($data['created_at']);
        $this->isFlagged = isset($data['flagged_at']);
        $this->status = isset($data['cancelled_at']) ? Procurement::CANCELLED :
            (isset($data['fulfilled_at']) ? Procurement::FULFILLED: Procurement::PENDING);
        $this->creatorName = $data['creator'] ?? null;
        $this->destinationName = isset($data['destination']) ? $data['destination']['display_name'] : null;
    }

    public function setProcurementItemFromArray(array $items): void
    {
        $newProcurementItems = [];
        foreach ($items as $item) {
            $procurementItem = new ProcurementItem();
            $procurementItem->id = $item['id'];
            $procurementItem->productId = $item['product_id'];
            $procurementItem->quantity = $item['quantity'];
            $procurementItem->packagingSize = $item['packaging_size'];
            $procurementItem->description = $item['description'];
            $procurementItem->totalCost = $item['total_cost'];
            $procurementItem->unitCost = $item['unit_cost'];
            $procurementItem->productCode = $item['product']['product_code'];

            array_push($newProcurementItems, $procurementItem);
        }

        $this->procurementItems = $newProcurementItems;
    }

    public function setAudits(array $audits): void
    {
        foreach ($audits as $audit) {
            $newAudit = new Audit();
            $newAudit->event = $audit['event'];
            $newAudit->userName = $audit['user']['name'];
            $newAudit->createdAt = Carbon::parse($audit['created_at']);
            $newAudit->newValue = $audit['new_values'];
            $newAudit->oldValue = $audit['old_values'];

            $this->audits[] = $newAudit;
        }
    }

    public function setRemarks(array $remarks): void
    {
        foreach ($remarks as $remark) {
            $newRemark = new Remark();
            $newRemark->body = $remark['body'];
            $newRemark->createdAt = Carbon::parse($remark['created_at']);
            $newRemark->userName = $remark['creator'];

            $this->remarks[] = $newRemark;
        }
    }
}
