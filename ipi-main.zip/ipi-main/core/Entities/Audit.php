<?php

namespace IPI\Core\Entities;

use Carbon\Carbon;

class Audit
{
    public string $event;
    public string $userName;
    public ?array $oldValue;
    public ?array $newValue;
    public Carbon $createdAt;
}
