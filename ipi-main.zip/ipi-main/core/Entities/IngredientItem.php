<?php

namespace IPI\Core\Entities;

class IngredientItem
{
    public int $id;
    public int $productId;
    public int $totalCost;
    public float $percentage;
    public ?string $remark;
    public ?string $productCode;

    public function __construct(int $id)
    {
        $this->id = $id;
    }
}
