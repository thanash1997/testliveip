<?php

namespace IPI\Core\Entities;

use Carbon\Carbon;

class FormulaType
{
    public int $id;
    public string $type;
    public string $displayText;
    public ?Carbon $createdAt;

    public function __construct(int $id)
    {
        $this->id = $id;
    }

    public function setFromArray(array $data): void
    {
        $this->type = $data['type'];
        $this->displayText = $data['display_text'];
        $this->createdAt = isset($data['created_at']) ? Carbon::parse($data['created_at']) : null;
    }
}
