<?php

namespace IPI\Core\Entities;

use Carbon\Carbon;

class Product
{
    public const TYPE_MATERIAL = 'material';
    public const TYPE_FORMULA = 'formula';
    public const TYPE_FORMULA_SAMPLE = 'formula_sample';
    public const TYPE_AWAITING_PROCUREMENT = 'awaiting_procurement';
    public const ALL_TYPES = [
        self::TYPE_FORMULA,
        self::TYPE_MATERIAL,
        self::TYPE_FORMULA_SAMPLE,
        self::TYPE_AWAITING_PROCUREMENT,
    ];

    public int $id;
    public string $uuid;
    public ?string $creatorName;
    public ?int $requesterCustomerId;
    public ?string $requesterCustomerCode;
    public ?string $productCode;
    public float $quantity = 0;
    public ?string $description;
    public ?string $typeCode;
    public ?string $packagingSize;
    public ?int $unitCost;
    public ?string $name;
    public ?int $threshold;
    public string $type;
    public ?Carbon $createdAt;

    /** @var Audit[] $audits */
    public ?array $audits = [];

    /** @var ProductTag[] $productTags */
    public array $productTags = [];

    public function __construct(int $id)
    {
        $this->id = $id;
    }

    public function setFromArray(array $data): void
    {
        $this->uuid = $data['uuid'];
        $this->requesterCustomerId = isset($data['requester_customer']) ? $data['requester_customer']['id'] : null;
        $this->requesterCustomerCode = isset($data['requester_customer']) ? $data['requester_customer']['company_code'] : null;
        $this->productCode = $data['product_code'];
        $this->description = $data['description'];
        $this->name = $data['name'] ?? null;
        $this->unitCost = $data['unit_cost'];
        $this->threshold = $data['threshold'] ?? null;
        $this->packagingSize = $data['packaging_size'];
        $this->type = $data['type'];
        $this->quantity = $data['quantity'] ?? 0;
        $this->creatorName = $data['creator'] ?? null;
        $this->typeCode = $data['type_code'] ?? null;
        $this->createdAt = Carbon::parse($data['created_at']);
    }

    public function setProductTags(array $tags): void
    {
        foreach ($tags as $tag) {
            $productTag = new ProductTag();
            $productTag->id = $tag['id'];
            $productTag->name = $tag['name'];
            $productTag->slug = $tag['slug'];

            array_push($this->productTags, $productTag);
        }
    }

    public function setAudits(array $audits): void
    {
        foreach ($audits as $audit) {
            $newAudit = new Audit();
            $newAudit->event = $audit['event'];
            $newAudit->userName = $audit['user']['name'];
            $newAudit->createdAt = Carbon::parse($audit['created_at']);
            $newAudit->newValue = $audit['new_values'];
            $newAudit->oldValue = $audit['old_values'];

            $this->audits[] = $newAudit;
        }
    }
}
