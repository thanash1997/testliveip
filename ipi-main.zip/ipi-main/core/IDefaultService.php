<?php

namespace IPI\Core;

use Illuminate\Database\Eloquent\Model;

interface IDefaultService
{
    public function handle(): Model;
}
