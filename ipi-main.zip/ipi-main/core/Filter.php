<?php

namespace IPI\Core;

interface Filter
{
    public function getPerPage();
}
