<?php

namespace IPI\Core\Company;

use App\Models\Company;
use App\Models\Shipment;

class ShipmentCreator
{
    private Company $company;

    public function __construct(Company $company)
    {
        $this->company = $company;
    }

    public function storeShipment(array $shipmentDetails, int $phoneNumberId, int $addressId, int $faxNumberId = null): Shipment
    {
        $shipment = new Shipment([
            'name' => $shipmentDetails['name'],
            'email' => $shipmentDetails['email'],
            'receiver_name' => $shipmentDetails['receiver_name'],
        ]);
        $shipment->company()->associate($this->company);
        $shipment->phoneNumber()->associate($phoneNumberId);
        $shipment->faxNumber()->associate($faxNumberId);
        $shipment->address()->associate($addressId);
        $shipment->save();

        return $shipment;
    }
}
