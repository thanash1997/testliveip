<?php

namespace IPI\Core\Company\Filters;

use IPI\Core\Filter;

class CompanyFilter implements Filter
{
    private array $parameters;

    public function __construct(array $parameters)
    {
        $this->parameters = $parameters;
    }

    public function getPerPage()
    {
        return $this->parameters['per_page'] ?? 20;
    }

    public function getCompanyType()
    {
        return $this->parameters['type'] ?? null;
    }

    public function getSearchQuery()
    {
        return $this->parameters['search_query'] ?? null;
    }

    public function getSortOrder()
    {
        return $this->parameters['sort_order'] ?? null;
    }

    public function getDateRange()
    {
        return $this->parameters['date_range'] ?? null;
    }
}
