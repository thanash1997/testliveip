<?php

namespace IPI\Core\Company;

use App\Models\Company;
use App\Models\Employee;
use App\Models\User;

class EmployeeCreator
{
    private Company $company;

    public function __construct(Company $company)
    {
        $this->company = $company;
    }

    public function storeEmployee(array $employeeDetails, int $phoneNumberId, int $faxNumberId = null): Employee
    {
        $user = User::firstOrCreate(
            ['email' => $employeeDetails['email']],
            ['name' => $employeeDetails['name']]
        );

        $employee = new Employee(['designation' => $employeeDetails['designation']]);
        $employee->phoneNumber()->associate($phoneNumberId);
        $employee->faxNumber()->associate($faxNumberId);
        $employee->user()->associate($user);
        $employee->company()->associate($this->company);
        $employee->save();

        return $employee;
    }
}
