<?php

namespace IPI\Core\Company;

use App\Models\Company;

class CompanyCreator
{
    public function storeCompany(array $companyDetails, int $phoneNumberId, int $addressId, string $type, int $faxNumberId = null): Company
    {
        $company = new Company([
            'company_code' => $this->generateCompanyCode($companyDetails['name'], $type),
            'name' => $companyDetails['name'],
            'registration_number' => $companyDetails['registration_number'],
            'website_url' => $companyDetails['website_url'] ?? null,
            'sst_number' => $companyDetails['sst_number'] ?? null,
            'gst_number' => $companyDetails['gst_number'] ?? null,
            'type' => $type,
        ]);
        $company->phoneNumber()->associate($phoneNumberId);
        $company->faxNumber()->associate($faxNumberId);
        $company->address()->associate($addressId);
        $company->save();

        return $company;
    }

    private function generateCompanyCode(string $companyName, string $type): string
    {
        $prefix = strtoupper(substr($companyName, 0, 2)) . strtoupper(substr($type, 0, 1));
        $latestCompany = Company::query()->where('type', $type)->orderBy('id', 'DESC')->first(['company_code']);

        if ($latestCompany === null) {
            $runningNumber = sprintf("%04d", 1);

            return strtoupper("{$prefix}{$runningNumber}");
        }

        $currentNumber = (int)substr($latestCompany->company_code, -4);
        $runningNumber = sprintf("%04d", $currentNumber + 1);

        return strtoupper("{$prefix}{$runningNumber}");
    }
}
