<?php

namespace IPI\Core\Company\Services;

use App\Models\Address;
use App\Models\Company;
use Carbon\Carbon;
use IPI\Core\Company\CompanyCreator;
use IPI\Core\Company\EmployeeCreator;
use IPI\Core\Company\Filters\CompanyFilter;
use IPI\Core\Company\PaymentAccountCreator;
use IPI\Core\Company\ShipmentCreator;
use IPI\Core\General\PhoneNumberCreator;

class CompanyService
{
    public function getCompanies(CompanyFilter $filters)
    {
        $query = Company::query();
        $type = $filters->getCompanyType();
        $searchQuery = $filters->getSearchQuery();
        $sortOrder = $filters->getSortOrder();
        $dateRange = $filters->getDateRange();

        if ($type) {
            $query = $query->where('type', $type);
        }

        if ($searchQuery) {
            $query = $query->where(function ($query) use ($searchQuery) {
                return $query->where('company_code', 'LIKE', "%$searchQuery%")
                    ->orWhere('name', 'LIKE', "%$searchQuery%");
            });
        }

        if ($dateRange) {
            $dateRange[0] = Carbon::parse($dateRange[0])->startOfDay();
            $dateRange[1] = Carbon::parse($dateRange[1])->endOfDay();

            $query = $query->whereBetween('created_at', $dateRange);
        }

        if ($sortOrder) {
            $query = $query->orderBy('id', $sortOrder);
        }

        return $query->with(['phoneNumber', 'shipments.address', 'employees.user'])->paginate($filters->getPerPage());
    }

    public function createCompany(array $parameters)
    {
        $phoneNumberCreator = new PhoneNumberCreator();
        $phoneNumber = $phoneNumberCreator->storePhoneNumber($parameters['phone_dialing_code_id'], $parameters['phone_number']);
        $faxNumber = null;

        if (isset($parameters['fax_number'])) {
            $faxNumber = $phoneNumberCreator->storePhoneNumber($parameters['fax_dialing_code_id'], $parameters['fax_number']);
        }

        $address = new Address([
            'line_1' => $parameters['address']['line_1'],
            'line_2' => $parameters['address']['line_2'] ?? null,
            'postcode' => $parameters['address']['postcode'],
            'state' => $parameters['address']['state'],
            'city' => $parameters['address']['city'],
        ]);
        $address->country()->associate($parameters['address']['country_id']);
        $address->save();

        $companyCreator = new CompanyCreator();
        $company = $companyCreator->storeCompany(
            [
                'name' => $parameters['name'],
                'registration_number' => $parameters['registration_number'],
                'website_url' => $parameters['website_url'],
                'sst_number' => $parameters['sst_number'] ?? null,
                'gst_number' => $parameters['gst_number'] ?? null,
            ],
            $phoneNumber->id,
            $address->id,
            $parameters['type'],
            $faxNumber->id ?? null
        );

        $employeeCreator = new EmployeeCreator($company);
        $employees = $parameters['employees'];

        foreach ($employees as $employeeDetails) {
            $employeePhoneNumber = $phoneNumberCreator->storePhoneNumber($employeeDetails['phone_dialing_code_id'], $employeeDetails['phone_number']);
            $employeeFaxNumber = null;

            if (isset($employeeDetails['fax_number'])) {
                $employeeFaxNumber = $phoneNumberCreator->storePhoneNumber($employeeDetails['fax_dialing_code_id'], $employeeDetails['fax_number']);
            }

            $employeeCreator->storeEmployee([
                'name' => $employeeDetails['name'],
                'email' => $employeeDetails['email'],
                'designation' => $employeeDetails['designation'] ?? null,
            ], $employeePhoneNumber->id, $employeeFaxNumber?->id);
        }

        $paymentAccountCreator = new PaymentAccountCreator($company);
        $paymentAccounts = $parameters['payment_accounts'];

        foreach ($paymentAccounts as $paymentAccountDetails) {
            $paymentAccountPhoneNumber = $phoneNumberCreator->storePhoneNumber($paymentAccountDetails['phone_dialing_code_id'], $paymentAccountDetails['phone_number']);
            $paymentAccountFaxNumber = null;

            if (isset($paymentAccountDetails['fax_number'])) {
                $paymentAccountFaxNumber = $phoneNumberCreator->storePhoneNumber($paymentAccountDetails['fax_dialing_code_id'], $paymentAccountDetails['fax_number']);
            }

            $addressDetails = $paymentAccountDetails['address'];
            $address = new Address([
                'line_1' => $addressDetails['line_1'],
                'line_2' => $addressDetails['line_2'] ?? null,
                'postcode' => $addressDetails['postcode'],
                'state' => $addressDetails['state'],
                'city' => $addressDetails['city'],
            ]);
            $address->country()->associate($addressDetails['country_id']);
            $address->save();

            $paymentAccountCreator->storePaymentAccount(
                [
                    'account_name' => $paymentAccountDetails['name'],
                    'email' => $paymentAccountDetails['email'],
                    'account_holder_name' => $paymentAccountDetails['account_holder_name'],
                    'account_number' => $paymentAccountDetails['account_number'],
                ],
                $paymentAccountDetails['payment_method_id'] ?? null,
                $paymentAccountPhoneNumber->id,
                $paymentAccountDetails['bank_id'],
                $address->id,
                $paymentAccountFaxNumber?->id
            );
        }

        $shipmentCreator = new ShipmentCreator($company);
        $shipments = $parameters['shipment_details'];

        foreach ($shipments as $shipmentDetails) {
            $shipmentPhoneNumber = $phoneNumberCreator->storePhoneNumber($shipmentDetails['phone_dialing_code_id'], $shipmentDetails['phone_number']);
            $shipmentFaxNumber = null;

            if (isset($shipmentDetails['fax_number'])) {
                $shipmentFaxNumber = $phoneNumberCreator->storePhoneNumber($shipmentDetails['fax_dialing_code_id'], $shipmentDetails['fax_number']);
            }

            $addressDetails = $shipmentDetails['address'];
            $address = new Address([
                'line_1' => $addressDetails['line_1'],
                'line_2' => $addressDetails['line_2'] ?? null,
                'postcode' => $addressDetails['postcode'],
                'state' => $addressDetails['state'],
                'city' => $addressDetails['city'],
            ]);
            $address->country()->associate($addressDetails['country_id']);
            $address->save();

            $shipmentCreator->storeShipment(
                [
                    'name' => $shipmentDetails['name'],
                    'email' => $shipmentDetails['email'],
                    'receiver_name' => $shipmentDetails['receiver_name'],
                ],
                $shipmentPhoneNumber->id,
                $address->id,
                $shipmentFaxNumber?->id
            );
        }

        return $company;
    }
}
