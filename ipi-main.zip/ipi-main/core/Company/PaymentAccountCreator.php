<?php

namespace IPI\Core\Company;

use App\Models\Company;
use App\Models\PaymentAccount;

class PaymentAccountCreator
{
    private Company $company;

    public function __construct(Company $company)
    {
        $this->company = $company;
    }

    public function storePaymentAccount(
        array $paymentAccountDetails,
        ?int $paymentMethodId,
        int $phoneNumberId,
        int $bankId,
        int $addressId,
        int $faxNumberId = null,
    ): PaymentAccount {
        $paymentAccount = new PaymentAccount($paymentAccountDetails);
        $paymentAccount->company()->associate($this->company);

        if ($paymentMethodId) {
            $paymentAccount->paymentMethod()->associate($paymentMethodId);
        }

        $paymentAccount->phoneNumber()->associate($phoneNumberId);
        $paymentAccount->faxNumber()->associate($faxNumberId);
        $paymentAccount->bank()->associate($bankId);
        $paymentAccount->address()->associate($addressId);
        $paymentAccount->save();

        return $paymentAccount;
    }
}
