<?php

namespace IPI\Core\User;

use App\Models\User;

class UserDepartmentAssigner
{
    private User $user;

    public function __construct(User $user)
    {
        $this->user = $user;
    }

    public function assignDepartment(int $departmentId): User
    {
        $this->user->department()->associate($departmentId);
        $this->user->save();

        return $this->user;
    }
}
