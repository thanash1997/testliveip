<?php

namespace IPI\Core\User;

use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserCreator
{
    public function storeUser(array $userDetails, $allowedToLogin = true): User
    {
        return User::create([
            'name' => $userDetails['name'],
            'username' => $userDetails['username'] ?? null,
            'email' => $userDetails['email'],
            'password' => isset($userDetails['password']) ? Hash::make($userDetails['password']) : null,
            'can_login' => $allowedToLogin,
        ]);
    }
}
