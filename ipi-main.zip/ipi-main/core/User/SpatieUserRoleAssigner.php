<?php

namespace IPI\Core\User;

use App\Models\User;

class SpatieUserRoleAssigner implements IUserRoleAssigner
{
    private User $user;

    public function setUser(User $user): void
    {
        $this->user = $user;
    }

    public function assignRole(string $roleName): User
    {
        return $this->user->assignRole($roleName);
    }
}
