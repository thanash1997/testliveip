<?php

namespace IPI\Core\User;

use App\Models\User;

interface IUserRoleAssigner
{
    public function setUser(User $user): void;

    public function assignRole(string $roleName): User;
}
