<?php

namespace IPI\Core\Filters;

use Illuminate\Database\Eloquent\Builder;
use IPI\Core\DTO\IndexFilter;
use IPI\Core\Entities\ActivityLog;

class EloquentIndexQueryBuilder
{
    private Builder $queryBuilder;
    private const TABLE_SEARCHABLE = [
        'products' => [
            'product_code' => 'LIKE',
            'description' => 'LIKE',
            'name' => 'LIKE',
        ],
        'formulas' => [
            'products.product_code' => 'LIKE',
            'products.description' => 'LIKE',
            'products.name' => 'LIKE',
        ],
        'internal_delivery_orders' => [
            'delivery_order_no' => 'LIKE',
        ],
        'external_delivery_orders' => [
            'delivery_order_no' => 'LIKE',
        ],
        'orders' => [
            'batch_no' => 'LIKE',
            'description' => 'LIKE',
        ],
        'companies' => [
            'company_code' => 'LIKE',
            'name' => 'LIKE',
            'registration_number' => 'LIKE',
        ],
        'formula_types' => [
            'type' => 'LIKE',
        ],
        'purchase_orders' => [
            'po_number' => 'LIKE',
        ],
        'audits' => [
            'event' => 'LIKE',
        ],
        'product_requisitions' => [
            'material_requisition_no' => 'LIKE',
        ],
        'notifications' => [],
    ];
    private const TABLE_DATE_COLUMN = [
        'products' => 'products.created_at',
        'formulas' => 'products.created_at',
        'internal_delivery_orders' => 'created_at',
        'external_delivery_orders' => 'created_at',
        'orders' => 'created_at',
        'companies' => 'created_at',
        'formula_types' => 'created_at',
        'purchase_orders' => 'created_at',
        'audits' => 'created_at',
        'product_requisitions' => 'created_at',
        'notifications' => 'created_at',
    ];

    public function __construct(Builder $builder)
    {
        $this->queryBuilder = $builder;
    }

    public function execute(IndexFilter $filter, string $table = null): Builder
    {
        $searchQuery = $filter->searchQuery;
        $sortOrder = $filter->sortOrder;
        $startDate = $filter->startDate;
        $endDate = $filter->endDate;

        if ($searchQuery) {
            $this->queryBuilder = $this->queryBuilder->where(function ($query) use ($searchQuery, $table) {
                $searchableColumns = self::TABLE_SEARCHABLE[$table];

                if ($table === 'orders') {
                    $query->orWhereHas('orderItems', function ($query) use ($searchQuery) {
                        return $query->whereHas('product', function ($query) use ($searchQuery) {
                            return $query->where(
                                'products.product_code',
                                'LIKE',
                                $this->formatValue($searchQuery, 'LIKE')
                            );
                        });
                    });

                    $query->orWhereHas('customer', function ($query) use ($searchQuery) {
                        return $query->where('companies.name', 'LIKE', $this->formatValue($searchQuery, 'LIKE'));
                    });
                }

                if ($table === 'audits') {
                    $searchQuery = $searchQuery === 'edit'
                        ? 'update' : ($searchQuery === 'add' ? 'create' : $searchQuery);

                    $map = array_flip(array_map(function ($module) {
                        return strtolower($module);
                    }, ActivityLog::SUB_MODULES));
                    $class = $map[strtolower($searchQuery)] ?? null;

                    if ($class !== null) {
                        $query->orWhere('auditable_type', '=', $class);
                    }
                }

                foreach ($searchableColumns as $searchableColumn => $operator) {
                    $query->orWhere($searchableColumn, $operator, $this->formatValue($searchQuery, $operator));
                }
            });
        }

        if (($startDate !== null && $endDate !== null) || $startDate !== null) {
            $startDate = $startDate->startOfDay();
            $endDate = $endDate->endOfDay();

            $this->queryBuilder = $this->queryBuilder->whereBetween(self::TABLE_DATE_COLUMN[$table], [
                $startDate,
                $endDate,
            ]);
        }

        if ($sortOrder) {
            $tablePrefix = $table ? "$table." : null;
            $this->queryBuilder = $this->queryBuilder->orderBy("{$tablePrefix}id", $sortOrder);
        }

        return $this->queryBuilder;
    }

    private function formatValue($value, $operator): string
    {
        if ($operator === 'LIKE') {
            return "%$value%";
        }

        return $value;
    }
}
