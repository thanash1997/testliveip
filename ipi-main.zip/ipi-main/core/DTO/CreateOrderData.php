<?php

namespace IPI\Core\DTO;

use Carbon\Carbon;

class CreateOrderData
{
    public int $customerId;
    public int $picId;
    public int $shipmentId;
    public int $contactPersonId;
    public ?string $description;
    public int $totalCost;
    public bool $withApproval = false;
    public Carbon $estimatedDeliveredAt;
    public array $files = [];

    /** @var CreateOrderItemData[] $createOrderItems */
    public array $createOrderItems;
}
