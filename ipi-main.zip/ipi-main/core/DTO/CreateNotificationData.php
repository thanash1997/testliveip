<?php

namespace IPI\Core\DTO;

class CreateNotificationData
{
    public array $moduleIds = [];
    public string $description;
    public ?string $viewActionLink;
    public ?string $approvalAction;
    public ?string $rejectionAction;
}
