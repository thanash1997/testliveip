<?php

namespace IPI\Core\DTO;

class CreateProcurementItemData
{
    public ?int $productId;
    public ?string $productCode;
    public float $quantity;
    public string $packagingSize;
    public string $description;
    public float $totalCost;
    public float $unitCost;
}
