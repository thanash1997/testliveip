<?php

namespace IPI\Core\DTO;

class CreateFormulaCheckpointData
{
    public string $type;
    public ?string $rangeMin;
    public ?string $rangeMax;
    public ?string $toleranceMin;
    public ?string $toleranceMax;
    public ?string $equipment;
    public ?string $remark;
}
