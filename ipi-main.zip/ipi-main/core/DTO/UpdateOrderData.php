<?php

namespace IPI\Core\DTO;

use Carbon\Carbon;

class UpdateOrderData
{
    public ?int $customerId;
    public ?int $picId;
    public ?int $shipmentId;
    public ?int $contactPersonId;
    public ?string $description;
    public ?int $totalCost;
    public ?string $status;
    public ?Carbon $estimatedDeliveredAt;
    public ?array $files = [];

    /** @var CreateOrderItemData[] $createOrderItems */
    public ?array $createOrderItems;

    /** @var UpdateProductionMaterialData[] $updateProductionMaterialData */
    public array $updateProductionMaterialData = [];
}
