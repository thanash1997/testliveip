<?php

namespace IPI\Core\DTO;

class UpdateFormulaData
{
    public ?int $engineerId;
    public ?int $requesterCustomerId;
    public ?int $formulaTypeId;
    public ?int $formulaTagId;
    public ?string $productName;
    public ?string $remark;

    /** @var CreateIngredientListsData[] $ingredientLists */
    public array $ingredientLists;

    /** @var CreateFormulaCheckpointData[] $checkpoints */
    public array $checkpoints;
}
