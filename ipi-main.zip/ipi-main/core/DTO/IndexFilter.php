<?php

namespace IPI\Core\DTO;

use Carbon\Carbon;

class IndexFilter
{
    public int $perPage = 20;
    public bool $paginateResult = true;
    public ?string $searchQuery;
    public string $sortOrder = 'desc';
    public ?Carbon $startDate;
    public ?Carbon $endDate;
    public array $relationships = [];
    public ?string $type;
    public ?int $userId;
    public ?string $companyUuid;
    public array $moduleIds = [];
    public ?bool $excludeEmpty;
    public ?string $status;
}
