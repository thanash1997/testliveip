<?php

namespace IPI\Core\DTO;

class CreateIngredientItemData
{
    public ?int $id;
    public ?int $productId;
    public ?string $productCode;
    public int $totalCost;
    public float $percentage;
    public ?string $remark;
}
