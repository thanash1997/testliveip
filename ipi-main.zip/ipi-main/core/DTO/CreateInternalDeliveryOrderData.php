<?php

namespace IPI\Core\DTO;

use Carbon\Carbon;
use IPI\Core\Entities\InternalDeliveryOrder;

class CreateInternalDeliveryOrderData
{
    public int $picId;
    public int $destinationId;
    public int $inventoryId;
    public string $usage;
    public ?string $batchNo;
    public bool $isFlagged = false;
    public ?string $description;
    public ?string $flagReason;
    public ?string $origin;
    public ?string $remark;
    public string $status = InternalDeliveryOrder::PENDING;
    public Carbon $estimatedDeliveryDate;

    /** @var CreateInternalDeliveryItemData[] $createInternalDeliveryItemData */
    public array $createInternalDeliveryItemData;
}
