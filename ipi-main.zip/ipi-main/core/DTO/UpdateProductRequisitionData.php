<?php

namespace IPI\Core\DTO;

class UpdateProductRequisitionData
{
    public ?int $destinationId;
    public ?string $usage;
    public ?string $flagReason;
    public ?string $remark;
    public ?bool $isFlagged;
    public ?string $status;

    /** @var CreateProductRequisitionItemData[] $createProductRequisitionItemData */
    public array $createProductRequisitionItemData;
}
