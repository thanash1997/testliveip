<?php

namespace IPI\Core\DTO;

class CreateInternalDeliveryItemData
{
    public ?int $id;
    public ?int $productId;
    public ?string $productCode;
    public float $quantity;
    public string $packagingSize;
    public string $description;
}
