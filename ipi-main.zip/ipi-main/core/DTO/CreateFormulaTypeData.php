<?php

namespace IPI\Core\DTO;

class CreateFormulaTypeData
{
    public string $name;
}
