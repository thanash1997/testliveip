<?php

namespace IPI\Core\DTO;

class UpdateProductionMaterialData
{
    public int $id;
    public int $productId;
    public float $quantity;
}
