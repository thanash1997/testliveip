<?php

namespace IPI\Core\DTO;

use Carbon\Carbon;
use IPI\Core\Entities\Procurement;

class CreateProcurementData
{
    public int $supplierId;
    public int $destinationId;
    public Carbon $expectedReceiveDate;
    public string $usage;
    public string $poNumber;
    public ?string $flagReason;
    public ?string $remark;
    public bool $isFlagged = false;
    public float $totalCost;
    public string $status = Procurement::PENDING;

    /** @var CreateProcurementItemData[] $purchaseOrderItems */
    public array $purchaseOrderItems;
}
