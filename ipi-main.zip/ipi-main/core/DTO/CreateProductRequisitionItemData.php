<?php

namespace IPI\Core\DTO;

class CreateProductRequisitionItemData
{
    public ?int $id;
    public ?int $productId;
    public ?string $productCode;
    public float $quantity;
    public string $packagingSize;
    public ?string $description;
}
