<?php

namespace IPI\Core\DTO;

class DeleteResourcesData
{
    public string $resource;
    public string $table;
    public array $ids = [];
}
