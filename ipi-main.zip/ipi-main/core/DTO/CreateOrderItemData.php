<?php

namespace IPI\Core\DTO;

class CreateOrderItemData
{
    public int $productId;
    public int $totalCost;
    public float $quantity;
}
