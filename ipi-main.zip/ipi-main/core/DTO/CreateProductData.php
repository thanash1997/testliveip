<?php

namespace IPI\Core\DTO;

use IPI\Core\Entities\Product;

class CreateProductData
{
    public ?int $productTagId;
    public ?int $requesterCustomerId;
    public ?string $productCode;
    public float $quantity;
    public ?string $description;
    public ?string $typeCode;
    public ?string $packagingSize;
    public int $unitCost;
    public ?string $name;
    public ?int $threshold;
    public string $type = Product::TYPE_MATERIAL;
}
