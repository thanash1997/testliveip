<?php

namespace IPI\Core\DTO;

use IPI\Core\Entities\Product;

class CreateFormulaData
{
    public int $engineerId;
    public ?int $requesterCustomerId;
    public int $formulaTypeId;
    public int $formulaTagId;
    public string $productName;
    public ?string $remark;
    public string $type = Product::TYPE_FORMULA;

    /** @var CreateIngredientListsData[] $ingredientLists */
    public array $ingredientLists;

    /** @var CreateFormulaCheckpointData[] $checkpoints */
    public array $checkpoints;
}
