<?php

namespace IPI\Core\DTO;

use Carbon\Carbon;
use IPI\Core\Entities\ExternalDeliveryOrder;

class UpdateExternalDeliveryOrderData
{
    public ?int $customerId;
    public ?int $addressId;
    public ?string $batchNo;
    public ?string $courierName;
    public ?string $vehicleNo;
    public ?string $trackingNo;
    public ?string $receiptNo;
    public ?string $description;
    public ?string $flagReason;
    public ?string $remark;
    public ?bool $isFlagged = false;
    public ?Carbon $estimatedDeliveryDate;
    public ?string $status = ExternalDeliveryOrder::STATUS_PENDING;

    /** @var CreateExternalDeliveryItemData[] $createExternalDeliverOrderItemData */
    public array $createExternalDeliverOrderItemData;
}
