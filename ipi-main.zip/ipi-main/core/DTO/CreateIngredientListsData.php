<?php

namespace IPI\Core\DTO;

class CreateIngredientListsData
{
    public ?int $id;
    public ?int $position;
    public ?int $totalCost;
    public ?string $remark;

    /** @var CreateIngredientItemData[] $createIngredientItems */
    public array $createIngredientItems;
}
