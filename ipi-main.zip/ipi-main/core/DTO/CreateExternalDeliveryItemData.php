<?php

namespace IPI\Core\DTO;

class CreateExternalDeliveryItemData
{
    public ?int $id;
    public int $productId;
    public ?int $orderId;
    public float $quantity;
    public string $packagingSize;
    public string $description;
}
