<?php

namespace IPI\Core\DTO;

use IPI\Core\Entities\ProductRequisition;

class CreateProductRequisitionData
{
    public int $orderId;
    public int $destinationId;
    public string $usage;
    public string $origin;
    public bool $isFlagged = false;
    public ?string $flagReason;
    public string $status = ProductRequisition::PENDING;

    /** @var CreateProductRequisitionItemData[] $createProductRequisitionItemData */
    public array $createProductRequisitionItemData;
}
