<?php

namespace IPI\Core\DTO;

use Carbon\Carbon;

class UpdateProcurementData
{
    public ?int $supplierId;
    public ?int $destinationId;
    public ?Carbon $expectedReceiveDate;
    public ?string $usage;
    public ?string $poNumber;
    public ?string $flagReason;
    public ?string $remark;
    public ?bool $isFlagged;
    public ?int $totalCost;
    public ?string $status;

    /** @var CreateProcurementItemData[] $purchaseOrderItems */
    public ?array $purchaseOrderItems;
}
