<?php

namespace IPI\Core\General;

use App\Events\NewNotificationSent;
use App\Models\Notification as EloquentNotification;
use IPI\Core\DTO\CreateNotificationData;
use IPI\Core\Entities\Notification;

class NotificationCreator
{
    public function createNotification(CreateNotificationData $data): Notification
    {
        $notificationEloquent = new EloquentNotification([
            'description' => $data->description,
            'view_action_link' => $data->viewActionLink ?? null,
            'approval_action' => $data->approvalAction ?? null,
            'rejection_action' => $data->rejectionAction ?? null,
        ]);
        $notificationEloquent->save();
        $notificationEloquent->modules()->sync($data->moduleIds);

        $notification = new Notification($notificationEloquent->id);
        $notification->setFromArray($notificationEloquent->toArray());

        foreach ($data->moduleIds as $moduleId) {
            NewNotificationSent::dispatch($moduleId);
        }

        return $notification;
    }
}
