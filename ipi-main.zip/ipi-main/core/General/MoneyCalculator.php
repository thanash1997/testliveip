<?php

namespace IPI\Core\General;

class MoneyCalculator
{
    public function calculateTotal(int $pricePerUnit, $totalUnit, $type = 'percent'): int
    {
        if ($type === 'percent') {
            return round($pricePerUnit * ($totalUnit / 100), 0);
        }

        return 0;
    }
}
