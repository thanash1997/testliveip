<?php

namespace IPI\Core\General;

use App\Models\Notification as EloquentNotification;
use Illuminate\Database\Eloquent\Collection as EloquentCollection;
use Illuminate\Support\Collection as SupportCollection;
use IPI\Core\DTO\IndexFilter;
use IPI\Core\Entities\Notification;
use IPI\Core\Filters\EloquentIndexQueryBuilder;

class GetNotifications
{
    public function getNotifications(IndexFilter $data): array
    {
        $eloquentNotificationQuery = EloquentNotification::query()->with($data->relationships);
        $queryBuilder = new EloquentIndexQueryBuilder($eloquentNotificationQuery);
        $eloquentQueryBuilder = $queryBuilder->execute($data, 'notifications');
        $eloquentQueryBuilder->orderBy('id', 'desc');

        if ($data->searchQuery === 'unread') {
            $eloquentQueryBuilder->whereNull('read_at');
        }

        if (preg_match('/(status):/', $data->searchQuery)) {
            $status = preg_replace('/(status):/', '', $data->searchQuery);

            if ($status === 'pending_imr') {
                $eloquentNotificationQuery
                    ->where(function ($query) {
                        $query->whereNull('action_taken_at')
                            ->whereNotNull('approval_action')
                            ->where('description', 'LIKE', 'Internal material requisition%');
                    });
            }

            if ($status === 'pending_formula') {
                $eloquentNotificationQuery
                    ->where(function ($query) {
                        $query->whereNull('action_taken_at')
                            ->whereNotNull('approval_action')
                            ->where('description', 'LIKE', 'Formula%');
                    });
            }
        }

        if ($data->moduleIds !== null && !empty($data->moduleIds)) {
            $eloquentQueryBuilder->whereHas('modules', function ($query) use ($data) {
                return $query->whereIn('module_id', $data->moduleIds);
            });
        }

        if ($data->paginateResult) {
            $notifications = $eloquentQueryBuilder->paginate($data->perPage);
            $responseMetaBuilder = new EloquentResponseMetaBuilder($notifications);

            return [
                $this->prepareNotifications($notifications->getCollection(), $data->type),
                $responseMetaBuilder->execute()
            ];
        }

        $notifications = $eloquentQueryBuilder->get();
        $notifications = $this->prepareNotifications($notifications, $data->type);

        return [$notifications, []];
    }

    private function prepareNotifications(EloquentCollection|SupportCollection $collection, string $type): array
    {
        $notifications = [];

        foreach ($collection as $item) {
            $notification = new Notification($item->id);
            $notification->setFromArray($item->toArray(), $type);

            $notifications[] = $notification;
        }

        return $notifications;
    }
}
