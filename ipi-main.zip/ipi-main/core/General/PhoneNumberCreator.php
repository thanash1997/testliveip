<?php

namespace IPI\Core\General;

use App\Models\PhoneNumber;

class PhoneNumberCreator
{
    public function storePhoneNumber(int $dialingCode, string $phoneNumber): PhoneNumber
    {
        $phoneNumber = new PhoneNumber(['phone_number' => $phoneNumber]);
        $phoneNumber->dialingCode()->associate($dialingCode);
        $phoneNumber->save();

        return $phoneNumber;
    }
}
