<?php

namespace IPI\Core\General;

use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class EloquentResponseMetaBuilder
{
    private LengthAwarePaginator $paginator;

    public function __construct(LengthAwarePaginator $paginator)
    {
        $this->paginator = $paginator;
    }

    public function execute(): array
    {
        $meta = [];
        $meta['path'] = $this->paginator->path();
        $meta['perPage'] = $this->paginator->perPage();
        $meta['total'] = $this->paginator->total();
        $meta['lastPage'] = $this->paginator->lastPage();
        $meta['currentPage'] = $this->paginator->currentPage();

        return $meta;
    }
}
