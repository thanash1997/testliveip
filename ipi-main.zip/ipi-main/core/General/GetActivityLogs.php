<?php

namespace IPI\Core\General;

use App\Models\Company;
use App\Models\ExternalDeliveryOrder;
use App\Models\Formula;
use App\Models\General\EloquentBaseUser;
use App\Models\InternalDeliveryOrder;
use App\Models\Order;
use App\Models\Product;
use App\Models\ProductionMaterial;
use App\Models\ProductRequisition;
use App\Models\PurchaseOrder;
use App\Models\Remark;
use Illuminate\Database\Eloquent\Collection as EloquentCollection;
use Illuminate\Support\Collection as SupportCollection;
use IPI\Core\DTO\IndexFilter;
use IPI\Core\Entities\ActivityLog;
use IPI\Core\Filters\EloquentIndexQueryBuilder;
use OwenIt\Auditing\Models\Audit as AuditEloquent;

class GetActivityLogs
{
    const ALLOWED_PERMISSION = [
        EloquentBaseUser::HOD_ROLE => [
            'warehouse' => [
                InternalDeliveryOrder::class,
                ExternalDeliveryOrder::class,
                Product::class,
                PurchaseOrder::class,
                ProductRequisition::class,
            ],
            'production' => [
                Order::class,
                Formula::class,
                Product::class,
                InternalDeliveryOrder::class,
                ProductRequisition::class,
                Company::class,
            ],
            'sales' => [
                Order::class,
                Product::class,
                InternalDeliveryOrder::class,
                ProductRequisition::class,
                Company::class,
            ],
            'lab' => [
                Formula::class,
            ],
        ],
        EloquentBaseUser::STAFF_ROLE => [
            'warehouse' => [
                InternalDeliveryOrder::class,
                ExternalDeliveryOrder::class,
                Product::class,
                PurchaseOrder::class,
                ProductRequisition::class,
            ],
            'production' => [
                Order::class,
                Formula::class,
                Product::class,
                InternalDeliveryOrder::class,
                ProductRequisition::class,
                Company::class,
            ],
            'sales' => [
                Order::class,
                Product::class,
                InternalDeliveryOrder::class,
                ProductRequisition::class,
                Company::class,
            ],
            'lab' => [
                Formula::class,
            ],
        ],
    ];

    public function getActivityLogs(IndexFilter $data): array
    {
        $department = request()->user()->department;
        $departmentName = strtolower($department->name);
        $role = request()->user()->roles()->first()->name;
        $eloquentAuditQuery = AuditEloquent::query()->with($data->relationships);
        $queryBuilder = new EloquentIndexQueryBuilder($eloquentAuditQuery);
        $eloquentQueryBuilder = $queryBuilder->execute($data, 'audits');
        $eloquentQueryBuilder->where('url', '!=', 'console');
        $eloquentQueryBuilder->where('auditable_type', '!=', Remark::class);
        $eloquentQueryBuilder->where('auditable_type', '!=', ProductionMaterial::class);

        if (isset(self::ALLOWED_PERMISSION[$role][$departmentName])) {
            $eloquentQueryBuilder->whereIn('auditable_type', self::ALLOWED_PERMISSION[$role][$departmentName]);
        }

        if ($data->paginateResult) {
            $activityLogs = $eloquentQueryBuilder->paginate($data->perPage);
            $responseMetaBuilder = new EloquentResponseMetaBuilder($activityLogs);

            return [
                $this->prepareActivityLogs($activityLogs->getCollection(), $departmentName),
                $responseMetaBuilder->execute(),
            ];
        }

        $activityLogs = $eloquentQueryBuilder->get();
        $activityLogs = $this->prepareActivityLogs($activityLogs, $departmentName);

        return [$activityLogs, []];
    }

    private function prepareActivityLogs(EloquentCollection|SupportCollection $collection, $departmentName): array
    {
        $activityLogs = [];

        foreach ($collection as $item) {
            $activityLog = new ActivityLog();
            $activityLog->setFromArray($item->toArray(), $departmentName);

            $activityLogs[] = $activityLog;
        }

        return $activityLogs;
    }
}
