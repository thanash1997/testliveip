<?php

namespace IPI\Core\Auth;

use Illuminate\Database\Eloquent\Model;
use IPI\Core\General\PhoneNumberCreator;
use IPI\Core\IDefaultService;
use IPI\Core\User\IUserRoleAssigner;
use IPI\Core\User\UserCreator;
use IPI\Core\User\UserDepartmentAssigner;

class RegistrationService implements IDefaultService
{
    private array $registrationData;

    public function __construct(array $registrationData)
    {
        $this->registrationData = $registrationData;
    }

    public function handle(): Model
    {
        $userCreator = new UserCreator();
        $roleAssigner = app(IUserRoleAssigner::class);

        $phoneNumberCreator = new PhoneNumberCreator();
        $phoneNumber = $phoneNumberCreator->storePhoneNumber(
            $this->registrationData['dialing_code_id'],
            $this->registrationData['phone_number']
        );

        $user = $userCreator->storeUser([
            'name' => $this->registrationData['name'],
            'username' => $this->registrationData['username'],
            'email' => $this->registrationData['email'],
            'password' => $this->registrationData['password'],
        ], true);

        $user->phoneNumber()->associate($phoneNumber);
        $roleAssigner->setUser($user);
        $user = $roleAssigner->assignRole($this->registrationData['role']);

        return (new UserDepartmentAssigner($user))->assignDepartment($this->registrationData['department_id']);
    }
}
