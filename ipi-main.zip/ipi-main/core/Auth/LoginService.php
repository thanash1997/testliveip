<?php

namespace IPI\Core\Auth;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Support\Facades\Auth;
use IPI\Core\IDefaultService;

class LoginService implements IDefaultService
{
    private array $loginData;

    public function __construct(array $loginData)
    {
        $this->loginData = $loginData;
    }

    public function handle(): Model
    {
        if (Auth::attempt($this->loginData)) {
            $identifier = isset($this->loginData['email']) ? 'email' : 'username';
            $user = User::where($identifier, $this->loginData[$identifier])->first();
            
            Auth::login($user);

            return $user;
        }

        throw new HttpResponseException(
            response()->json([
                'error' => 'Invalid login credentials.'
            ], 401)
        );
    }
}
