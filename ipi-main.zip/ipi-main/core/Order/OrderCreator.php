<?php

namespace IPI\Core\Order;

use App\Models\Company;
use App\Models\Formula as FormulaEloquent;
use App\Models\Inventory;
use App\Models\Module;
use App\Models\Order as OrderEloquent;
use App\Models\OrderItem as OrderItemEloquent;
use App\Models\Product;
use Illuminate\Support\Facades\DB;
use IPI\Core\DTO\CreateNotificationData;
use IPI\Core\DTO\CreateOrderData;
use IPI\Core\DTO\CreateProductRequisitionData;
use IPI\Core\DTO\CreateProductRequisitionItemData;
use IPI\Core\Entities\Order;
use IPI\Core\Entities\OrderItem;
use IPI\Core\Entities\ProductRequisition;
use IPI\Core\General\NotificationCreator;
use IPI\Core\Product\ProductRequisitionCreator;

class OrderCreator
{
    private ProductRequisitionCreator $productRequisitionCreator;
    private NotificationCreator $notificationCreator;
    private ReplicateIngredients $replicateIngredients;

    public function __construct(
        ProductRequisitionCreator $productRequisitionCreator,
        NotificationCreator $notificationCreator,
        ReplicateIngredients $replicateIngredients
    ) {
        $this->productRequisitionCreator = $productRequisitionCreator;
        $this->notificationCreator = $notificationCreator;
        $this->replicateIngredients = $replicateIngredients;
    }

    public function createOrder(CreateOrderData $data): Order
    {
        return DB::transaction(function () use ($data) {
            $orderEloquent = new OrderEloquent([
                'batch_no' => $this->generateBatchNumber(),
                'description' => $data->description,
                'total_cost' => $data->totalCost,
                'estimated_delivered_at' => $data->estimatedDeliveredAt,
            ]);
            $orderEloquent->customer()->associate($data->customerId);
            $orderEloquent->shipment()->associate($data->shipmentId);
            $orderEloquent->contactPerson()->associate($data->contactPersonId);
            $orderEloquent->personInCharge()->associate($data->picId);
            $orderEloquent->save();

            foreach ($data->createOrderItems as $createOrderItem) {
                $orderItemEloquent = new OrderItemEloquent([
                    'total_cost' => $createOrderItem->totalCost,
                    'quantity' => $createOrderItem->quantity,
                    'remaining_quantity' => $createOrderItem->quantity,
                ]);
                $orderItemEloquent->order()->associate($orderEloquent->id);
                $orderItemEloquent->product()->associate(
                    $createOrderItem->productId
                );
                $orderItemEloquent->save();
                $this->replicateIngredients->replicateToOrderItem(
                    $orderItemEloquent->id
                );

                if ($data->withApproval) {
                    $customer = Company::find($data->customerId);
                    $product = Product::find($createOrderItem->productId);
                    $this->generateApprovalNotification(
                        $orderEloquent->uuid,
                        $product->product_code,
                        $customer->name
                    );
                }

                $this->generateProductRequisition(
                    $createOrderItem->productId,
                    $createOrderItem->quantity,
                    $orderEloquent->id
                );
            }

            if (count($data->files) > 0) {
                foreach ($data->files as $file) {
                    $orderEloquent->addMediaFromDisk($file)->toMediaCollection();
                }
            }

            return $this->prepareOrderData($orderEloquent); 
        });
    }

    private function prepareOrderData(OrderEloquent $orderEloquent): Order
    {
        $orderEloquent->loadMissing('orderItems.product');
        $order = new Order($orderEloquent->id);
        $order->setFromArray($orderEloquent->toArray());

        $orderItems = [];

        foreach ($orderEloquent->orderItems as $orderItemEloquent) {
            $orderItem = new OrderItem($orderItemEloquent->id);
            $orderItem->setFromArray($orderItemEloquent->toArray());

            $orderItems[] = $orderItem;
        }

        $order->orderItems = $orderItems;

        return $order;
    }

    private function generateBatchNumber(): string
    {
        $latestOrder = OrderEloquent::query()->orderBy('id', 'desc')->first();

        if ($latestOrder === null) {
            return sprintf("%06d", 1);
        }

        $currentNumber = (int)$latestOrder->batch_no;

        return sprintf("%06d", $currentNumber + 1);
    }

    private function generateProductRequisition(
        int $productId,
        int $quantity,
        int $orderId
    ): void {
        $formula = FormulaEloquent::query()
            ->with('ingredientLists.ingredientListItems.product.inventories')
            ->where('product_id', $productId)
            ->first();
        $warehouse = Inventory::query()->where('slug', Inventory::WAREHOUSE)
            ->first();
        $createProductRequisitionData = new CreateProductRequisitionData();
        $createProductRequisitionData->orderId = $orderId;
        $createProductRequisitionData->destinationId = $warehouse->id;
        $createProductRequisitionData->usage = 'Production';
        $createProductRequisitionData->origin = 'IPI Sdn Bhd';
        $createProductRequisitionItems = [];

        foreach ($formula->ingredientLists as $ingredientList) {
            foreach ($ingredientList->ingredientListItems as $ingredientItem) {
                $ingredientQuantity = ($ingredientItem->percentage / 100)
                    * $quantity;
                $product = $ingredientItem->product;
                $productThreshold = $product->threshold;
                $inventoryProduction = $product->inventories->where(
                    'slug',
                    Inventory::PRODUCTION
                )->first();
                $inventoryWarehouse = $product->inventories->where(
                    'slug',
                    Inventory::WAREHOUSE
                )->first();
                $totalQuantity = $inventoryProduction->pivot->quantity
                    + $inventoryWarehouse->pivot->quantity;

                if ($totalQuantity < $productThreshold) {
                    // TODO: Do procurement
                    continue;
                }

                if ($inventoryProduction->pivot->quantity
                    < $ingredientQuantity
                ) {
                    $createProductRequisitionItemData
                        = new CreateProductRequisitionItemData();
                    $createProductRequisitionItemData->description
                        = $product->description;
                    $createProductRequisitionItemData->quantity
                        = $ingredientQuantity
                        - $inventoryProduction->pivot->quantity;
                    $createProductRequisitionItemData->productId = $product->id;
                    $createProductRequisitionItemData->packagingSize
                        = $product->packaging_size;
                    $createProductRequisitionItems[]
                        = $createProductRequisitionItemData;
                }
            }
        }

        if (count($createProductRequisitionItems) > 0) {
            $createProductRequisitionData->createProductRequisitionItemData
                = $createProductRequisitionItems;
            $productRequisition
                = $this->productRequisitionCreator->createProductRequisition(
                $createProductRequisitionData
            );
            $this->generateNotification($productRequisition);
        }
    }

    private function generateNotification(ProductRequisition $productRequisition
    ): void {
        $moduleIds = Module::query()->whereIn(
            'slug',
            [Module::PRODUCTION, Module::WAREHOUSE]
        )->pluck('id')->toArray();
        $createNotificationData = new CreateNotificationData();
        $createNotificationData->description
            = "Internal material requisition {$productRequisition->materialRequisitionNo} is created.";
        $createNotificationData->viewActionLink = route(
            'production.product-requisitions.details',
            ['uuid' => $productRequisition->uuid]
        );
        $createNotificationData->moduleIds = $moduleIds;
        $createNotificationData->approvalAction = route(
            'api.imr.approve',
            $productRequisition->uuid
        );
        $createNotificationData->rejectionAction = route(
            'api.imr.reject',
            $productRequisition->uuid
        );

        $this->notificationCreator->createNotification($createNotificationData);
    }

    private function generateApprovalNotification(
        string $orderUuid,
        string $productCode,
        string $customerName
    ): void {
        $moduleIds = Module::query()->whereIn('slug', [Module::PRODUCTION])
            ->pluck('id')->toArray();
        $createNotificationData = new CreateNotificationData();
        $createNotificationData->description
            = "$productCode has been approved by customer $customerName";
        $createNotificationData->viewActionLink = route(
            'production.order.details',
            ['uuid' => $orderUuid]
        );
        $createNotificationData->moduleIds = $moduleIds;

        $this->notificationCreator->createNotification($createNotificationData);
    }
}
