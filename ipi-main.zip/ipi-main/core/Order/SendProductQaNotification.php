<?php

namespace IPI\Core\Order;

use App\Models\Module;
use IPI\Core\DTO\CreateNotificationData;
use IPI\Core\General\NotificationCreator;

class SendProductQaNotification
{
    private NotificationCreator $notificationCreator;

    public function __construct(NotificationCreator $notificationCreator)
    {
        $this->notificationCreator = $notificationCreator;
    }

    public function sendNotification(string $productCode, string $orderUuid): void
    {
        $moduleIds = Module::query()->whereIn('slug', [Module::WAREHOUSE])->pluck('id')->toArray();
        $createNotificationData = new CreateNotificationData();
        $createNotificationData->description = "$productCode is in inventory for more than a year and needs QA/QC before sending out, kindly check.";
        $createNotificationData->viewActionLink = route('production.order.details', ['uuid' => $orderUuid]);
        $createNotificationData->moduleIds = $moduleIds;

        $this->notificationCreator->createNotification($createNotificationData);
    }
}
