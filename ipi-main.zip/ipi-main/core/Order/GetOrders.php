<?php

namespace IPI\Core\Order;

use App\Models\Order as EloquentOrder;
use App\Models\Company as EloquentCompany;
use Illuminate\Database\Eloquent\Collection as EloquentCollection;
use Illuminate\Support\Collection as SupportCollection;
use IPI\Core\DTO\IndexFilter;
use IPI\Core\Entities\Company;
use IPI\Core\Entities\Order;
use IPI\Core\Entities\OrderItem;
use IPI\Core\Filters\EloquentIndexQueryBuilder;
use IPI\Core\General\EloquentResponseMetaBuilder;

class GetOrders
{
    public function getOrders(IndexFilter $data): array
    {
        $eloquentOrderQuery = EloquentOrder::query()->withCreator()->with($data->relationships);
        $queryBuilder = new EloquentIndexQueryBuilder($eloquentOrderQuery);
        $eloquentQueryBuilder = $queryBuilder->execute($data, 'orders');

        if (isset($data->status) && $data->status === 'completed') {
            $eloquentQueryBuilder->whereNotNull('completed_at')
                ->whereNull(['cancelled_at', 'halted_at']);
        }

        if (isset($data->excludeEmpty) && $data->excludeEmpty === true) {
            $eloquentQueryBuilder->whereHas('orderItems', function ($query) {
                return $query->where('remaining_quantity', '>', 0);
            });
        }

        if (isset($data->companyUuid)) {
            $company = EloquentCompany::query()->where('uuid', $data->companyUuid)->first();

            $eloquentQueryBuilder->where('customer_id', $company->id);
        }

        if ($data->paginateResult) {
            $orders = $eloquentQueryBuilder->paginate($data->perPage);
            $responseMetaBuilder = new EloquentResponseMetaBuilder($orders);

            return [
                $this->prepareOrders($orders->getCollection()),
                $responseMetaBuilder->execute(),
            ];
        }

        $orders = $eloquentQueryBuilder->get();
        $orders = $this->prepareOrders($orders);

        return [$orders, []];
    }

    private function prepareOrders(EloquentCollection|SupportCollection $collection): array
    {
        $orders = [];

        foreach ($collection as $item) {
            $order = new Order($item->id);
            $order->setFromArray($item->toArray());

            $customer = new Company();
            $customer->uuid = $item->customer->uuid;
            $customer->companyCode = $item->customer->company_code;
            $customer->name = $item->customer->name;
            $customer->id = $item->customer->id;

            $orderItems = [];

            foreach ($item->orderItems as $orderItemEloquent) {
                $orderItem = new OrderItem($orderItemEloquent->id);
                $orderItem->setFromArray($orderItemEloquent->toArray());

                $orderItems[] = $orderItem;
            }

            $order->customer = $customer;
            $order->orderItems = $orderItems;

            $orders[] = $order;
        }

        return $orders;
    }
}
