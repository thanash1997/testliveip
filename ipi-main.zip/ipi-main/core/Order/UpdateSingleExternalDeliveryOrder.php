<?php

namespace IPI\Core\Order;

use App\Models\ExternalDeliveryItem as ExternalDeliveryItemEloquent;
use App\Models\ExternalDeliveryOrder as ExternalDeliveryOrderEloquent;
use App\Models\Inventory;
use Illuminate\Support\Facades\DB;
use IPI\Core\DTO\UpdateExternalDeliveryOrderData;
use IPI\Core\Entities\ExternalDeliveryOrder;
use IPI\Core\Entities\Procurement;
use IPI\Core\Product\VerifyInventoryProductThreshold;

class UpdateSingleExternalDeliveryOrder
{
    private VerifyInventoryProductThreshold $inventoryProductThreshold;

    public function __construct(
        VerifyInventoryProductThreshold $inventoryProductThreshold
    ) {
        $this->inventoryProductThreshold = $inventoryProductThreshold;
    }

    private const UPDATABLE = [
        'batch_no',
        'courier_name',
        'vehicle_no',
        'tracking_no',
        'receipt_no',
        'description',
        'is_flagged',
        'flag_reason',
        'estimated_delivery_date',
        'status',
    ];

    public function updateExternalDeliveryOrder(
        UpdateExternalDeliveryOrderData $data,
        string $uuid
    ): ExternalDeliveryOrder {
        $externalDeliveryOrderEloquent = ExternalDeliveryOrderEloquent::query()->where('uuid', $uuid)->first();
        $previousState = new ExternalDeliveryOrder($externalDeliveryOrderEloquent->id);
        $previousState->setFromArray($externalDeliveryOrderEloquent->toArray());

        return DB::transaction(
            function () use (
                $data,
                $externalDeliveryOrderEloquent,
                $previousState
            ) {
                $values = get_object_vars($data);

                foreach ($values as $key => $value) {
                    if ($value === null) {
                        continue;
                    }

                    $key = $this->formatKey($key);
                    if (in_array($key, self::UPDATABLE)) {
                        if ($key === 'status' && $value === 'pending') {
                            $externalDeliveryOrderEloquent->cancelled_at = null;
                            $externalDeliveryOrderEloquent->fulfilled_at = null;
                            continue;
                        }

                        [$modelKey, $value] = $this->formatValue($key, $value);
                        $externalDeliveryOrderEloquent->$modelKey = $value;
                    }
                }

                $externalDeliveryOrderEloquent->save();

                if (isset($data->remark)) {
                    $externalDeliveryOrderEloquent->remarks()->create(
                        ['body' => $data->remark]
                    );
                }

                $productsQuantity = [];

                foreach ($data->createExternalDeliverOrderItemData as $externalDeliveryItem) {
                    if ($externalDeliveryItem->id !== null) {
                        $newExternalDeliveryOrderItem = $externalDeliveryOrderEloquent->orderItems()
                            ->where('id', $externalDeliveryItem->id)
                            ->first();
                    } else {
                        $newExternalDeliveryOrderItem = $externalDeliveryOrderEloquent->orderItems()
                            ->where('product_id', $externalDeliveryItem->productId)
                            ->first();
                    }

                    if ($newExternalDeliveryOrderItem) {
                        $newExternalDeliveryOrderItem->quantity = $externalDeliveryItem->quantity;
                        $newExternalDeliveryOrderItem->packaging_size = $externalDeliveryItem->packagingSize;
                        $newExternalDeliveryOrderItem->description = $externalDeliveryItem->description;
                    } else {
                        $newExternalDeliveryOrderItem = new ExternalDeliveryItemEloquent([
                            'quantity' => $externalDeliveryItem->quantity,
                            'packaging_size' => $externalDeliveryItem->packagingSize,
                            'description' => $externalDeliveryItem->description,
                        ]);

                        $newExternalDeliveryOrderItem->externalDeliveryOrder()
                            ->associate($externalDeliveryOrderEloquent->id);
                    }

                    if (!empty($externalDeliveryItem->orderId)) {
                        $newExternalDeliveryOrderItem->order()->associate($externalDeliveryItem->orderId);
                    }

                    $newExternalDeliveryOrderItem->product()->associate($externalDeliveryItem->productId);

                    if ($newExternalDeliveryOrderItem->isDirty()) {
                        $newExternalDeliveryOrderItem->save();
                    }

                    $productsQuantity[] = [
                        'productId' => $externalDeliveryItem->productId,
                        'quantity' => $externalDeliveryItem->quantity,
                        'orderId' => $externalDeliveryItem->orderId ?? null,
                    ];
                }

                if ($previousState->status !== Procurement::FULFILLED && $data->status === Procurement::FULFILLED) {
                    $inventory = Inventory::query()->where('slug', Inventory::WAREHOUSE)->first();

                    foreach ($productsQuantity as $productData) {
                        $quantity = $productData['quantity'];
                        $orderId = $productData['orderId'];
                        $productId = $productData['productId'];
                        $inventory->products()->where('product_id', $productId)->decrement('quantity', $quantity);
                        DB::table('order_items')->where('order_id', $orderId)->decrement(
                            'remaining_quantity',
                            $quantity
                        );
                        $this->inventoryProductThreshold->verify($productId, $inventory->id);
                    }
                } elseif ($previousState->status === Procurement::FULFILLED
                    && $data->status !== Procurement::FULFILLED
                ) {
                    $inventory = Inventory::query()->where('slug', Inventory::WAREHOUSE)->first();

                    foreach ($productsQuantity as $productId => $productData) {
                        $quantity = $productData['quantity'];
                        $orderId = $productData['orderId'];
                        DB::table('order_items')->where('order_id', $orderId)->increment(
                            'remaining_quantity',
                            $quantity
                        );
                        $inventory->products()->where('product_id', $productId)->increment('quantity', $quantity);
                    }
                }

                $externalDeliveryOrderEloquent->loadMissing('orderItems.product');
                $externalDeliveryOrder = new ExternalDeliveryOrder($externalDeliveryOrderEloquent->id);
                $externalDeliveryOrder->setFromArray($externalDeliveryOrderEloquent->toArray());
                $externalDeliveryOrder->setExternalDeliveryOrderItemFromArray(
                    $externalDeliveryOrderEloquent->orderItems->toArray()
                );

                return $externalDeliveryOrder;
            }
        );
    }

    private function generateBatchNo($batchNo): string
    {
        return sprintf("%06d", $batchNo);
    }

    private function formatValue(string $key, $value)
    {
        if ($key === 'is_flagged') {
            if ($value === true) {
                return ['flagged_at', now()];
            }

            return ['flagged_at', null];
        }

        if ($key === 'status') {
            $hashMap = [
                ExternalDeliveryOrder::STATUS_FULFILLED => 'fulfilled_at',
                ExternalDeliveryOrder::STATUS_CANCELLED => 'cancelled_at',
            ];

            return [$hashMap[$value], now()];
        }

        if ($key === 'batch_no') {
            return [$key, $this->generateBatchNo($value)];
        }

        return [$key, $value];
    }

    private function formatKey(string $key): string
    {
        return strtolower(
            preg_replace(
                [
                    '#([A-Z][a-z]*)(\d+[A-Z][a-z]*\d+)#',
                    '#([A-Z]+\d*)([A-Z])#',
                    '#([a-z]+\d*)([A-Z])#',
                    '#([^_\d])([A-Z][a-z])#',
                ],
                '$1_$2',
                $key
            )
        );
    }
}
