<?php

namespace IPI\Core\Order;

use App\Models\InternalDeliveryOrder as EloquentInternalDeliveryOrder;
use IPI\Core\Entities\InternalDeliveryOrder;

class GetSingleInternalDeliveryOrder
{
    public function getInternalDeliveryOrder(string $uuid): InternalDeliveryOrder
    {
        $eloquentQueryBuilder = EloquentInternalDeliveryOrder::query()->with([
            'orderItems.product',
            'personInCharge',
            'destination',
            'audits.user',
            'remarks' => function ($query) {
                $query->withCreator();
            },
        ]);
        $internalDeliveryOrderEloquent = $eloquentQueryBuilder->where('uuid', $uuid)->withCreator()->first();

        return $this->prepareInternalDeliveryOrder($internalDeliveryOrderEloquent);
    }

    private function prepareInternalDeliveryOrder(EloquentInternalDeliveryOrder $internalDeliveryOrderEloquent): InternalDeliveryOrder
    {
        $internalDeliveryOrder = new InternalDeliveryOrder($internalDeliveryOrderEloquent->id);
        $internalDeliveryOrder->setFromArray($internalDeliveryOrderEloquent->toArray());
        $internalDeliveryOrder->setInternalDeliveryOrderItemFromArray($internalDeliveryOrderEloquent->orderItems->toArray());
        $internalDeliveryOrder->setAudits($internalDeliveryOrderEloquent->audits->toArray());
        $internalDeliveryOrder->setRemarks($internalDeliveryOrderEloquent->remarks->toArray());

        return $internalDeliveryOrder;
    }
}
