<?php

namespace IPI\Core\Order;

use App\Models\InternalDeliveryOrder as EloquentInternalDeliveryOrder;
use Illuminate\Database\Eloquent\Collection as EloquentCollection;
use Illuminate\Support\Collection as SupportCollection;
use IPI\Core\DTO\IndexFilter;
use IPI\Core\Entities\InternalDeliveryOrder;
use IPI\Core\Filters\EloquentIndexQueryBuilder;
use IPI\Core\General\EloquentResponseMetaBuilder;

class GetInternalDeliveryOrders
{
    public function getInternalDeliveryOrders(IndexFilter $data): array
    {
        $eloquentOrderQuery = EloquentInternalDeliveryOrder::query()->withCreator()->with($data->relationships);
        $queryBuilder = new EloquentIndexQueryBuilder($eloquentOrderQuery);
        $eloquentQueryBuilder = $queryBuilder->execute($data, 'internal_delivery_orders');
        
        if ($data->type !== null) {
            $eloquentQueryBuilder
                ->leftJoin('inventories', 'inventories.id', '=', 'internal_delivery_orders.inventory_id')
                ->where('inventories.slug', $data->type);   
        }

        if ($data->paginateResult) {
            $internalDeliveryOrders = $eloquentQueryBuilder->paginate($data->perPage);
            $responseMetaBuilder = new EloquentResponseMetaBuilder($internalDeliveryOrders);

            return [
                $this->prepareInternalDeliveryOrders($internalDeliveryOrders->getCollection()),
                $responseMetaBuilder->execute()
            ];
        }

        $internalDeliveryOrders = $eloquentQueryBuilder->get();
        $internalDeliveryOrders = $this->prepareInternalDeliveryOrders($internalDeliveryOrders);

        return [$internalDeliveryOrders, []];
    }

    private function prepareInternalDeliveryOrders(EloquentCollection|SupportCollection $collection): array
    {
        $internalDeliveryOrders = [];

        foreach ($collection as $item) {
            $internalDeliveryOrder = new InternalDeliveryOrder($item->id);
            $internalDeliveryOrder->setFromArray($item->toArray());
            $internalDeliveryOrder->setInternalDeliveryOrderItemFromArray($item->orderItems->toArray());

            $internalDeliveryOrders[] = $internalDeliveryOrder;
        }

        return $internalDeliveryOrders;
    }
}
