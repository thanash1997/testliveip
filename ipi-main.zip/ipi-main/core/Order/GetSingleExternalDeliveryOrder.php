<?php

namespace IPI\Core\Order;

use App\Models\ExternalDeliveryOrder as EloquentExternalDeliveryOrder;
use IPI\Core\Entities\ExternalDeliveryOrder;

class GetSingleExternalDeliveryOrder
{
    public function getExternalDeliveryOrder(string $uuid): ExternalDeliveryOrder
    {
        $eloquentQueryBuilder = EloquentExternalDeliveryOrder::query()->with([
            'orderItems.product',
            'orderItems.order',
            'audits.user',
            'customer',
            'address',
            'remarks' => function ($query) {
                $query->withCreator();
            },
        ]);
        $externalDeliveryOrderEloquent = $eloquentQueryBuilder->where('uuid', $uuid)->withCreator()->first();

        return $this->prepareExternalDeliveryOrder($externalDeliveryOrderEloquent);
    }

    private function prepareExternalDeliveryOrder(EloquentExternalDeliveryOrder $externalDeliveryOrderEloquent): ExternalDeliveryOrder
    {
        $externalDeliveryOrder = new ExternalDeliveryOrder($externalDeliveryOrderEloquent->id);
        $externalDeliveryOrder->setFromArray($externalDeliveryOrderEloquent->toArray());
        $externalDeliveryOrder->setExternalDeliveryOrderItemFromArray($externalDeliveryOrderEloquent->orderItems->toArray());
        $externalDeliveryOrder->setAudits($externalDeliveryOrderEloquent->audits->toArray());
        $externalDeliveryOrder->setRemarks($externalDeliveryOrderEloquent->remarks->toArray());

        return $externalDeliveryOrder;
    }
}
