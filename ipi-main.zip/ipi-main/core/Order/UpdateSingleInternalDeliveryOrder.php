<?php

namespace IPI\Core\Order;

use App\Exceptions\InsufficientInventoryQuantity;
use App\Models\InternalDeliveryItem as InternalDeliveryItemEloquent;
use App\Models\InternalDeliveryOrder as InternalDeliveryOrderEloquent;
use App\Models\Inventory;
use App\Models\Product as ProductEloquent;
use Illuminate\Support\Facades\DB;
use IPI\Core\DTO\CreateProductData;
use IPI\Core\DTO\UpdateInternalDeliveryOrderData;
use IPI\Core\Entities\InternalDeliveryOrder;
use IPI\Core\Entities\Procurement;
use IPI\Core\Entities\Product;
use IPI\Core\Product\ProductCreator;
use IPI\Core\Product\VerifyInventoryProductThreshold;

class UpdateSingleInternalDeliveryOrder
{
    private ProductCreator $productCreator;
    private VerifyInventoryProductThreshold $inventoryProductThreshold;

    private const UPDATABLE
        = [
            'usage',
            'description',
            'estimated_delivery_date',
            'is_flagged',
            'flag_reason',
            'status',
        ];

    public function __construct(
        ProductCreator $productCreator,
        VerifyInventoryProductThreshold $inventoryProductThreshold
    ) {
        $this->productCreator = $productCreator;
        $this->inventoryProductThreshold = $inventoryProductThreshold;
    }

    /**
     * @param  UpdateInternalDeliveryOrderData  $data
     * @param  string                           $uuid
     *
     * @return InternalDeliveryOrder
     * @throws InsufficientInventoryQuantity
     */
    public function updateInternalDeliveryOrder(
        UpdateInternalDeliveryOrderData $data,
        string $uuid
    ): InternalDeliveryOrder {
        $internalDeliveryOrderEloquent = InternalDeliveryOrderEloquent::query()
            ->where('uuid', $uuid)->first();
        $previousState = new InternalDeliveryOrder(
            $internalDeliveryOrderEloquent->id
        );
        $previousState->setFromArray($internalDeliveryOrderEloquent->toArray());

        return DB::transaction(
            function () use (
                $data,
                $internalDeliveryOrderEloquent,
                $previousState
            ) {
                $newlyDelivered = null;
                $newlyFulfilled = null;

                $values = get_object_vars($data);

                foreach ($values as $key => $value) {
                    if ($value === null) {
                        continue;
                    }

                    $key = $this->formatKey($key);
                    if (in_array($key, self::UPDATABLE)) {
                        if ($key === 'status'
                            && $value === InternalDeliveryOrder::PENDING
                        ) {
                            $internalDeliveryOrderEloquent->delivered_at = null;
                            $internalDeliveryOrderEloquent->fulfilled_at = null;
                            continue;
                        }

                        if ($key === 'status'
                            && $value === InternalDeliveryOrder::DELIVERED
                            && $previousState->status
                            === InternalDeliveryOrder::PENDING
                        ) {
                            $newlyDelivered = now();
                            continue;
                        }

                        if ($key === 'status'
                            && $value === InternalDeliveryOrder::FULFILLED
                            && $previousState->status
                            !== InternalDeliveryOrder::FULFILLED
                        ) {
                            $newlyFulfilled = now();
                            continue;
                        }

                        [$modelKey, $value] = $this->formatValue($key, $value);
                        $internalDeliveryOrderEloquent->$modelKey = $value;
                    }
                }

                if (isset($data->picId)) {
                    $internalDeliveryOrderEloquent->personInCharge()->associate(
                        $data->picId
                    );
                }

                if (isset($data->destinationId)) {
                    $internalDeliveryOrderEloquent->destination()->associate(
                        $data->destinationId
                    );
                }

                $internalDeliveryOrderEloquent->save();

                if (isset($data->remark)) {
                    $internalDeliveryOrderEloquent->remarks()->create(
                        ['body' => $data->remark]
                    );
                }

                $newInternalDeliveryOrderItems = [];
                $productsQuantity = [];

                foreach (
                    $data->createInternalDeliveryItemData as
                    $internalDeliveryItem
                ) {
                    $existingProductId = $internalDeliveryItem->productId ??
                        ProductEloquent::query()->where(
                            'product_code',
                            $internalDeliveryItem->productCode
                        )->first()->id ?? null;

                    if ($existingProductId) {
                        if ($internalDeliveryItem->id !== null) {
                            $newInternalDeliveryOrderItem
                                = $internalDeliveryOrderEloquent->orderItems()
                                ->where('id', $internalDeliveryItem->id)->first(
                                );
                        } else {
                            $newInternalDeliveryOrderItem
                                = $internalDeliveryOrderEloquent->orderItems()
                                ->where(
                                    'product_id',
                                    $internalDeliveryItem->productId
                                )->first();
                        }

                        if ($newInternalDeliveryOrderItem) {
                            $newInternalDeliveryOrderItem->quantity
                                = $internalDeliveryItem->quantity;
                            $newInternalDeliveryOrderItem->packaging_size
                                = $internalDeliveryItem->packagingSize;
                            $newInternalDeliveryOrderItem->description
                                = $internalDeliveryItem->description;
                        } else {
                            $newInternalDeliveryOrderItem
                                = new InternalDeliveryItemEloquent([
                                'quantity' => $internalDeliveryItem->quantity,
                                'packaging_size' => $internalDeliveryItem->packagingSize,
                                'description' => $internalDeliveryItem->description,
                            ]);

                            $newInternalDeliveryOrderItem->internalDeliveryOrder(
                            )->associate($internalDeliveryOrderEloquent->id);
                        }

                        $newInternalDeliveryOrderItem->product()->associate(
                            $existingProductId
                        );
                        $newInternalDeliveryOrderItem->save();

                        if (isset($productsQuantity[$existingProductId])) {
                            $productsQuantity[$existingProductId] += $internalDeliveryItem->quantity;
                        } else {
                            $productsQuantity[$existingProductId]
                                = $internalDeliveryItem->quantity;
                        }
                    } else {
                        $createProductData = new CreateProductData();
                        $createProductData->productCode
                            = $internalDeliveryItem->productCode;
                        $createProductData->packagingSize
                            = $internalDeliveryItem->packagingSize;
                        $createProductData->description
                            = $internalDeliveryItem->description;
                        $createProductData->unitCost = 0;
                        $createProductData->quantity = 0;
                        $createProductData->type
                            = Product::TYPE_AWAITING_PROCUREMENT;

                        $product = $this->productCreator->createProduct(
                            $createProductData
                        );

                        $newInternalDeliveryOrderItem
                            = new InternalDeliveryItemEloquent([
                            'quantity' => $internalDeliveryItem->quantity,
                            'packaging_size' => $internalDeliveryItem->packagingSize,
                            'description' => $internalDeliveryItem->description,
                        ]);
                        $newInternalDeliveryOrderItem->internalDeliveryOrder()
                            ->associate($internalDeliveryOrderEloquent->id);
                        $newInternalDeliveryOrderItem->product()->associate(
                            $product->id
                        );
                        $newInternalDeliveryOrderItem->save();

                        if (isset($productsQuantity[$existingProductId])) {
                            $productsQuantity[$existingProductId] += $internalDeliveryItem->quantity;
                        } else {
                            $productsQuantity[$existingProductId]
                                = $internalDeliveryItem->quantity;
                        }
                    }

                    $newInternalDeliveryOrderItem->load('product');
                    array_push(
                        $newInternalDeliveryOrderItems,
                        $newInternalDeliveryOrderItem->toArray()
                    );
                }

                if ($newlyDelivered !== null || $newlyFulfilled !== null) {
                    $inventoryId = $internalDeliveryOrderEloquent->inventory_id;

                    foreach (
                        $newInternalDeliveryOrderItems as
                        $newInternalDeliveryOrderItem
                    ) {
                        $productQuery = ProductEloquent::query();
                        $productQuery->whereInventoryIs($inventoryId);
                        $productQuery->addSelect(
                            'quantity',
                            'inventory_products.quantity'
                        );
                        $productQuery->where(
                            'quantity',
                            '>=',
                            $newInternalDeliveryOrderItem['quantity']
                        );
                        $productQuery->where(
                            'products.id',
                            $newInternalDeliveryOrderItem['product']['id']
                        );

                        if ($productQuery->doesntExist()) {
                            throw new InsufficientInventoryQuantity(
                                'Insufficient quantity for product. Please check with inventory',
                                422
                            );
                        }
                    }

                    if ($newlyFulfilled !== null) {
                        $internalDeliveryOrderEloquent->update([
                            'fulfilled_at' => $newlyFulfilled,
                        ]);
                    }

                    if ($newlyDelivered !== null) {
                        $internalDeliveryOrderEloquent->update([
                            'delivered_at' => $newlyDelivered,
                        ]);
                    }
                }

                if ($previousState->status !== Procurement::FULFILLED
                    && $data->status === Procurement::FULFILLED
                ) {
                    $destination = Inventory::query()->where(
                        'id',
                        $internalDeliveryOrderEloquent->destination_id
                    )->first();
                    $inventory = Inventory::query()->where(
                        'id',
                        $internalDeliveryOrderEloquent->inventory_id
                    )->first();

                    foreach ($productsQuantity as $productId => $quantity) {
                        $inventory->products()->where('product_id', $productId)
                            ->decrement('quantity', $quantity);
                        $this->inventoryProductThreshold->verify(
                            $productId,
                            $inventory->id
                        );
                        $destination->products()->where(
                            'product_id',
                            $productId
                        )->increment('quantity', $quantity);
                    }
                } elseif ($previousState->status === Procurement::FULFILLED
                    && $data->status !== Procurement::FULFILLED
                ) {
                    $destination = Inventory::query()->where(
                        'id',
                        $internalDeliveryOrderEloquent->destination_id
                    )->first();
                    $inventory = Inventory::query()->where(
                        'id',
                        $internalDeliveryOrderEloquent->inventory_id
                    )->first();

                    foreach ($productsQuantity as $productId => $quantity) {
                        $inventory->products()->where('product_id', $productId)
                            ->increment('quantity', $quantity);
                        $destination->products()->where(
                            'product_id',
                            $productId
                        )->decrement('quantity', $quantity);
                        $this->inventoryProductThreshold->verify(
                            $productId,
                            $destination->id
                        );
                    }
                }

                $internalDeliveryOrder = new InternalDeliveryOrder(
                    $internalDeliveryOrderEloquent->id
                );
                $internalDeliveryOrder->setFromArray(
                    $internalDeliveryOrderEloquent->toArray()
                );
                $internalDeliveryOrder->setInternalDeliveryOrderItemFromArray(
                    $newInternalDeliveryOrderItems
                );

                return $internalDeliveryOrder;
            }
        );
    }

    private function formatValue(string $key, $value): array
    {
        if ($key === 'is_flagged') {
            if ($value === true) {
                return ['flagged_at', now()];
            }

            return ['flagged_at', null];
        }

        if ($key === 'status') {
            $hashMap = [
                InternalDeliveryOrder::DELIVERED => 'delivered_at',
                InternalDeliveryOrder::FULFILLED => 'fulfilled_at',
            ];

            return [$hashMap[$value], now()];
        }

        return [$key, $value];
    }

    private function formatKey(string $key): string
    {
        return strtolower(
            preg_replace(
                [
                    '#([A-Z][a-z]*)(\d+[A-Z][a-z]*\d+)#',
                    '#([A-Z]+\d*)([A-Z])#',
                    '#([a-z]+\d*)([A-Z])#',
                    '#([^_\d])([A-Z][a-z])#',
                ],
                '$1_$2',
                $key
            )
        );
    }
}
