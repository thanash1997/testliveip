<?php

namespace IPI\Core\Order;

use App\Models\ExternalDeliveryOrder as ExternalDeliveryOrderEloquent;
use IPI\Core\DTO\IndexFilter;
use IPI\Core\Entities\ExternalDeliveryOrder;
use IPI\Core\Filters\EloquentIndexQueryBuilder;
use IPI\Core\General\EloquentResponseMetaBuilder;
use Illuminate\Database\Eloquent\Collection as EloquentCollection;
use Illuminate\Support\Collection as SupportCollection;

class GetExternalDeliverOrders
{
    public function getExternalDeliveryOrders(IndexFilter $data): array
    {
        $eloquentOrderQuery = ExternalDeliveryOrderEloquent::query()->withCreator()->with($data->relationships);
        $queryBuilder = new EloquentIndexQueryBuilder($eloquentOrderQuery);
        $eloquentQueryBuilder = $queryBuilder->execute($data, 'external_delivery_orders');

        if (!empty($data->companyUuid)) {
            $eloquentQueryBuilder->whereHas('customer', function ($query) use ($data) {
                return $query->where('companies.uuid', $data->companyUuid);
            });
        }

        if ($data->paginateResult) {
            $externalDeliveryOrders = $eloquentQueryBuilder->paginate($data->perPage);
            $responseMetaBuilder = new EloquentResponseMetaBuilder($externalDeliveryOrders);

            return [
                $this->prepareExternalDeliveryOrders($externalDeliveryOrders->getCollection()),
                $responseMetaBuilder->execute(),
            ];
        }

        $externalDeliveryOrders = $eloquentQueryBuilder->get();
        $externalDeliveryOrders = $this->prepareExternalDeliveryOrders($externalDeliveryOrders);

        return [$externalDeliveryOrders, []];
    }

    private function prepareExternalDeliveryOrders(EloquentCollection|SupportCollection $collection): array
    {
        $externalDeliveryOrders = [];

        foreach ($collection as $item) {
            $externalDeliveryOrder = new ExternalDeliveryOrder($item->id);
            $externalDeliveryOrder->setFromArray($item->toArray());
            $externalDeliveryOrder->setExternalDeliveryOrderItemFromArray($item->orderItems->toArray());

            $externalDeliveryOrders[] = $externalDeliveryOrder;
        }

        return $externalDeliveryOrders;
    }
}
