<?php

namespace IPI\Core\Order;

use App\Models\Order as OrderEloquent;
use IPI\Core\Entities\Company;
use IPI\Core\Entities\File;
use IPI\Core\Entities\Order;
use IPI\Core\Entities\OrderItem;
use IPI\Core\Entities\ProductionMaterial;
use IPI\Core\Entities\Shipment;

class GetSingleOrder
{
    public function getOrder(string $uuid): Order
    {
        $eloquentQueryBuilder = OrderEloquent::query()->with([
            'personInCharge',
            'shipment',
            'customer',
            'orderItems.product',
            'orderItems.materialLists.productionMaterials.product',
            'audits.user',
            'media',
        ]);
        $order = $eloquentQueryBuilder->where('uuid', $uuid)->withCreator()->first();

        return $this->prepareOrder($order);
    }

    private function prepareOrder(OrderEloquent $orderEloquent): Order
    {
        $order = new Order($orderEloquent->id);
        $order->setFromArray($orderEloquent->toArray());
        $order->setAudits($orderEloquent->audits->toArray());

        $orderItems = [];

        foreach ($orderEloquent->orderItems as $orderItemEloquent) {
            $productionMaterials = [];
            $orderItem = new OrderItem($orderItemEloquent->id);
            $orderItem->setFromArray($orderItemEloquent->toArray());

            foreach ($orderItemEloquent->materialLists as $materialList) {
                foreach ($materialList->productionMaterials as $productionMaterialEloquent) {
                    $productionMaterial = new ProductionMaterial($productionMaterialEloquent->id);
                    $productionMaterial->productId = $productionMaterialEloquent->product->id;
                    $productionMaterial->totalCost = $productionMaterialEloquent->total_cost;
                    $productionMaterial->percentage = $productionMaterialEloquent->percentage;
                    $productionMaterial->productCode = $productionMaterialEloquent->product->product_code;
                    $productionMaterial->quantity = (float)$productionMaterialEloquent->quantity / 1000;

                    $productionMaterials[] = $productionMaterial;
                }
            }

            $orderItem->productionMaterials = $productionMaterials;
            $orderItems[] = $orderItem;
        }

        $customer = new Company();
        $customer->uuid = $orderEloquent->customer->uuid;
        $customer->companyCode = $orderEloquent->customer->company_code;
        $customer->name = $orderEloquent->customer->name;
        $customer->id = $orderEloquent->customer->id;

        $shipment = new Shipment($orderEloquent->shipment->id);
        $shipment->name = $orderEloquent->shipment->name;
        $shipment->receiverName = $orderEloquent->shipment->receiver_name ?? null;
        $shipment->email = $orderEloquent->shipment->email ?? null;

        $files = [];
        $eloquentFiles = $orderEloquent->media->toArray();

        foreach ($eloquentFiles as $eloquentFile) {
            $file = new File();
            $file->setFromArray($eloquentFile);

            $files[] = $file;
        }

        $order->orderItems = $orderItems;
        $order->customer = $customer;
        $order->shipment = $shipment;
        $order->files = $files;

        return $order;
    }
}
