<?php

namespace IPI\Core\Order;

use App\Exceptions\InsufficientInventoryQuantity;
use App\Models\ExternalDeliveryItem as ExternalDeliveryItemEloquent;
use App\Models\ExternalDeliveryOrder as ExternalDeliveryOrderEloquent;
use App\Models\Inventory;
use App\Models\Module;
use App\Models\Product;
use Illuminate\Support\Facades\DB;
use IPI\Core\DTO\CreateExternalDeliveryOrderData;
use IPI\Core\DTO\CreateNotificationData;
use IPI\Core\Entities\ExternalDeliveryOrder;
use IPI\Core\General\NotificationCreator;

class ExternalDeliveryOrderCreator
{
    private NotificationCreator $notificationCreator;

    public function __construct(NotificationCreator $notificationCreator)
    {
        $this->notificationCreator = $notificationCreator;
    }

    /**
     * @param CreateExternalDeliveryOrderData $data
     *
     * @return ExternalDeliveryOrder
     * @throws InsufficientInventoryQuantity
     */
    public function createExternalDeliveryOrder(CreateExternalDeliveryOrderData $data): ExternalDeliveryOrder
    {
        $this->checkQuantity($data->createExternalDeliverOrderItemData);

        return DB::transaction(function () use ($data) {
            $latestEDO = ExternalDeliveryOrderEloquent::query()->orderBy('id', 'desc')->first();

            $externalDeliveryOrderEloquent = new ExternalDeliveryOrderEloquent([
                'batch_no' => $data->batchNo !== null ? $this->generateBatchNo($data->batchNo) : null,
                'delivery_order_no' => $this->generateNextDeliveryOrderNo($latestEDO),
                'courier_name' => $data->courierName ?? null,
                'vehicle_no' => $data->vehicleNo ?? null,
                'tracking_no' => $data->trackingNo ?? null,
                'receipt_no' => $data->receiptNo ?? null,
                'description' => $data->description ?? null,
                'flag_reason' => $data->flagReason ?? null,
                'estimated_delivery_date' => $data->estimatedDeliveryDate,
                'fulfilled_at' => $data->status === ExternalDeliveryOrder::STATUS_FULFILLED ? now() : null,
                'cancelled_at' => $data->status === ExternalDeliveryOrder::STATUS_CANCELLED ? now() : null,
                'flagged_at' => $data->isFlagged === true ? now() : null,
            ]);

            $externalDeliveryOrderEloquent->address()->associate($data->addressId);
            $externalDeliveryOrderEloquent->customer()->associate($data->customerId);
            $externalDeliveryOrderEloquent->save();

            if (isset($data->remark)) {
                $externalDeliveryOrderEloquent->remarks()->create(['body' => $data->remark]);
            }

            foreach ($data->createExternalDeliverOrderItemData as $item) {
                $externalDeliveryItemEloquent = new ExternalDeliveryItemEloquent([
                    'quantity' => $item->quantity,
                    'packaging_size' => $item->packagingSize,
                    'description' => $item->description,
                ]);

                $externalDeliveryItemEloquent->product()->associate($item->productId);
                $externalDeliveryItemEloquent->externalDeliveryOrder()->associate($externalDeliveryOrderEloquent->id);

                if (!empty($item->orderId)) {
                    $externalDeliveryItemEloquent->order()->associate($item->orderId);
                }

                $externalDeliveryItemEloquent->save();
            }

            return $this->prepareOrder($externalDeliveryOrderEloquent);
        });
    }

    private function prepareOrder(ExternalDeliveryOrderEloquent $externalDeliveryOrderEloquent): ExternalDeliveryOrder
    {
        $externalDeliveryOrderEloquent->loadMissing(['orderItems.product', 'orderItems.order']);
        $externalDeliveryOrder = new ExternalDeliveryOrder($externalDeliveryOrderEloquent->id);
        $externalDeliveryOrder->setFromArray($externalDeliveryOrderEloquent->toArray());
        $externalDeliveryOrder->setExternalDeliveryOrderItemFromArray(
            $externalDeliveryOrderEloquent->orderItems->toArray()
        );
        $this->generateNotification($externalDeliveryOrder);

        return $externalDeliveryOrder;
    }

    private function generateBatchNo($batchNo): string
    {
        return sprintf("%06d", $batchNo);
    }

    private function generateNextDeliveryOrderNo($latestEDO): string
    {
        $prefix = 'EDO';

        if ($latestEDO === null) {
            $runningNumber = sprintf("%06d", 1);

            return strtoupper("{$prefix}{$runningNumber}");
        }

        $currentNumber = (int)substr($latestEDO->delivery_order_no, -6);
        $runningNumber = sprintf("%06d", $currentNumber + 1);

        return strtoupper("{$prefix}{$runningNumber}");
    }

    private function generateNotification(ExternalDeliveryOrder $externalDeliveryOrder): void
    {
        $moduleIds = Module::query()->whereIn('slug', [Module::WAREHOUSE])->pluck('id')->toArray();
        $createNotificationData = new CreateNotificationData();
        $createNotificationData->description
            = "External delivery order {$externalDeliveryOrder->deliveryOrderNo} is created.";
        $createNotificationData->viewActionLink = route(
            'warehouse.external-do.details',
            ['uuid' => $externalDeliveryOrder->uuid]
        );
        $createNotificationData->moduleIds = $moduleIds;

        $this->notificationCreator->createNotification($createNotificationData);
    }

    /**
     * @param array $orderItems
     *
     * @throws InsufficientInventoryQuantity
     */
    private function checkQuantity(array $orderItems): void
    {
        $warehouseInventory = Inventory::query()->where('slug', Inventory::WAREHOUSE)->first();

        foreach ($orderItems as $orderItem) {
            $productQuery = Product::query();
            $productQuery->whereInventoryIs($warehouseInventory->id);
            $productQuery->addSelect('quantity', 'inventory_products.quantity');
            $productQuery->where('quantity', '>=', $orderItem->quantity);
            $productQuery->where('products.id', $orderItem->productId);

            if ($productQuery->doesntExist()) {
                throw new InsufficientInventoryQuantity(
                    'Insufficient quantity for product. Please check with inventory',
                    422
                );
            }
        }
    }
}
