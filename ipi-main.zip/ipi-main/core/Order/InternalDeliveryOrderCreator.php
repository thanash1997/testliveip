<?php

namespace IPI\Core\Order;

use App\Exceptions\InsufficientInventoryQuantity;
use App\Models\InternalDeliveryItem as InternalDeliveryItemEloquent;
use App\Models\InternalDeliveryOrder as InternalDeliveryOrderEloquent;
use App\Models\Module;
use App\Models\Product as ProductEloquent;
use Illuminate\Support\Facades\DB;
use IPI\Core\DTO\CreateInternalDeliveryOrderData;
use IPI\Core\DTO\CreateNotificationData;
use IPI\Core\DTO\CreateProductData;
use IPI\Core\Entities\InternalDeliveryOrder;
use IPI\Core\Entities\Product;
use IPI\Core\General\NotificationCreator;
use IPI\Core\Product\ProductCreator;

class InternalDeliveryOrderCreator
{
    private ProductCreator $productCreator;
    private NotificationCreator $notificationCreator;

    public function __construct(ProductCreator $productCreator, NotificationCreator $notificationCreator)
    {
        $this->productCreator = $productCreator;
        $this->notificationCreator = $notificationCreator;
    }

    /**
     * @param CreateInternalDeliveryOrderData $data
     *
     * @return InternalDeliveryOrder
     * @throws InsufficientInventoryQuantity
     */
    public function createInternalDeliveryOrder(CreateInternalDeliveryOrderData $data): InternalDeliveryOrder
    {
        $this->checkQuantity($data->createInternalDeliveryItemData, $data->inventoryId);

        return DB::transaction(function () use ($data) {
            $latestIDO = InternalDeliveryOrderEloquent::query()->orderBy('id', 'desc')->first();

            $internalDeliveryOrderEloquent = new InternalDeliveryOrderEloquent([
                'batch_no' => $data->batchNo ? $this->generateBatchNo($data->batchNo) : null,
                'delivery_order_no' => $this->generateNextDeliveryOrderNo($latestIDO),
                'usage' => $data->usage,
                'origin' => $data->origin,
                'description' => $data->description ?? null,
                'flag_reason' => $data->isFlagged ? $data->flagReason : null,
                'estimated_delivery_date' => $data->estimatedDeliveryDate,
                'flagged_at' => $data->isFlagged ? now() : null,
                'delivered_at' => $data->status === InternalDeliveryOrder::DELIVERED ? now() : null,
                'fulfilled_at' => $data->status === InternalDeliveryOrder::FULFILLED ? now() : null,
            ]);
            $internalDeliveryOrderEloquent->personInCharge()->associate($data->picId);
            $internalDeliveryOrderEloquent->destination()->associate($data->destinationId);
            $internalDeliveryOrderEloquent->inventory()->associate($data->inventoryId);
            $internalDeliveryOrderEloquent->save();

            if (isset($data->remark)) {
                $internalDeliveryOrderEloquent->remarks()->create(['body' => $data->remark]);
            }

            foreach ($data->createInternalDeliveryItemData as $item) {
                $isExistingProduct = isset($item->productId);
                $internalDeliverItemEloquent = new InternalDeliveryItemEloquent([
                    'quantity' => $item->quantity,
                    'packaging_size' => $item->packagingSize,
                    'description' => $item->description,
                ]);

                if ($isExistingProduct) {
                    $internalDeliverItemEloquent->product()->associate($item->productId);
                }

                if (!$isExistingProduct) {
                    $existingProduct = ProductEloquent::query()->where('product_code', $item->productCode)->first();

                    if ($existingProduct) {
                        $internalDeliverItemEloquent->product()->associate($existingProduct->id);
                    } else {
                        $createProductData = new CreateProductData();
                        $createProductData->productCode = $item->productCode;
                        $createProductData->packagingSize = $item->packagingSize;
                        $createProductData->description = $item->description;
                        $createProductData->unitCost = 0;
                        $createProductData->quantity = 0;
                        $createProductData->type = Product::TYPE_AWAITING_PROCUREMENT;

                        $product = $this->productCreator->createProduct($createProductData);
                        $internalDeliverItemEloquent->product()->associate($product->id);
                    }
                }

                $internalDeliverItemEloquent->internalDeliveryOrder()->associate($internalDeliveryOrderEloquent->id);
                $internalDeliverItemEloquent->save();
            }

            return $this->prepareOrder($internalDeliveryOrderEloquent);
        });
    }

    private function prepareOrder(InternalDeliveryOrderEloquent $internalDeliveryOrderEloquent): InternalDeliveryOrder
    {
        $internalDeliveryOrderEloquent->loadMissing('orderItems.product');
        $internalDeliveryOrder = new InternalDeliveryOrder($internalDeliveryOrderEloquent->id);
        $internalDeliveryOrder->setFromArray($internalDeliveryOrderEloquent->toArray());
        $internalDeliveryOrder->setInternalDeliveryOrderItemFromArray(
            $internalDeliveryOrderEloquent->orderItems->toArray()
        );
        $this->generateNotification($internalDeliveryOrder);

        return $internalDeliveryOrder;
    }

    private function generateBatchNo($batchNo): string
    {
        return sprintf("%06d", $batchNo);
    }

    private function generateNextDeliveryOrderNo($latestIDO): string
    {
        $prefix = 'IDO';

        if ($latestIDO === null) {
            $runningNumber = sprintf("%06d", 1);

            return strtoupper("{$prefix}{$runningNumber}");
        }

        $currentNumber = (int)substr($latestIDO->delivery_order_no, -6);
        $runningNumber = sprintf("%06d", $currentNumber + 1);

        return strtoupper("{$prefix}{$runningNumber}");
    }

    private function generateNotification(InternalDeliveryOrder $internalDeliveryOrder): void
    {
        $moduleIds = Module::query()->whereIn('slug', [Module::PRODUCTION, Module::WAREHOUSE])->pluck('id')->toArray();
        $createNotificationData = new CreateNotificationData();
        $createNotificationData->description =
            "Internal delivery order {$internalDeliveryOrder->deliveryOrderNo} is created.";
        $createNotificationData->viewActionLink =
            route('warehouse.internal-do.details', ['uuid' => $internalDeliveryOrder->uuid]);
        $createNotificationData->moduleIds = $moduleIds;

        $this->notificationCreator->createNotification($createNotificationData);
    }

    /**
     * @param array $orderItems
     * @param int $inventoryId
     *
     * @throws InsufficientInventoryQuantity
     */
    private function checkQuantity(array $orderItems, int $inventoryId): void
    {
        foreach ($orderItems as $orderItem) {
            $productQuery = ProductEloquent::query();
            $productQuery->whereInventoryIs($inventoryId);
            $productQuery->addSelect('quantity', 'inventory_products.quantity');
            $productQuery->where('quantity', '>=', $orderItem->quantity);
            $productQuery->where('products.id', $orderItem->productId);

            if ($productQuery->doesntExist()) {
                throw new InsufficientInventoryQuantity(
                    'Insufficient quantity for product. Please check with inventory',
                    422
                );
            }
        }
    }
}
