<?php

namespace IPI\Core\Order;

use App\Models\Formula as FormulaEloquent;
use App\Models\ProductionMaterial as ProductMaterialEloquent;
use App\Models\MaterialList as MaterialListEloquent;
use App\Models\OrderItem as OrderItemEloquent;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class ReplicateIngredients
{
    public function replicateToOrderItem(int $orderItemId): void
    {
        $orderItem = OrderItemEloquent::query()->findOrFail($orderItemId);
        $formula = $this->getFormula($orderItem->product_id);

        DB::transaction(function () use ($formula, $orderItemId, $orderItem) {
            foreach ($formula->ingredientLists as $ingredientList) {
                $materialList = new MaterialListEloquent([
                    'remark' => $ingredientList->remark,
                    'total_cost' => $ingredientList->total_cost,
                    'position' => $ingredientList->position,
                ]);
                $materialList->orderItem()->associate($orderItemId);
                $materialList->ingredientList()->associate($ingredientList->id);
                $materialList->save();

                foreach (
                    $ingredientList->ingredientListItems as $ingredientListItem
                ) {
                    $productMaterial = new ProductMaterialEloquent([
                        'total_cost' => $ingredientListItem->total_cost,
                        'percentage' => $ingredientListItem->percentage,
                        'quantity' => (float)$ingredientListItem->percentage / 100
                            * ($orderItem->quantity / 1000) * 1000,
                        'remark' => $ingredientListItem->remark,
                    ]);
                    $productMaterial->product()->associate($ingredientListItem->product_id);
                    $productMaterial->ingredientListItem()->associate($ingredientListItem->id);
                    $productMaterial->materialList()->associate($materialList->id);
                    $productMaterial->save();
                }
            }
        });
    }

    private function getFormula(int $productId): FormulaEloquent|Model
    {
        return FormulaEloquent::query()
            ->where('product_id', '=', $productId)
            ->with(['ingredientLists.ingredientListItems.product'])
            ->first(['id']);
    }
}
