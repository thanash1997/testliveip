<?php

namespace IPI\Core\Order;

use App\Models\Inventory;
use IPI\Core\DTO\CreateInternalDeliveryOrderData;
use IPI\Core\DTO\CreateProductRequisitionItemData;
use IPI\Core\Entities\ProductRequisition;
use App\Exceptions\InsufficientInventoryQuantity;

class GenerateInternalDeliveryOrder
{
    private InternalDeliveryOrderCreator $internalDeliveryOrderCreator;

    public function __construct(InternalDeliveryOrderCreator $internalDeliveryOrderCreator)
    {
        $this->internalDeliveryOrderCreator = $internalDeliveryOrderCreator;
    }

    /**
     * @param ProductRequisition $productRequisition
     *
     * @throws InsufficientInventoryQuantity
     */
    public function generate(ProductRequisition $productRequisition)
    {
        $inventories = Inventory::all();
        $warehouseInventory = $inventories->where('slug', Inventory::WAREHOUSE)->first();
        $productionInventory = $inventories->where('slug', Inventory::PRODUCTION)->first();

        $createInternalDeliveryOrderData = new CreateInternalDeliveryOrderData();
        $createInternalDeliveryOrderData->picId = auth()->user()->id;
        $createInternalDeliveryOrderData->destinationId = $productionInventory->id;
        $createInternalDeliveryOrderData->inventoryId = $warehouseInventory->id;
        $createInternalDeliveryOrderData->usage = $productRequisition->usage;
        $createInternalDeliveryOrderData->batchNo = $productRequisition->orderBatchNo;
        $createInternalDeliveryOrderData->origin = $productRequisition->origin;
        $createInternalDeliveryOrderData->estimatedDeliveryDate = $productRequisition->createdAt; // TODO: What's this???

        $createInternalDeliveryOrderItems = [];

        foreach ($productRequisition->productRequisitionItems as $productRequisitionItem) {
            $createInternalDeliveryOrderItem = new CreateProductRequisitionItemData();
            $createInternalDeliveryOrderItem->productId = $productRequisitionItem->productId;
            $createInternalDeliveryOrderItem->packagingSize = $productRequisitionItem->packagingSize;
            $createInternalDeliveryOrderItem->quantity = $productRequisitionItem->quantity;
            $createInternalDeliveryOrderItem->description = $productRequisitionItem->description;

            $createInternalDeliveryOrderItems[] = $createInternalDeliveryOrderItem;
        }

        $createInternalDeliveryOrderData->createInternalDeliveryItemData = $createInternalDeliveryOrderItems;
        $this->internalDeliveryOrderCreator->createInternalDeliveryOrder($createInternalDeliveryOrderData);
    }
}
