<?php

namespace IPI\Core\Order;

use App\Exceptions\InvalidFlowException;
use App\Models\Formula as FormulaEloquent;
use App\Models\Inventory;
use App\Models\Order as OrderEloquent;
use App\Models\ProductionMaterial;
use Illuminate\Support\Facades\DB;
use IPI\Core\DTO\UpdateOrderData;
use IPI\Core\Entities\Order;
use IPI\Core\Entities\OrderItem;

class UpdateSingleOrder
{
    private const UPDATABLE = [
        'description',
        'total_cost',
        'status',
        'estimated_delivered_at',
    ];

    public function updateOrder(UpdateOrderData $data, string $uuid): Order
    {
        $orderEloquent = OrderEloquent::query()->where('uuid', $uuid)->first();

        return DB::transaction(function () use ($data, $orderEloquent) {
            $values = get_object_vars($data);
            $previousState = new Order($orderEloquent->id);
            $previousState->setFromArray($orderEloquent->toArray());

            foreach ($values as $key => $value) {
                if ($value === null) {
                    continue;
                }

                $key = $this->formatKey($key);
                if (in_array($key, self::UPDATABLE)) {
                    if ($key === 'status' && $value === 'pending') {
                        $orderEloquent->estimated_delivered_at = null;
                        $orderEloquent->production_started_at = null;
                        $orderEloquent->pending_for_material_at = null;
                        $orderEloquent->scheduled_for_planning_at = null;
                        $orderEloquent->completed_at = null;
                        $orderEloquent->cancelled_at = null;
                        $orderEloquent->halted_at = null;
                        continue;
                    }

                    if ($key === 'status' && $value !== 'halted') {
                        $orderEloquent->halted_at = null;
                    }

                    [$modelKey, $value] = $this->formatValue($key, $value);
                    $orderEloquent->$modelKey = $value;
                }
            }

            if (
                $previousState->status === Order::STATUS_COMPLETED
                && $data->status === Order::STATUS_IN_PRODUCTION
            ) {
                $orderEloquent->completed_at = null;
            }

            $orderEloquent->save();

            foreach ($data->createOrderItems as $createOrderItem) {
                $orderEloquent->orderItems()->where(
                    'product_id',
                    $createOrderItem->productId
                )->update([
                    'quantity' => $createOrderItem->quantity,
                    'total_cost' => $createOrderItem->totalCost,
                ]);
            }

            if (isset($data->files)) {
                foreach ($data->files as $file) {
                    $orderEloquent->addMediaFromDisk($file)->toMediaCollection();
                }
            }

            $orderEloquent->loadMissing('orderItems.product');
            $order = new Order($orderEloquent->id);
            $order->setFromArray($orderEloquent->toArray());

            if (
                $previousState->status === Order::STATUS_CANCELLED
                && $data->status !== Order::STATUS_CANCELLED
            ) {
                throw new InvalidFlowException('Cancelled order cannot be revived', 400);
            }

            if (
                $previousState->status !== Order::STATUS_IN_PRODUCTION
                && $data->status === Order::STATUS_COMPLETED
            ) {
                throw new InvalidFlowException('Completed order must be in-production first', 400);
            }

            $orderItems = [];

            foreach ($orderEloquent->orderItems as $orderItemEloquent) {
                $orderItem = new OrderItem($orderItemEloquent->id);
                $orderItem->setFromArray($orderItemEloquent->toArray());

                $orderItems[] = $orderItem;

                if (
                    (in_array($previousState->status, Order::STARTING_STATUSES)
                        || $previousState->status === Order::STATUS_HALTED)
                    && $order->status === Order::STATUS_IN_PRODUCTION
                ) {
                    $inventory = Inventory::query()->where('slug', Inventory::PRODUCTION)->first();
                    $formula = FormulaEloquent::query()
                        ->with('ingredientLists.ingredientListItems.product.inventories')
                        ->where('product_id', $orderItem->productId)
                        ->first();

                    foreach ($formula->ingredientLists as $ingredientList) {
                        foreach ($ingredientList->ingredientListItems as $ingredientItem) {
                            $ingredientQuantity = ($ingredientItem->percentage / 100) * $orderItem->quantity;
                            $product = $ingredientItem->product;

                            $inventory->products()
                                ->where('product_id', $product->id)
                                ->decrement('quantity', $ingredientQuantity);
                        }
                    }
                } elseif (
                    $previousState->status == Order::STATUS_IN_PRODUCTION
                    && in_array($order->status, Order::CANCELLING_STATUSES)
                ) {
                    $inventory = Inventory::query()->where('slug', Inventory::PRODUCTION)->first();
                    $formula = FormulaEloquent::query()
                        ->with('ingredientLists.ingredientListItems.product.inventories')
                        ->where('product_id', $orderItem->productId)
                        ->first();

                    foreach ($formula->ingredientLists as $ingredientList) {
                        foreach ($ingredientList->ingredientListItems as $ingredientItem) {
                            $ingredientQuantity = ($ingredientItem->percentage / 100) * $orderItem->quantity;
                            $product = $ingredientItem->product;

                            $inventory->products()->where(
                                'product_id',
                                $product->id
                            )->increment('quantity', $ingredientQuantity);
                        }
                    }
                } elseif (
                    $previousState->status == Order::STATUS_IN_PRODUCTION
                    && $order->status == Order::STATUS_COMPLETED
                ) {
                    $inventory = Inventory::query()->where('slug', Inventory::PRODUCTION)->first();

                    foreach ($data->updateProductionMaterialData as $productionMaterialData) {
                        $productionMaterialEloquent = ProductionMaterial::query()
                            ->with('ingredientListItem')
                            ->find($productionMaterialData->id);
                        $originalQuantity = floatval(
                            preg_replace(
                                '/[^\d.]/',
                                '',
                                number_format((float)$productionMaterialEloquent->quantity / 1000, 3)
                            )
                        );
                        $newQuantity = floatval(
                            preg_replace('/[^\d.]/', '', number_format($productionMaterialData->quantity, 3))
                        );;

                        if ($newQuantity > $originalQuantity) {
                            $diff = ($newQuantity - $originalQuantity) * 1000;
                            $inventory->products()->where(
                                'product_id',
                                $productionMaterialData->productId
                            )->decrement('quantity', $diff);

                            $productionMaterialEloquent->update([
                                'quantity' => $newQuantity * 1000,
                                // 'percentage' => ($newQuantity * 1000) / $orderItem->quantity * 100,
                            ]);
                        } else {
                            if ($newQuantity < $originalQuantity) {
                                $diff = ($originalQuantity - $newQuantity) * 1000;
                                $inventory->products()->where(
                                    'product_id',
                                    $productionMaterialData->productId
                                )->increment('quantity', $diff);

                                $productionMaterialEloquent->update([
                                    'quantity' => $newQuantity * 1000,
                                    // 'percentage' => ($newQuantity * 1000) / $orderItem->quantity * 100,
                                ]);
                            }
                        }
                    }

                    $inventory->products()->where(
                        'product_id',
                        $orderItem->productId
                    )->increment('quantity', $orderItem->quantity);
                } elseif (
                    $previousState->status === Order::STATUS_COMPLETED
                    && !empty($data->status)
                    && $data->status !== Order::STATUS_COMPLETED
                ) {
                    $inventory = Inventory::query()->where('slug', Inventory::PRODUCTION)->first();
                    $inventory->products()->where(
                        'product_id',
                        $orderItem->productId
                    )->decrement('quantity', $orderItem->quantity);

                    $orderEloquent->completed_at = null;
                }
            }

            $order->orderItems = $orderItems;

            return $order;
        });
    }

    private function formatValue(string $key, $value)
    {
        if ($key === 'status') {
            $hashMap = [
                Order::STATUS_IN_PRODUCTION => 'production_started_at',
                Order::STATUS_PENDING_MATERIAL => 'pending_for_material_at',
                Order::STATUS_PENDING_PLANNING => 'scheduled_for_planning_at',
                Order::STATUS_COMPLETED => 'completed_at',
                Order::STATUS_CANCELLED => 'cancelled_at',
                Order::STATUS_HALTED => 'halted_at',
            ];

            return [$hashMap[$value], now()];
        }

        return [$key, $value];
    }

    private function formatKey(string $key): string
    {
        return strtolower(
            preg_replace(
                [
                    '#([A-Z][a-z]*)(\d+[A-Z][a-z]*\d+)#',
                    '#([A-Z]+\d*)([A-Z])#',
                    '#([a-z]+\d*)([A-Z])#',
                    '#([^_\d])([A-Z][a-z])#',
                ],
                '$1_$2',
                $key
            )
        );
    }
}
