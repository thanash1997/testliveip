<?php

namespace Database\Factories;

use App\Models\Product;
use IPI\Core\Entities\Product as ProductEntity;
use Illuminate\Database\Eloquent\Factories\Factory;

class ProductFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Product::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'product_code' => $this->faker->toUpper($this->faker->word),
            'description' => $this->faker->sentence,
            'name' => $this->faker->word,
            'unit_cost' => $this->faker->numberBetween(5000, 10000),
            'threshold' => $this->faker->numberBetween(10000, 50000),
            'packaging_size' => $this->faker->word,
            'type' => ProductEntity::TYPE_MATERIAL,
            'quantity' => $this->faker->numberBetween(7000, 60000)
        ];
    }
}
