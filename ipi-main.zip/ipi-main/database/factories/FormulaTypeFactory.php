<?php

namespace Database\Factories;

use App\Models\FormulaType;
use Illuminate\Database\Eloquent\Factories\Factory;

class FormulaTypeFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = FormulaType::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'type' => strtoupper($this->faker->word),
            'display_text' => $this->faker->word,
        ];
    }
}
