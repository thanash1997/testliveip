<?php

namespace Database\Factories;

use App\Models\PurchaseOrderItem;
use Illuminate\Database\Eloquent\Factories\Factory;

class PurchaseOrderItemFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = PurchaseOrderItem::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'quantity' => $this->faker->numberBetween(5000, 40000),
            'packaging_size' => $this->faker->word,
            'description' => $this->faker->sentence,
            'total_cost' => $this->faker->numberBetween(1000, 60000),
            'unit_cost' => $this->faker->numberBetween(1000, 5000),
        ];
    }
}
