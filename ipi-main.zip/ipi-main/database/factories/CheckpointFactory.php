<?php

namespace Database\Factories;

use App\Models\Checkpoint;
use Illuminate\Database\Eloquent\Factories\Factory;

class CheckpointFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Checkpoint::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'type' => Checkpoint::TYPE_SR_SAMP,
            'range_min' => $this->faker->numberBetween(0, 50),
            'range_max' => $this->faker->numberBetween(51, 100),
            'tolerance_min' => $this->faker->numberBetween(0, 50),
            'tolerance_max' => $this->faker->numberBetween(51, 100),
            'equipment' => $this->faker->sentence,
            'remark' => $this->faker->sentence,
        ];
    }
}
