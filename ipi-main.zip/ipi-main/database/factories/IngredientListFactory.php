<?php

namespace Database\Factories;

use App\Models\IngredientList;
use Illuminate\Database\Eloquent\Factories\Factory;

class IngredientListFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = IngredientList::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'remark' => $this->faker->word,
            'total_cost' => $this->faker->numberBetween(1000, 5000),
            'position' => 1,
        ];
    }
}
