<?php

namespace Database\Factories;

use App\Models\Company;
use Illuminate\Database\Eloquent\Factories\Factory;

class CompanyFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Company::class;

    /**
     * Define the model's default state.
     *
     * To use this factory, you will need to pass the following:
     * 1. phone_number_id (Compulsory) - Create a phone number first before using this factory.
     * 2. Assign a type, either customer or supplier using the type cont in the Model.
     * 2. address_id (Compulsory) - Create an address first before using this factory.
     *
     * Note: Refer to Feature/Company/EmployeeCreatorTest to see how to use this factory
     *
     * @return array
     */
    public function definition()
    {
        return [
            'name' => $this->faker->company,
            'registration_number' => $this->faker->swiftBicNumber,
            'website_url' => $this->faker->url,
            'sst_number' => $this->faker->swiftBicNumber,
            'gst_number' => $this->faker->swiftBicNumber,
            'company_code' => strtoupper($this->faker->word)
        ];
    }
}
