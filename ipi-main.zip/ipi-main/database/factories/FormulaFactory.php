<?php

namespace Database\Factories;

use App\Models\Formula;
use Illuminate\Database\Eloquent\Factories\Factory;
use IPI\Core\Entities\Product;

class FormulaFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Formula::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'product_name' => $this->faker->word,
            'remark' => $this->faker->sentence,
            'total_cost' => $this->faker->numberBetween(1000, 50000),
            'type' => Product::TYPE_FORMULA
        ];
    }
}
