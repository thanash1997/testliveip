<?php

namespace Database\Factories;

use App\Models\IngredientListItem;
use Illuminate\Database\Eloquent\Factories\Factory;

class IngredientListItemFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = IngredientListItem::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'total_cost' => $this->faker->numberBetween(2000, 7000),
            'percentage' => $this->faker->randomFloat(2, 60, 90),
            'remark' => $this->faker->sentence,
        ];
    }
}
