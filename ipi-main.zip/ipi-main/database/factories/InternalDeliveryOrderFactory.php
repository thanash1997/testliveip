<?php

namespace Database\Factories;

use App\Models\InternalDeliveryOrder;
use Illuminate\Database\Eloquent\Factories\Factory;

class InternalDeliveryOrderFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = InternalDeliveryOrder::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'usage' => $this->faker->word,
            'origin' => $this->faker->sentence,
            'description' => $this->faker->sentence,
            'estimated_delivery_date' => $this->faker->dateTimeBetween('+7 days', '+24 days'),
        ];
    }
}
