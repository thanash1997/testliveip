<?php

namespace Database\Factories;

use App\Models\PurchaseOrder;
use Illuminate\Database\Eloquent\Factories\Factory;

class PurchaseOrderFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = PurchaseOrder::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'usage' => $this->faker->word,
            'po_number' => $this->faker->uuid,
            'total_cost' => $this->faker->numberBetween(10000, 40000),
            'expected_receive_date' => $this->faker->dateTimeBetween('+5 days', '+2 weeks'),
        ];
    }
}
