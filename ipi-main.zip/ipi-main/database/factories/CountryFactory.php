<?php

namespace Database\Factories;

use App\Models\Country;
use Illuminate\Database\Eloquent\Factories\Factory;

class CountryFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Country::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'name' => $this->faker->country,
            'iso_3166_alpha_2_code' => $this->faker->countryCode,
            'iso_4217_currency_code' => $this->faker->currencyCode,
            'geo_name_id' => $this->faker->randomDigit,
        ];
    }
}
