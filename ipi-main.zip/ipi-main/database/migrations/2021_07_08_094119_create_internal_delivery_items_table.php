<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateInternalDeliveryItemsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('internal_delivery_items', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('internal_delivery_order_id');
            $table->unsignedBigInteger('product_id');
            $table->integer('quantity');
            $table->string('packaging_size');
            $table->string('description')->nullable();

            $table->timestamps();
            $table->softDeletes();
            $table->foreign('internal_delivery_order_id')->references('id')->on('internal_delivery_orders');
            $table->foreign('product_id')->references('id')->on('products');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('internal_delivery_items');
    }
}
