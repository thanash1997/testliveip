<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductRequisitionItemsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product_requisition_items', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('product_requisition_id');
            $table->unsignedBigInteger('product_id'); 
            $table->integer('quantity');
            $table->string('packaging_size');
            $table->string('description');

            $table->timestamps();
            $table->softDeletes();
            $table->foreign('product_requisition_id')->references('id')->on('product_requisitions');
            $table->foreign('product_id')->references('id')->on('products');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product_requisition_items');
    }
}
