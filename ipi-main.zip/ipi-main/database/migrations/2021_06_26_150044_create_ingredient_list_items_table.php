<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateIngredientListItemsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ingredient_list_items', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('ingredient_list_id');
            $table->unsignedBigInteger('product_id');
            $table->integer('total_cost');
            $table->float('percentage');
            $table->string('remark')->nullable();

            $table->timestamps();
            $table->softDeletes();
            $table->foreign('ingredient_list_id')->references('id')->on('ingredient_lists');
            $table->foreign('product_id')->references('id')->on('products');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ingredient_list_items');
    }
}
