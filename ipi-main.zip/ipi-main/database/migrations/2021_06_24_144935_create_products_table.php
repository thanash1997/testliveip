<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->unsignedBigInteger('requester_customer_id')->nullable();
            $table->string('product_code', 50);
            $table->string('description')->nullable();
            $table->string('name')->nullable();
            $table->string('type_code')->nullable();
            $table->string('packaging_size')->nullable();
            $table->integer('unit_cost')->nullable();
            $table->integer('threshold')->nullable();
            $table->enum('type', ['material', 'formula', 'formula_sample']);

            $table->timestamps();
            $table->softDeletes();
            $table->foreign('requester_customer_id')->references('id')->on('companies');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
