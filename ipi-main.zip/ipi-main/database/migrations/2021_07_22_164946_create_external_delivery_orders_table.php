<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateExternalDeliveryOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('external_delivery_orders', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->unsignedBigInteger('customer_id');
            $table->unsignedBigInteger('address_id');
            $table->string('batch_no', 30)->nullable();
            $table->string('delivery_order_no', 30)->unique();
            $table->string('courier_name')->nullable();
            $table->string('vehicle_no')->nullable();
            $table->string('tracking_no')->nullable();
            $table->string('receipt_no')->nullable();
            $table->string('description')->nullable();
            $table->string('flag_reason')->nullable();

            $table->timestamps();
            $table->timestamp('estimated_delivery_date');
            $table->timestamp('fulfilled_at')->nullable();
            $table->timestamp('cancelled_at')->nullable();
            $table->timestamp('flagged_at')->nullable();
            $table->softDeletes();
            $table->foreign('customer_id')->references('id')->on('companies');
            $table->foreign('address_id')->references('id')->on('addresses');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('external_delivery_orders');
    }
}
