<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateInternalDeliveryOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('internal_delivery_orders', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->unsignedBigInteger('pic_id');
            $table->unsignedBigInteger('destination_id');
            $table->unsignedBigInteger('inventory_id');
            $table->string('batch_no', 30)->nullable();
            $table->string('delivery_order_no', 30)->unique();
            $table->string('usage', 100);
            $table->string('origin');
            $table->string('description')->nullable();
            $table->string('flag_reason')->nullable();

            $table->timestamps();
            $table->timestamp('estimated_delivery_date');
            $table->timestamp('fulfilled_at')->nullable();
            $table->timestamp('delivered_at')->nullable();
            $table->timestamp('flagged_at')->nullable();
            $table->softDeletes();
            $table->foreign('pic_id')->references('id')->on('users');
            $table->foreign('destination_id')->references('id')->on('inventories');
            $table->foreign('inventory_id')->references('id')->on('inventories');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('internal_delivery_orders');
    }
}
