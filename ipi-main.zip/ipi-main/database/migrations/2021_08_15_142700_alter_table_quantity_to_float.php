<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterTableQuantityToFloat extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('product_requisition_items', function (Blueprint $table) {
            $table->unsignedFloat('quantity', 8, 1)->change();
        });

        Schema::table('external_delivery_items', function (Blueprint $table) {
            $table->unsignedFloat('quantity', 8, 1)->change();
        });

        Schema::table('internal_delivery_items', function (Blueprint $table) {
            $table->unsignedFloat('quantity', 8, 1)->change();
        });

        Schema::table('inventory_products', function (Blueprint $table) {
            $table->unsignedFloat('quantity', 8, 1)->change();
        });

        Schema::table('order_items', function (Blueprint $table) {
            $table->unsignedFloat('quantity', 8, 1)->change();
        });

        Schema::table('product_requisition_items', function (Blueprint $table) {
            $table->unsignedFloat('quantity', 8, 1)->change();
        });

        Schema::table('purchase_order_items', function (Blueprint $table) {
            $table->unsignedFloat('quantity', 8, 1)->change();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
