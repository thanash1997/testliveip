<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductionMaterialsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('production_materials', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('material_list_id');
            $table->unsignedBigInteger('product_id');
            $table->unsignedBigInteger('ingredient_list_item_id');
            $table->integer('total_cost');
            $table->float('percentage');
            $table->string('remark')->nullable();

            $table->timestamps();
            $table->softDeletes();
            $table->foreign('material_list_id')->references('id')->on('material_lists');
            $table->foreign('product_id')->references('id')->on('products');
            $table->foreign('ingredient_list_item_id')->references('id')->on('ingredient_list_items');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('production_materials');
    }
}
