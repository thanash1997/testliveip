<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCheckpointsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('checkpoints', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('formula_id');
            $table->string('type');
            $table->float('range_min')->nullable();
            $table->float('range_max')->nullable();
            $table->float('tolerance_min')->nullable();
            $table->float('tolerance_max')->nullable();
            $table->string('equipment')->nullable();
            $table->string('remark')->nullable();

            $table->timestamps();
            $table->foreign('formula_id')->references('id')->on('formulas');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('checkpoints');
    }
}
