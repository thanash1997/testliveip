<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMaterialListsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('material_lists', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('order_item_id');
            $table->unsignedBigInteger('ingredient_list_id');
            $table->integer('total_cost')->default(0);
            $table->tinyInteger('position');
            $table->string('remark')->nullable();

            $table->timestamps();
            $table->softDeletes();
            $table->foreign('order_item_id')->references('id')->on('order_items');
            $table->foreign('ingredient_list_id')->references('id')->on('ingredient_lists');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('material_lists');
    }
}
