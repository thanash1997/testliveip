<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCompaniesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('companies', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->unsignedBigInteger('phone_number_id');
            $table->unsignedBigInteger('fax_number_id')->nullable();
            $table->string('name');
            $table->string('registration_number');
            $table->string('website_url')->nullable();
            $table->string('sst_number')->nullable();
            $table->string('gst_number')->nullable();
            $table->string('type', 30)->index();

            $table->timestamps();
            $table->foreign('phone_number_id')->references('id')->on('phone_numbers');
            $table->foreign('fax_number_id')->references('id')->on('phone_numbers');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('companies');
    }
}
