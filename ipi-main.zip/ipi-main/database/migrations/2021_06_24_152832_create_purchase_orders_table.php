<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePurchaseOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('purchase_orders', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->unsignedBigInteger('supplier_id');
            $table->unsignedBigInteger('destination_id');
            $table->string('usage', 100);
            $table->string('po_number', 50);
            $table->integer('total_cost');
            $table->string('flag_reason')->nullable();

            $table->timestamps();
            $table->softDeletes();
            $table->timestamp('expected_receive_date');
            $table->timestamp('cancelled_at')->nullable();
            $table->timestamp('fulfilled_at')->nullable();
            $table->timestamp('flagged_at')->nullable();
            $table->foreign('supplier_id')->references('id')->on('companies');
            $table->foreign('destination_id')->references('id')->on('inventories');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('purchase_orders');
    }
}
