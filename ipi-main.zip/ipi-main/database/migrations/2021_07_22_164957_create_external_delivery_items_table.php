<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateExternalDeliveryItemsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('external_delivery_items', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('external_delivery_order_id');
            $table->unsignedBigInteger('product_id');
            $table->integer('quantity');
            $table->string('packaging_size');
            $table->string('description')->nullable();

            $table->timestamps();
            $table->softDeletes();
            $table->foreign('external_delivery_order_id')->references('id')->on('external_delivery_orders');
            $table->foreign('product_id')->references('id')->on('products');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('external_delivery_items');
    }
}
