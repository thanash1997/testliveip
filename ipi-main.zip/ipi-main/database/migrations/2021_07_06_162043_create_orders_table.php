<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->unsignedBigInteger('customer_id');
            $table->unsignedBigInteger('pic_id');
            $table->unsignedBigInteger('shipment_id');
            $table->unsignedBigInteger('contact_person_id');
            $table->string('batch_no');
            $table->string('description')->nullable();
            $table->string('total_cost');

            $table->timestamp('estimated_delivered_at')->nullable();
            $table->timestamp('production_started_at')->nullable();
            $table->timestamp('pending_for_material_at')->nullable();
            $table->timestamp('scheduled_for_planning_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamp('cancelled_at')->nullable();
            $table->timestamp('halted_at')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->foreign('customer_id')->references('id')->on('companies');
            $table->foreign('pic_id')->references('id')->on('users');
            $table->foreign('shipment_id')->references('id')->on('shipments');
            $table->foreign('contact_person_id')->references('id')->on('users');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
}
