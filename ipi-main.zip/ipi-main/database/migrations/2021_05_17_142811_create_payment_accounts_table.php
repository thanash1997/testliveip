<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePaymentAccountsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payment_accounts', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id');
            $table->unsignedBigInteger('address_id');
            $table->unsignedBigInteger('phone_number_id');
            $table->unsignedBigInteger('fax_number_id')->nullable();
            $table->string('account_name');
            $table->string('email');
            $table->string('account_holder_name');
            $table->string('account_number');

            $table->timestamps();
            $table->foreign('phone_number_id')->references('id')->on('phone_numbers');
            $table->foreign('fax_number_id')->references('id')->on('phone_numbers');
            $table->foreign('company_id')->references('id')->on('companies');
            $table->foreign('address_id')->references('id')->on('addresses');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payment_accounts');
    }
}
