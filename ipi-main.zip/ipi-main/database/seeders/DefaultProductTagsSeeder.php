<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use IPI\Core\Entities\ProductTag;
use App\Models\ProductTag as ProductTagEloquent;

class DefaultProductTagsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $tags = ProductTag::ALL_TAGS;

        foreach ($tags as $tag) {
            ProductTagEloquent::query()->firstOrCreate(
                ['slug' => $tag],
                ['name' => ucwords(str_replace('-', ' ', $tag))],
            );
        }
    }
}
