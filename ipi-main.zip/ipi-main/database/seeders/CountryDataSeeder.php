<?php

namespace Database\Seeders;

use App\Models\Country;
use App\Models\DialingCode;
use Illuminate\Database\Seeder;

class CountryDataSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run(): void
    {
        if (Country::query()->count() > 0) {
            return;
        }

        $file = fopen(database_path('/seeders/data/country_data.csv'), 'r');
        $currentRow = 1;
        $countriesData = [];
        $countriesDialingCodesData = [];

        while ($row = fgetcsv($file)) {
            if ($currentRow < 4) {
                $currentRow++;
                continue;
            }

            array_push($countriesData, [
                'name' => $row[0],
                'iso_3166_alpha_2_code' => $row[2],
                'iso_4217_currency_code' => $row[14],
                'geo_name_id' => $row[24],
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            $countriesDialingCodesData[$row[2]] = explode(',', $row[9]);

            $currentRow++;
        }

        fclose($file);

        Country::query()->insert($countriesData);

        $countries = Country::query()->select(['id', 'iso_3166_alpha_2_code'])->get();
        $dialingCodesData = [];

        foreach ($countriesDialingCodesData as $isoAlpha2Code => $countryDialingCodes) {
            $countryID = $countries->where('iso_3166_alpha_2_code', $isoAlpha2Code)->first()->id;
            foreach ($countryDialingCodes as $countryDialingCode) {
                array_push($dialingCodesData, [
                    'country_id' => $countryID,
                    'code' => $countryDialingCode,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
        }

        DialingCode::query()->insert($dialingCodesData);
    }
}
