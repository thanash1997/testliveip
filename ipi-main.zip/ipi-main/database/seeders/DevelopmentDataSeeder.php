<?php

namespace Database\Seeders;

use App\Models\Address;
use App\Models\Bank;
use App\Models\Company;
use App\Models\Country;
use App\Models\Employee;
use App\Models\PaymentAccount;
use App\Models\PaymentMethod;
use App\Models\PhoneNumber;
use App\Models\Shipment;
use App\Models\User;
use Illuminate\Database\Seeder;
use IPI\Core\Company\CompanyCreator;
use IPI\Core\Company\EmployeeCreator;
use IPI\Core\Company\PaymentAccountCreator;
use IPI\Core\Company\ShipmentCreator;

class DevelopmentDataSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        if (!app()->environment('local')) {
            return;
        }

        auth()->login(User::find(1));
        $country = Country::query()->where('iso_3166_alpha_2_code', 'MY')->first();
        $dialingCode = $country->dialingCodes()->first();
        $companyCreator = new CompanyCreator();

        $customers = Company::factory()->count(35)->make(['type' => Company::CUSTOMER_TYPE]);
        $paymentMethod = PaymentMethod::first();
        $bank = Bank::first();

        foreach ($customers as $customer) {
            $phoneNumber = PhoneNumber::factory([
                'dialing_code_id' => $dialingCode->id,
            ])->create();
            $address = Address::factory([
                'country_id' => $country->id,
            ])->create();

            $company = $companyCreator->storeCompany(
                $customer->toArray(),
                $phoneNumber->id,
                $address->id,
                Company::CUSTOMER_TYPE
            );

            // Create employee
            $employeeCreator = new EmployeeCreator($company);
            $user = User::factory()->make();
            $employee = Employee::factory()->make();
            $employeePhoneNumber = PhoneNumber::factory([
                'dialing_code_id' => $dialingCode->id,
            ])->create();

            $employeeCreator->storeEmployee([
                'name' => $user->name,
                'email' => $user->email,
                'designation' => $employee->designation,
            ], $employeePhoneNumber->id);

            // Create payment account
            $paymentAccountCreator = new PaymentAccountCreator($company);
            $paymentAccountAddress = Address::factory()->create([
                'country_id' => $country->id,
            ]);
            $paymentAccountPhoneNumber = PhoneNumber::factory([
                'dialing_code_id' => $dialingCode->id,
            ])->create();
            $paymentAccount = PaymentAccount::factory()->make();

            $paymentAccountCreator->storePaymentAccount(
                [
                    'account_name' => $paymentAccount->account_name,
                    'email' => $paymentAccount->email,
                    'account_holder_name' => $paymentAccount->account_holder_name,
                    'account_number' => $paymentAccount->account_number,
                ],
                $paymentMethod->id,
                $paymentAccountPhoneNumber->id,
                $bank->id,
                $paymentAccountAddress->id,
            );

            // Create shipment details
            $shipmentCreator = new ShipmentCreator($company);
            $shipment = Shipment::factory()->make();
            $shipmentAddress = Address::factory()->create([
                'country_id' => $country->id,
            ]);
            $shipmentPhoneNumber = PhoneNumber::factory([
                'dialing_code_id' => $dialingCode->id,
            ])->create();

            $shipmentCreator->storeShipment(
                [
                    'name' => $shipment->name,
                    'email' => $shipment->email,
                    'receiver_name' => $shipment->receiver_name,
                ],
                $shipmentPhoneNumber->id,
                $shipmentAddress->id,
            );
        }

        $suppliers = Company::factory()->count(35)->make(['type' => Company::SUPPLIER_TYPE]);

        foreach ($suppliers as $supplier) {
            $phoneNumber = PhoneNumber::factory([
                'dialing_code_id' => $dialingCode->id,
            ])->create();
            $address = Address::factory([
                'country_id' => $country->id,
            ])->create();

            $company = $companyCreator->storeCompany(
                $supplier->toArray(),
                $phoneNumber->id,
                $address->id,
                Company::SUPPLIER_TYPE
            );

            // Create employee
            $employeeCreator = new EmployeeCreator($company);
            $user = User::factory()->make();
            $employee = Employee::factory()->make();
            $employeePhoneNumber = PhoneNumber::factory([
                'dialing_code_id' => $dialingCode->id,
            ])->create();

            $employeeCreator->storeEmployee([
                'name' => $user->name,
                'email' => $user->email,
                'designation' => $employee->designation,
            ], $employeePhoneNumber->id);

            // Create payment account
            $paymentAccountCreator = new PaymentAccountCreator($company);
            $paymentAccountAddress = Address::factory()->create([
                'country_id' => $country->id,
            ]);
            $paymentAccountPhoneNumber = PhoneNumber::factory([
                'dialing_code_id' => $dialingCode->id,
            ])->create();
            $paymentAccount = PaymentAccount::factory()->make();

            $paymentAccountCreator->storePaymentAccount(
                [
                    'account_name' => $paymentAccount->account_name,
                    'email' => $paymentAccount->email,
                    'account_holder_name' => $paymentAccount->account_holder_name,
                    'account_number' => $paymentAccount->account_number,
                ],
                $paymentMethod->id,
                $paymentAccountPhoneNumber->id,
                $bank->id,
                $paymentAccountAddress->id,
            );

            // Create shipment details
            $shipmentCreator = new ShipmentCreator($company);
            $shipment = Shipment::factory()->make();
            $shipmentAddress = Address::factory()->create([
                'country_id' => $country->id,
            ]);
            $shipmentPhoneNumber = PhoneNumber::factory([
                'dialing_code_id' => $dialingCode->id,
            ])->create();

            $shipmentCreator->storeShipment(
                [
                    'name' => $shipment->name,
                    'email' => $shipment->email,
                    'receiver_name' => $shipment->receiver_name,
                ],
                $shipmentPhoneNumber->id,
                $shipmentAddress->id,
            );
        }
    }
}
