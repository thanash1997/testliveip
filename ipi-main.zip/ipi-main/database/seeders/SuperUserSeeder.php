<?php

namespace Database\Seeders;

use App\Models\Department;
use App\Models\DialingCode;
use App\Models\General\EloquentBaseUser;
use App\Models\PhoneNumber;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use IPI\Core\User\IUserRoleAssigner;
use IPI\Core\User\UserDepartmentAssigner;

class SuperUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run(IUserRoleAssigner $roleAssigner)
    {
        $dialingCode = DialingCode::where('code', '60')->first();
        $phoneNumber = PhoneNumber::firstOrCreate(
            ['phone_number' => '123456789'],
            ['dialing_code_id' => $dialingCode->id]
        );

        $user = User::firstOrCreate(
            ['email' => 'waps-admin@ipi.com'],
            [
                'password' => Hash::make('ipialwaysstrong1312'),
                'name' => 'Super Admin',
                'username' => 'wapssuperadmin',
                'can_login' => true,
                'email_verified_at' => now(),
                'phone_number_id' => $phoneNumber->id,
            ]
        );

        if ($user->wasRecentlyCreated === true) {
            $departmentAssigner = new UserDepartmentAssigner($user);
            $department = Department::where('name', 'Admin')->first();
            $departmentAssigner->assignDepartment($department->id);

            $roleAssigner->setUser($user);
            $roleAssigner->assignRole(EloquentBaseUser::SUPER_ADMIN_ROLE);
        }
    }
}
