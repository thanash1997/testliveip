<?php

namespace Database\Seeders;

use App\Models\Department;
use Illuminate\Database\Seeder;

class DefaultDepartmentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $departments = [
            [
                'name' => 'Admin',
                'description' => 'Top managements.'
            ],
            [
                'name' => 'Production',
                'description' => 'Production managements.'
            ],
            [
                'name' => 'Warehouse',
                'description' => 'Warehouse managements.'
            ],
            [
                'name' => 'Sales',
                'description' => 'Sales managements.'
            ],
            [
                'name' => 'Lab',
                'description' => 'Lab managements.'
            ],
        ];

        foreach ($departments as $department) {
            Department::query()->firstOrCreate(
                ['name' => $department['name']],
                ['description' => $department['description']],
            );
        }
    }
}
