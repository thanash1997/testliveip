<?php

namespace Database\Seeders;

use App\Models\Inventory;
use Illuminate\Database\Seeder;

class DefaultInventoriesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $production = Inventory::PRODUCTION;
        $warehouse = Inventory::WAREHOUSE;

        Inventory::query()->firstOrCreate(
            [
                'slug' => $production,
            ],
            [
                'name' => Inventory::NAMES[$production],
                'display_name' => Inventory::DISPLAY_NAMES[$production],
            ]
        );

        Inventory::query()->firstOrCreate(
            [
                'slug' => $warehouse,
            ],
            [
                'name' => Inventory::NAMES[$warehouse],
                'display_name' => Inventory::DISPLAY_NAMES[$warehouse],
            ]
        );
    }
}
