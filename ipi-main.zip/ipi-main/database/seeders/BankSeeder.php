<?php

namespace Database\Seeders;

use App\Models\Bank;
use App\Models\Country;
use Illuminate\Database\Seeder;

class BankSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $malaysianBanks = [
            'AmBank',
            'Bank of America',
            'Bank Islam',
            'Bank Muamalat',
            'Bank Rakyat',
            'Bank Simpanan Nasional (BSN)',
            'Agro Bank',
            'Alliance Bank',
            'Al-Rajhi Bank',
            'Bank of America',
            'BNP Paribas',
            'Kuwait Finance House',
            'Affin Bank',
            'Alliance Bank',
            'BNP Paribas',
            'Bangkok Bank',
            'CIMB Bank',
            'China Construction',
            'Citibank',
            'Deutsche Bank',
            'HSBC Bank',
            'ICBC Bank',
            'JPMorgan Chase',
            'Maybank',
            'Mizuho Bank',
            'OCBC Bank',
            'Standard Chartered Bank',
            'Bank of China',
            'Hong Leong Bank',
            'India International Bank',
            'MUFG Bank',
            'Public Bank',
            'RHB Bank',
            'SMBC Bank',
            'Scotiabank',
            'United Overseas Bank (UOB)',
        ];
        $malaysiaCountry = Country::where('iso_3166_alpha_2_code', 'MY')->first();
        ksort($malaysianBanks);

        foreach ($malaysianBanks as $malaysianBankName) {
            $malaysiaCountry->banks()->firstOrCreate(
                ['name' => $malaysianBankName],
                [
                    'branch' => 'TBD',
                    'swift_code' => 'TBD',
                ]
            );
        }
    }
}
