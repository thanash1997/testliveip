<?php

namespace Database\Seeders;

use App\Models\Module;
use Illuminate\Database\Seeder;

class ModulesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $modules = Module::ALL_MODULES;

        foreach ($modules as $module) {
            Module::firstOrCreate(
                ['slug' => $module],
                ['name' => ucwords($module)]
            );
        }
    }
}
