<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            RolePermissionSeeder::class,
            CountryDataSeeder::class,
            DefaultDepartmentSeeder::class,
            BankSeeder::class,
            PaymentMethodSeeder::class,
            DefaultProductTagsSeeder::class,
            DefaultInventoriesSeeder::class,
            DefaultFormulaTagSeeder::class,
            ModulesSeeder::class,
            DepartmentModuleSeeder::class,
            CourierSeeder::class,
            SuperUserSeeder::class,
            DevelopmentDataSeeder::class,
        ]);
    }
}
