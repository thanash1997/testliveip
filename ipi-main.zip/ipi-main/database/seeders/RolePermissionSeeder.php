<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RolePermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $rolesAndPermissions = [
            User::SUPER_ADMIN_ROLE => [
                User::NAV_DASHBOARD_PERMISSION,
                User::NAV_PRODUCTION_PERMISSION,
                User::NAV_WAREHOUSE_PERMISSION,
                User::NAV_FORMULA_PERMISSION,
                User::NAV_CUSTOMER_PERMISSION,
                User::NAV_REPORT_PERMISSION,
                User::NAV_SUPPLIER_PERMISSION,

                User::VIEW_CUSTOMER_INDEX_PERMISSION,
                User::VIEW_CUSTOMER_CREATE_PERMISSION,
                User::VIEW_CUSTOMER_DETAILS_PERMISSION,
                User::CREATE_CUSTOMER_PERMISSION,
                User::UPDATE_CUSTOMER_PERMISSION,
                User::VIEW_SUPPLIER_INDEX_PERMISSION,
                User::VIEW_SUPPLIER_DETAILS_PERMISSION,
                User::VIEW_SUPPLIER_CREATE_PERMISSION,
                User::CREATE_SUPPLIER_PERMISSION,
                User::UPDATE_SUPPLIER_PERMISSION,
                User::VIEW_USER_INDEX_PERMISSION,
                User::VIEW_USER_CREATE_PERMISSION,
                User::VIEW_USER_UPDATE_PERMISSION,
                User::VIEW_USER_DETAILS_PERMISSION,
                User::CREATE_USER_PERMISSION,
                User::UPDATE_USER_PERMISSION,
                User::DELETE_USER_PERMISSION,
                User::UPDATE_PASSWORD_PERMISSION,
                User::VIEW_FORMULA_INDEX_PERMISSION,
                User::VIEW_FORMULA_CREATE_PERMISSION,
                User::VIEW_FORMULA_DETAILS_PERMISSION,
                User::CREATE_FORMULA_PERMISSION,
                User::UPDATE_FORMULA_PERMISSION,
                User::DELETE_FORMULA_PERMISSION,
                User::VIEW_FORMULA_SAMPLING_INDEX_PERMISSION,
                User::VIEW_FORMULA_SAMPLING_CREATE_PERMISSION,
                User::VIEW_FORMULA_SAMPLING_DETAILS_PERMISSION,
                User::CREATE_FORMULA_SAMPLING_PERMISSION,
                User::UPDATE_FORMULA_SAMPLING_PERMISSION,
                User::DELETE_FORMULA_SAMPLING_PERMISSION,
                
                User::APPROVAL_PERMISSION,
            ],
            User::ADMIN_ROLE => [
                User::NAV_DASHBOARD_PERMISSION,
                User::NAV_PRODUCTION_PERMISSION,
                User::NAV_WAREHOUSE_PERMISSION,
                User::NAV_FORMULA_PERMISSION,
                User::NAV_CUSTOMER_PERMISSION,
                User::NAV_REPORT_PERMISSION,
                User::NAV_SUPPLIER_PERMISSION,

                User::VIEW_CUSTOMER_INDEX_PERMISSION,
                User::VIEW_CUSTOMER_CREATE_PERMISSION,
                User::VIEW_CUSTOMER_DETAILS_PERMISSION,
                User::CREATE_CUSTOMER_PERMISSION,
                User::UPDATE_CUSTOMER_PERMISSION,
                User::VIEW_SUPPLIER_INDEX_PERMISSION,
                User::VIEW_SUPPLIER_DETAILS_PERMISSION,
                User::VIEW_SUPPLIER_CREATE_PERMISSION,
                User::CREATE_SUPPLIER_PERMISSION,
                User::UPDATE_SUPPLIER_PERMISSION,
                User::VIEW_USER_INDEX_PERMISSION,
                User::VIEW_USER_CREATE_PERMISSION,
                User::VIEW_USER_UPDATE_PERMISSION,
                User::CREATE_USER_PERMISSION,
                User::UPDATE_USER_PERMISSION,
                User::UPDATE_PASSWORD_PERMISSION,
                User::VIEW_FORMULA_INDEX_PERMISSION,
                User::VIEW_FORMULA_CREATE_PERMISSION,
                User::VIEW_FORMULA_DETAILS_PERMISSION,
                User::CREATE_FORMULA_PERMISSION,
                User::UPDATE_FORMULA_PERMISSION,
                User::DELETE_FORMULA_PERMISSION,
                User::VIEW_FORMULA_SAMPLING_INDEX_PERMISSION,
                User::VIEW_FORMULA_SAMPLING_CREATE_PERMISSION,
                User::VIEW_FORMULA_SAMPLING_DETAILS_PERMISSION,
                User::CREATE_FORMULA_SAMPLING_PERMISSION,
                User::UPDATE_FORMULA_SAMPLING_PERMISSION,
                User::DELETE_FORMULA_SAMPLING_PERMISSION,

                User::APPROVAL_PERMISSION,
            ],
            User::HOD_ROLE => [
                User::NAV_DASHBOARD_PERMISSION,
                User::NAV_PRODUCTION_PERMISSION,
                User::NAV_WAREHOUSE_PERMISSION,
                User::NAV_FORMULA_PERMISSION,
                User::NAV_CUSTOMER_PERMISSION,
                User::NAV_REPORT_PERMISSION,
                User::NAV_SUPPLIER_PERMISSION,

                User::VIEW_CUSTOMER_INDEX_PERMISSION,
                User::VIEW_CUSTOMER_CREATE_PERMISSION,
                User::VIEW_CUSTOMER_DETAILS_PERMISSION,
                User::CREATE_CUSTOMER_PERMISSION,
                User::UPDATE_CUSTOMER_PERMISSION,
                User::VIEW_SUPPLIER_INDEX_PERMISSION,
                User::VIEW_SUPPLIER_DETAILS_PERMISSION,
                User::VIEW_SUPPLIER_CREATE_PERMISSION,
                User::CREATE_SUPPLIER_PERMISSION,
                User::UPDATE_SUPPLIER_PERMISSION,
                User::UPDATE_PASSWORD_PERMISSION,
                User::VIEW_FORMULA_INDEX_PERMISSION,
                User::VIEW_FORMULA_CREATE_PERMISSION,
                User::VIEW_FORMULA_DETAILS_PERMISSION,
                User::CREATE_FORMULA_PERMISSION,
                User::UPDATE_FORMULA_PERMISSION,
                User::VIEW_FORMULA_SAMPLING_INDEX_PERMISSION,
                User::VIEW_FORMULA_SAMPLING_CREATE_PERMISSION,
                User::VIEW_FORMULA_SAMPLING_DETAILS_PERMISSION,
                User::CREATE_FORMULA_SAMPLING_PERMISSION,
                User::UPDATE_FORMULA_SAMPLING_PERMISSION,
            ],
            User::STAFF_ROLE => [
                User::NAV_DASHBOARD_PERMISSION,
                User::NAV_PRODUCTION_PERMISSION,
                User::NAV_WAREHOUSE_PERMISSION,
                User::NAV_FORMULA_PERMISSION,
                User::NAV_CUSTOMER_PERMISSION,
                User::NAV_SUPPLIER_PERMISSION,

                User::VIEW_CUSTOMER_INDEX_PERMISSION,
                User::VIEW_CUSTOMER_CREATE_PERMISSION,
                User::VIEW_CUSTOMER_DETAILS_PERMISSION,
                User::CREATE_CUSTOMER_PERMISSION,
                User::VIEW_SUPPLIER_INDEX_PERMISSION,
                User::VIEW_SUPPLIER_DETAILS_PERMISSION,
                User::VIEW_SUPPLIER_CREATE_PERMISSION,
                User::CREATE_SUPPLIER_PERMISSION,
                User::UPDATE_PASSWORD_PERMISSION,
                User::VIEW_FORMULA_INDEX_PERMISSION,
                User::VIEW_FORMULA_CREATE_PERMISSION,
                User::VIEW_FORMULA_DETAILS_PERMISSION,
                User::CREATE_FORMULA_PERMISSION,
                User::VIEW_FORMULA_SAMPLING_INDEX_PERMISSION,
                User::VIEW_FORMULA_SAMPLING_CREATE_PERMISSION,
                User::VIEW_FORMULA_SAMPLING_DETAILS_PERMISSION,
                User::CREATE_FORMULA_SAMPLING_PERMISSION,
            ]
        ];

        foreach ($rolesAndPermissions as $role => $permissions) {
            foreach ($permissions as $permission) {
                Permission::query()->updateOrCreate(['name' => $permission]);
            }

            Role::firstOrCreate(['name' => $role])->givePermissionTo($permissions);
        }
    }
}
