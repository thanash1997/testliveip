<?php

namespace Database\Seeders;

use App\Models\FormulaTag;
use Illuminate\Database\Seeder;

class DefaultFormulaTagSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $tags = FormulaTag::ALL_TAGS;

        foreach ($tags as $tag) {
            FormulaTag::query()->firstOrCreate(
                ['slug' => $tag],
                ['name' => ucwords(str_replace('-', ' ', $tag))],
            );
        }
    }
}
