<?php

namespace Database\Seeders;

use App\Models\Department;
use App\Models\Module;
use Illuminate\Database\Seeder;

class DepartmentModuleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $maps = [
            'Admin' => [
                'production',
                'warehouse',
                'formula',
            ],
            'Production' => [
                'production'
            ],
            'Warehouse' => [
                'warehouse'
            ],
            'Sales' => [
                'formula',
            ],
            'Lab' => [
                'formula',
            ],
        ];

        foreach ($maps as $departmentName => $moduleSlugs) {
            $modules = Module::query()->whereIn('slug', $moduleSlugs)->get();
            $department = Department::query()->where('name', $departmentName)->first();
            $department->modules()->sync($modules);
        }
    }
}
