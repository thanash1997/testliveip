<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Default Role Permission Library
    |--------------------------------------------------------------------------
    |
    | Here you may specify which role permissions library you are using
    | for the application. Default to spatie/laravel-permission.
    |
    */

    'role-permission-lib' => env('ROLE_PERMISSION_LIB', 'spatie/laravel-permission'),
];
