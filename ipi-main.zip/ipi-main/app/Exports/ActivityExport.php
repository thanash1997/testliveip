<?php

namespace App\Exports;

use App\Models\Module;
use App\Models\Remark;
use Carbon\Carbon;
use Illuminate\Contracts\Support\Responsable;
use Illuminate\Database\Eloquent\Collection as EloquentCollection;
use Illuminate\Support\Collection as SupportCollection;
use IPI\Core\Entities\ActivityLog;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Excel;
use OwenIt\Auditing\Models\Audit as AuditEloquent;

class ActivityExport implements FromArray, Responsable, ShouldAutoSize
{
    use Exportable;

    private $moduleId;
    private $startDate;
    private $endDate;
    private $roleId;
    private $userId;
    private $actionType;

    public function __construct($moduleId, $startDate, $endDate, $roleId, $userId, $actionType)
    {
        $this->startDate = $startDate ? Carbon::parse($startDate)->startOfDay() : null;
        $this->endDate = $endDate ? Carbon::parse($endDate)->endOfDay() : null;
        $this->moduleId = $moduleId;
        $this->roleId = $roleId;
        $this->userId = $userId;
        $this->actionType = $actionType;
    }

    /**
     * It's required to define the fileName within
     * the export class when making use of Responsable.
     */
    private $fileName = 'activities.xlsx';

    /**
     * Optional Writer Type
     */
    private $writerType = Excel::XLSX;

    /**
     * Optional headers
     */
    private $headers = [
        'Content-Type' => 'text/csv',
    ];

    public function array(): array
    {
        $audits = $this->fetchActivities();
        $headers = ['Date', 'Module', 'User Role', 'User Name', 'Action Done'];
        $data = [$headers];

        foreach ($audits as $audit) {
            $data[] = [
                Carbon::parse($audit->createdAt)->setTimezone('Asia/Kuala_Lumpur'),
                $audit->subModule,
                $audit->userRole,
                $audit->userName,
                $audit->event,
            ];
        }

        return [$data];
    }

    private function fetchActivities(): array
    {
        $eloquentQueryBuilder = AuditEloquent::query()->with(['user.roles', 'user.department']);
        $eloquentQueryBuilder->where('url', '!=', 'console');
        $eloquentQueryBuilder->where('auditable_type', '!=', Remark::class);

        if ($this->startDate !== null && $this->endDate !== null) {
            $eloquentQueryBuilder->whereBetween('audits.created_at', [
                $this->startDate,
                $this->endDate
            ]);
        }

        if ($this->userId !== null) {
            $eloquentQueryBuilder->where('user_id', $this->userId);
        }

        if ($this->roleId !== null) {
            $eloquentQueryBuilder->leftJoin('model_has_roles', 'model_has_roles.model_id', '=', 'audits.user_id')
                ->where('model_has_roles.model_id', $this->roleId);
        }

        if ($this->moduleId !== null) {
            $module = Module::query()->where('id', $this->moduleId)->select([
                'slug'
            ])->first();
            $map = [
                'production' => [
                    'App\Models\Order',
                    'App\Models\ProductRequisition',
                    'App\Models\InternalDeliveryOrder',
                    'App\Models\Product'
                ],
                'warehouse' => [
                    'App\Models\InternalDeliveryOrder',
                    'App\Models\InternalDeliveryOrder',
                    'App\Models\Product'
                ],
                'formula' => [
                    'App\Models\Formula'
                ],
            ];

            $eloquentQueryBuilder->where('auditable_type', $map[$module->slug]);
        }

        if ($this->actionType !== null) {
            $map = [
                'edit' => 'updated',
                'create' => 'created',
                'delete' => 'deleted',
            ];

            $eloquentQueryBuilder->where('event', $map[$this->actionType]);
        }

        $audits = $eloquentQueryBuilder->get();

        return $this->prepareActivityLogs($audits);
    }

    private function prepareActivityLogs(EloquentCollection|SupportCollection $collection): array
    {
        $activityLogs = [];

        foreach ($collection as $item) {
            $activityLog = new ActivityLog();
            $activityLog->setFromArray($item->toArray());

            $subModule = ActivityLog::SUB_MODULES[$item->auditable_type];
            $value = match ($subModule) {
                'User', 'Company' => $item->auditable->name,
                'Inventory' => $item->auditable->product_code,
                'Procurement' => $item->auditable->po_number,
                'Formula' => $item->auditable->product->product_code,
                'Order' => $item->auditable->orderItems->first()->product->product_code,
                'Internal Material Requisition' => $item->auditable->material_requisition_no,
                'Internal Delivery Order', 'External Delivery Order' => $item->auditable->delivery_order_no,
                default => '',
            };
            $activityLog->event .= " $value";

            $activityLogs[] = $activityLog;
        }

        return $activityLogs;
    }
}
