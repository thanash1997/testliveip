<?php

namespace App\Exports;

use App\Models\InternalDeliveryOrder;
use App\Models\Inventory;
use Carbon\Carbon;
use Illuminate\Contracts\Support\Responsable;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Excel;

class ProducedStockExport implements FromArray, Responsable, ShouldAutoSize
{
    use Exportable;

    private $startDate;
    private $endDate;
    private $customerId;
    private $formulaTypeId;

    public function __construct($startDate, $endDate, $customerId, $formulaTypeId)
    {
        $this->startDate = $startDate ? Carbon::parse($startDate)->startOfDay() : null;
        $this->endDate = $endDate ? Carbon::parse($endDate)->endOfDay() : null;
        $this->customerId = $customerId;
        $this->formulaTypeId = $formulaTypeId;
    }

    /**
     * It's required to define the fileName within
     * the export class when making use of Responsable.
     */
    private $fileName = 'produced_stocks.xlsx';

    /**
     * Optional Writer Type
     */
    private $writerType = Excel::XLSX;

    /**
     * Optional headers
     */
    private $headers = [
        'Content-Type' => 'text/csv',
    ];

    public function array(): array
    {
        $hasDateRange = isset($this->startDate) && isset($this->endDate);
        $warehouseInventory = Inventory::query()->where('slug', 'warehouse')->first();
        $orders = InternalDeliveryOrder::query()
            ->with(['orderItems.product'])
            ->whereHas('destination', function ($query) use ($warehouseInventory) {
                return $query->where('inventories.id', $warehouseInventory->id);
            })
            ->when($hasDateRange, function ($query) {
                return $query->whereBetween('internal_delivery_orders.created_at', [$this->startDate, $this->endDate]);
            })
            ->get();

        $header = ['Date', 'Batch No', 'Product Description', 'Customer Name', 'Product Code', 'Quantity', 'Packaging Size', 'Total Cost', 'Cost per unit'];
        $data = [$header];

        foreach ($orders as $order) {
            foreach ($order->orderItems as $orderItem) {
                $data[] = [
                    Carbon::parse($order->created_at)->setTimezone('Asia/Kuala_Lumpur'),
                    $order->batch_no,
                    $orderItem->product->description,
                    '',
                    $orderItem->product->product_code,
                    $orderItem->quantity / 1000,
                    $orderItem->product->packaging_size,
                    $orderItem->quantity / 1000 * $orderItem->product->unit_cost / 100,
                    $orderItem->product->unit_cost / 100,
                ];
            }
        }

        return [$data];
    }
}
