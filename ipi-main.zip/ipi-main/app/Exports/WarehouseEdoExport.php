<?php

namespace App\Exports;

use App\Models\ExternalDeliveryOrder;
use Carbon\Carbon;
use Illuminate\Contracts\Support\Responsable;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Excel;

class WarehouseEdoExport implements FromArray, Responsable, ShouldAutoSize
{
    use Exportable;

    private $startDate;
    private $endDate;
    private $deliveryStartDate;
    private $deliveryEndDate;
    private $customerId;

    public function __construct($startDate, $endDate, $deliveryStartDate, $deliveryEndDate, $customerId)
    {
        $this->startDate = $startDate ? Carbon::parse($startDate)->startOfDay() : null;
        $this->endDate = $endDate ? Carbon::parse($endDate)->endOfDay() : null;
        $this->deliveryStartDate = $deliveryStartDate ? Carbon::parse($deliveryStartDate)->startOfDay() : null;
        $this->deliveryEndDate = $deliveryEndDate ? Carbon::parse($deliveryEndDate)->endOfDay() : null;
        $this->customerId = $customerId;
    }

    /**
     * It's required to define the fileName within
     * the export class when making use of Responsable.
     */
    private $fileName = 'external_deliveries.xlsx';

    /**
     * Optional Writer Type
     */
    private $writerType = Excel::XLSX;

    /**
     * Optional headers
     */
    private $headers = [
        'Content-Type' => 'text/csv',
    ];

    public function array(): array
    {
        $hasDateRange = isset($this->startDate) && isset($this->endDate);
        $hasDeliveryDateRange = isset($this->deliveryStartDate) && isset($this->deliveryEndDate);
        $orders = ExternalDeliveryOrder::query()
            ->with(['orderItems.product', 'customer'])
            ->when($hasDateRange, function ($query) {
                return $query->whereBetween('external_delivery_orders.created_at', [$this->startDate, $this->endDate]);
            })
            ->when($hasDeliveryDateRange, function ($query) {
                return $query->whereBetween('external_delivery_orders.estimated_delivery_date', [$this->deliveryStartDate, $this->deliveryEndDate]);
            })
            ->when($this->customerId, function ($query, $customerId) {
                return $query->where('customer_id', $customerId);
            })
            ->get();

        $header = ['Date', 'Delivery Date', 'Delivery Order Number', 'Customer Name', 'Product Code', 'Packaging Size', 'Quantity', 'Status', 'Flagged', 'Transportation', 'Courier', 'Tracking Number'];
        $data = [$header];

        foreach ($orders as $order) {
            $orderEntity = new \IPI\Core\Entities\ExternalDeliveryOrder($order->id);
            $orderEntity->setFromArray($order->toArray());
            foreach ($order->orderItems as $orderItem) {
                $data[] = [
                    Carbon::parse($orderEntity->createdAt)->setTimezone('Asia/Kuala_Lumpur'),
                    Carbon::parse($orderEntity->estimatedDeliveryDate)->setTimezone('Asia/Kuala_Lumpur'),
                    $orderEntity->deliveryOrderNo,
                    $orderEntity->customerName,
                    $orderItem->product->product_code,
                    $orderItem->product->packaging_size,
                    $orderItem->quantity / 1000,
                    $orderEntity->status,
                    $order->flag_reason,
                    $order->vehicle_no,
                    $order->courier_name,
                    $order->tracking_no,
                ];
            }
        }

        return [$data];
    }
}
