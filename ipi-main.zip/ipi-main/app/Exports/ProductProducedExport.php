<?php

namespace App\Exports;

use App\Models\Order;
use Carbon\Carbon;
use Illuminate\Contracts\Support\Responsable;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Excel;

class ProductProducedExport implements FromArray, Responsable, ShouldAutoSize
{
    use Exportable;

    private $startDate;
    private $endDate;
    private $customerId;

    public function __construct($startDate, $endDate, $customerId)
    {
        $this->startDate = $startDate ? Carbon::parse($startDate)->startOfDay() : null;
        $this->endDate = $endDate ? Carbon::parse($endDate)->endOfDay() : null;
        $this->customerId = $customerId;
    }

    /**
     * It's required to define the fileName within
     * the export class when making use of Responsable.
     */
    private $fileName = 'product_produced.xlsx';

    /**
     * Optional Writer Type
     */
    private $writerType = Excel::XLSX;

    /**
     * Optional headers
     */
    private $headers = [
        'Content-Type' => 'text/csv',
    ];

    public function array(): array
    {
        $hasDateRange = isset($this->startDate) && isset($this->endDate);
        $orders = Order::query()
            ->with(['customer.address', 'orderItems.product'])
            ->when($hasDateRange, function ($query) {
                return $query->whereBetween('created_at', [$this->startDate, $this->endDate]);
            })
            ->when($this->customerId, function ($query, $customerId) {
                return $query->where('customer_id', $customerId);
            })
            ->get();

        $header = ['Date', 'Batch Ticket No', 'Customer Name', 'Customer ID', 'Address', 'Product Code', 'Quantity', 'Delivered By', 'Order Status', 'Date of Production', 'Date of Production Completed'];
        $data = [$header];

        foreach ($orders as $order) {
            $orderEntity = new \IPI\Core\Entities\Order($order->id);
            $orderEntity->setFromArray($order->toArray(0));
            $data[] = [
                Carbon::parse($order->created_at)->setTimezone('Asia/Kuala_Lumpur'),
                $order->batch_no,
                $order->customer->name,
                $order->customer->company_code,
                $order->customer->address->full_address,
                $order->orderItems[0]->product->product_code,
                $order->orderItems[0]->quantity / 1000,
                $order->estimated_delivered_at ? Carbon::parse($order->estimated_delivered_at)->setTimezone('Asia/Kuala_Lumpur') : '',
                $orderEntity->status,
                $order->production_started_at ? Carbon::parse($order->production_started_at)->setTimezone('Asia/Kuala_Lumpur') : '',
                $order->completed_at ? Carbon::parse($order->completed_at)->setTimezone('Asia/Kuala_Lumpur') : ''
            ];
        }

        return [$data];
    }
}
