<?php

namespace App\Exports;

use App\Models\InternalDeliveryOrder;
use App\Models\Inventory;
use Carbon\Carbon;
use Illuminate\Contracts\Support\Responsable;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Excel;

class WarehouseIdoExport implements FromArray, Responsable, ShouldAutoSize
{
    use Exportable;

    private $startDate;
    private $endDate;
    private $deliveryStartDate;
    private $deliveryEndDate;
    private $orderId;

    public function __construct($startDate, $endDate, $deliveryStartDate, $deliveryEndDate, $orderId)
    {
        $this->startDate = $startDate ? Carbon::parse($startDate)->startOfDay() : null;
        $this->endDate = $endDate ? Carbon::parse($endDate)->endOfDay() : null;
        $this->deliveryStartDate = $deliveryStartDate ? Carbon::parse($deliveryStartDate)->startOfDay() : null;
        $this->deliveryEndDate = $deliveryEndDate ? Carbon::parse($deliveryEndDate)->endOfDay() : null;
        $this->orderId = $orderId;
    }

    /**
     * It's required to define the fileName within
     * the export class when making use of Responsable.
     */
    private $fileName = 'internal_deliveries.xlsx';

    /**
     * Optional Writer Type
     */
    private $writerType = Excel::XLSX;

    /**
     * Optional headers
     */
    private $headers = [
        'Content-Type' => 'text/csv',
    ];

    public function array(): array
    {
        $hasDateRange = isset($this->startDate) && isset($this->endDate);
        $hasDeliveryDateRange = isset($this->deliveryStartDate) && isset($this->deliveryEndDate);
        $warehouseInventory = Inventory::query()->where('slug', 'warehouse')->first();
        $orders = InternalDeliveryOrder::query()
            ->with(['orderItems.product'])
            ->whereHas('destination', function ($query) use ($warehouseInventory) {
                return $query->where('inventories.id', $warehouseInventory->id);
            })
            ->when($hasDateRange, function ($query) {
                return $query->whereBetween('internal_delivery_orders.created_at', [$this->startDate, $this->endDate]);
            })
            ->when($hasDeliveryDateRange, function ($query) {
                return $query->whereBetween('internal_delivery_orders.estimated_delivery_date', [$this->deliveryStartDate, $this->deliveryEndDate]);
            })
            ->when($this->orderId, function ($query, $orderId) {
                return $query->leftJoin('orders', 'orders.batch_no', '=', 'internal_delivery_orders.batch_no')
                    ->where('orders.id', $orderId);
            })
            ->get();

        $header = ['Date', 'Delivery Date', 'Delivery Order Number', 'Batch No.', 'Product Code', 'Packaging Size', 'Quantity', 'Status', 'Flagged'];
        $data = [$header];

        foreach ($orders as $order) {
            $orderEntity = new \IPI\Core\Entities\InternalDeliveryOrder($order->id);
            $orderEntity->setFromArray($order->toArray());
            foreach ($order->orderItems as $orderItem) {
                $data[] = [
                    Carbon::parse($order->created_at)->setTimezone('Asia/Kuala_Lumpur'),
                    Carbon::parse($order->extimated_delivery_date)->setTimezone('Asia/Kuala_Lumpur'),
                    $order->delivery_order_no,
                    $order->batch_no,
                    $orderItem->product->product_code,
                    $orderItem->product->packaging_size,
                    $orderItem->quantity / 1000,
                    $orderEntity->status,
                    $order->flag_reason
                ];
            }
        }

        return [$data];
    }
}
