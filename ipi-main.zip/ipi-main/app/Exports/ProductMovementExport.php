<?php

namespace App\Exports;

use App\Models\InternalDeliveryOrder;
use App\Models\Inventory;
use Carbon\Carbon;
use Illuminate\Contracts\Support\Responsable;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;
use Maatwebsite\Excel\Excel;

class ProductMovementExport implements FromArray, Responsable, WithColumnFormatting, ShouldAutoSize
{
    use Exportable;

    private $startDate;
    private $endDate;
    private $orderId;

    public function __construct($startDate, $endDate, $orderId)
    {
        $this->startDate = $startDate ? Carbon::parse($startDate)->startOfDay() : null;
        $this->endDate = $endDate ? Carbon::parse($endDate)->endOfDay() : null;
        $this->orderId = $orderId;
    }

    public function columnFormats(): array
    {
        return [
            'C' => '0.0000',
            'E' => '0.00000',
        ];
    }

    /**
     * It's required to define the fileName within
     * the export class when making use of Responsable.
     */
    private $fileName = 'product_movement.xlsx';

    /**
     * Optional Writer Type
     */
    private $writerType = Excel::XLSX;

    /**
     * Optional headers
     */
    private $headers = [
        'Content-Type' => 'text/csv',
    ];

    public function array(): array
    {
        $hasDateRange = isset($this->startDate) && isset($this->endDate);
        $productionInventory = Inventory::query()->where('slug', 'production')->first();
        $orders = InternalDeliveryOrder::query()
            ->with(['orderItems.product'])
            ->whereHas('destination', function ($query) use ($productionInventory) {
                return $query->where('inventories.id', $productionInventory->id);
            })
            ->when($hasDateRange, function ($query) {
                return $query->whereBetween('internal_delivery_orders.created_at', [$this->startDate, $this->endDate]);
            })
            ->when($this->orderId, function ($query, $orderId) {
                return $query->leftJoin('orders', 'orders.batch_no', '=', 'internal_delivery_orders.batch_no')
                    ->where('orders.id', $orderId);
            })
            ->get();

        $header = ['Date', 'Product Code', 'Quantity', 'Packaging Size', 'Total Cost', 'Cost per unit'];
        $data = [$header];

        foreach ($orders as $order) {
            foreach ($order->orderItems as $orderItem) {
                $data[] = [
                    Carbon::parse($order->created_at)->setTimezone('Asia/Kuala_Lumpur'),
                    $orderItem->product->product_code,
                    $orderItem->quantity / 1000,
                    $orderItem->product->packaging_size,
                    $orderItem->quantity / 1000 * $orderItem->product->unit_cost / 100,
                    $orderItem->product->unit_cost / 100,
                ];
            }
        }

        return [$data];
    }
}
