<?php

namespace App\Exports;

use App\Models\Company;
use Carbon\Carbon;
use Illuminate\Contracts\Support\Responsable;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;
use Maatwebsite\Excel\Excel;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;

class CompanyExport implements FromArray, Responsable, WithColumnFormatting, ShouldAutoSize
{
    use Exportable;

    private $type;
    private $startDate;
    private $endDate;
    private $companyId;

    public function __construct($type, $startDate, $endDate, $companyId)
    {
        $this->startDate = $startDate ? Carbon::parse($startDate)->startOfDay() : null;
        $this->endDate = $endDate ? Carbon::parse($endDate)->endOfDay() : null;
        $this->type = $type;
        $this->companyId = $companyId;
    }

    /**
     * It's required to define the fileName within
     * the export class when making use of Responsable.
     */
    private $fileName = 'companies.xlsx';

    /**
     * Optional Writer Type
     */
    private $writerType = Excel::XLSX;

    /**
     * Optional headers
     */
    private $headers = [
        'Content-Type' => 'text/csv',
    ];

    public function columnFormats(): array
    {
        return [
            'F' => NumberFormat::FORMAT_NUMBER,
            'H' => NumberFormat::FORMAT_NUMBER,
            'I' => NumberFormat::FORMAT_NUMBER,
        ];
    }

    public function array(): array
    {
        $hasDateRange = isset($this->startDate) && isset($this->endDate);

        $companies = Company::query()
            ->with(['address', 'employees.user', 'paymentAccounts.phoneNumber'])
            ->where('type', $this->type)
            ->when($this->companyId, function ($query) {
                return $query->where('id', $this->companyId);
            })
            ->when($hasDateRange, function ($query) {
                return $query->whereBetween('created_at', [$this->startDate, $this->endDate]);
            })
            ->get();
        $headers = ['Date', 'Company Name', 'Co. ID', 'Contact Person', 'Contact Email', 'Contact No. (Main)', 'Address', 'Bank Name', 'Bank Account'];
        $data = [$headers];

        foreach ($companies as $company) {
            $data[] = [
                Carbon::parse($company->created_at)->setTimezone('Asia/Kuala_Lumpur'),
                $company->name,
                $company->company_code,
                $company->employees[0]->user->name,
                $company->employees[0]->user->email,
                $company->phoneNumber->full_phone_number,
                $company->address->full_address,
                $company->paymentAccounts[0]->phoneNumber->full_phone_number,
                $company->paymentAccounts[0]->account_number,
            ];
        }

        return [$data];
    }
}
