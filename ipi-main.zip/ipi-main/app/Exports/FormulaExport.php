<?php

namespace App\Exports;

use App\Models\Formula;
use Carbon\Carbon;
use Illuminate\Contracts\Support\Responsable;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;
use Maatwebsite\Excel\Excel;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;

class FormulaExport implements FromArray, Responsable, WithColumnFormatting, ShouldAutoSize
{
    use Exportable;

    private $type;
    private $startDate;
    private $endDate;
    private $formulaTypeId;
    private $customerId;
    private $productTagId;

    public function __construct($type, $startDate, $endDate, $formulaTypeId, $customerId, $productTagId)
    {
        $this->type = $type;
        $this->startDate = $startDate ? Carbon::parse($startDate)->startOfDay() : null;
        $this->endDate = $endDate ? Carbon::parse($endDate)->endOfDay() : null;
        $this->formulaTypeId = $formulaTypeId;
        $this->customerId = $customerId;
        $this->productTagId = $productTagId;
    }

    public function columnFormats(): array
    {
        return [
            'D' => '0.0000',
            'E' => NumberFormat::FORMAT_NUMBER_00,
            'F' => '0.00000',
        ];
    }

    /**
     * It's required to define the fileName within
     * the export class when making use of Responsable.
     */
    private $fileName = 'formulas.xlsx';

    /**
     * Optional Writer Type
     */
    private $writerType = Excel::XLSX;

    /**
     * Optional headers
     */
    private $headers = [
        'Content-Type' => 'text/csv',
    ];

    public function array(): array
    {
        $hasDateRange = isset($this->startDate) && isset($this->endDate);

        $formulas = Formula::query()
            ->with(['product', 'ingredientLists.ingredientListItems.product'])
            ->when($hasDateRange, function ($query) {
                return $query->whereBetween('created_at', [$this->startDate, $this->endDate]);
            })
            ->when($this->type, function ($query) {
                return $query->whereHas('product', function ($query) {
                    return $query->where('products.type', $this->type);
                });
            })
            ->when($this->formulaTypeId, function ($query) {
                return $query->whereHas('formulaType', function ($query) {
                    return $query->where('formula_types.id', $this->formulaTypeId);
                });
            })
            ->when($this->customerId, function ($query) {
                return $query->whereHas('product', function ($query) {
                    return $query->where('requester_customer_id', $this->customerId);
                });
            })
            ->when($this->productTagId, function ($query) {
                return $query->whereHas('product', function ($query) {
                    return $query->whereHas('productTags', function ($query) {
                        return $query->where('product_tags.id', $this->productTagId);
                    });
                });
            })
            ->get();
        $data = [];

        foreach ($formulas as $formula) {
            $data[] = ['Product', $formula->product->name];
            $data[] = ['Code', $formula->product->product_code];
            $data[] = [];
            $data[] = ['', 'Ingredient'];
            $data[] = ['Item', 'Code', 'Description', 'Quantity (KG)', 'Cost Per Unit', 'Total'];
            $data[] = [];
            $key = 1;
            $totalCost = 0;

            foreach ($formula->ingredientLists as $ingredientList) {
                foreach ($ingredientList->ingredientListItems as $ingredientListItem) {
                    $percentage = $ingredientListItem->percentage / 100;
                    $unitCost = $ingredientListItem->product->unit_cost / 100;
                    $itemCost = $percentage * $unitCost;

//                    if ($itemCost < 0.01) {
//                        $itemCost = 0.01;
//                    }

                    $totalCost += $itemCost;

                    $data[] = [
                        $key,
                        $ingredientListItem->product->product_code,
                        $ingredientListItem->product->description,
                        number_format($percentage, 4),
                        number_format($unitCost, 2),
                        number_format($itemCost, 5),
                    ];
                    $key++;
                }

                $data[] = [];
            }

            $data[] = ['', '', '', '1', '', number_format($totalCost, 5)];
            $data[] = [];
            $data[] = [];
        }

        return [$data];
    }
}
