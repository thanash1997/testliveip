<?php

namespace App\Exports;

use App\Models\Inventory;
use App\Models\Product as EloquentProduct;
use Carbon\Carbon;
use Illuminate\Contracts\Support\Responsable;
use Illuminate\Database\Eloquent\Collection as EloquentCollection;
use Illuminate\Support\Collection as SupportCollection;
use IPI\Core\Entities\Product;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;
use Maatwebsite\Excel\Excel;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;

class WarehouseInventoryExport implements FromArray, Responsable, WithColumnFormatting, ShouldAutoSize
{
    use Exportable;

    private $startDate;
    private $endDate;
    private $customerId;
    private $productType;
    private $productTagId;
    private $quantity;
    private $threshold;

    public function __construct($startDate, $endDate, $productType, $productTagId, $quantity, $threshold)
    {
        $this->startDate = $startDate ? Carbon::parse($startDate)->startOfDay() : null;
        $this->endDate = $endDate ? Carbon::parse($endDate)->endOfDay() : null;
        $this->productType = $productType;
        $this->productTagId = $productTagId;
        $this->quantity = $quantity;
        $this->threshold = $threshold;
    }

    public function columnFormats(): array
    {
        return [
            'D' => '0.0000',
            'F' => '0.00000',
        ];
    }

    /**
     * It's required to define the fileName within
     * the export class when making use of Responsable.
     */
    private $fileName = 'inventory.xlsx';

    /**
     * Optional Writer Type
     */
    private $writerType = Excel::XLSX;

    /**
     * Optional headers
     */
    private $headers = [
        'Content-Type' => 'text/csv',
    ];

    public function array(): array
    {
        $warehouseInventory = Inventory::query()->where('slug', 'warehouse')->first();
        $eloquentQueryBuilder = EloquentProduct::query()->withCreator();

        if ($this->startDate !== null && $this->endDate !== null) {
            $eloquentQueryBuilder->whereBetween('products.created_at', [
                $this->startDate,
                $this->endDate
            ]);
        }

        if ($this->productType !== null) {
            $eloquentQueryBuilder->where(function ($query) {
                return $query->where('type', $this->productType)
                    ->orWhere('type_code', $this->productType);
            });
        }

        if ($this->productTagId !== null) {
            $eloquentQueryBuilder->whereHas('productTags', function ($query) {
                return $query->where('product_tags.id', $this->productTagId);
            });
        }

        $eloquentQueryBuilder
            ->whereInventoryIs($warehouseInventory->id)
            ->addSelect('quantity', 'inventory_products.quantity')
            ->where('quantity', '>', 0);

        if ($this->quantity !== null) {
            $eloquentQueryBuilder->where('quantity', '>=', $this->quantity);
        }

        if ($this->threshold !== null) {
            $eloquentQueryBuilder->where('products.threshold', '>=', $this->threshold);
        }

        $products = $this->prepareProducts($eloquentQueryBuilder->get());

        $header = ['Date', 'Product Code', 'Description', 'Quantity', 'Threshold', 'Total Cost', 'Cost per unit', 'Product Tag'];
        $data = [$header];

        foreach ($products as $product) {
            $data[] = [
                Carbon::parse($product->createdAt)->setTimezone('Asia/Kuala_Lumpur'),
                $product->productCode,
                $product->description,
                $product->quantity / 1000,
                $product->threshold / 1000,
                $product->quantity / 1000 * $product->unitCost / 100,
                $product->unitCost / 100,
                !empty($product->productTags) ? $product->productTags[0]->name : 0,
            ];
        }

        return [$data];
    }

    private function prepareProducts(EloquentCollection|SupportCollection $collection): array
    {
        $products = [];

        foreach ($collection as $item) {
            $product = new Product($item->id);
            $product->setFromArray($item->toArray());
            $product->setProductTags($item->productTags->toArray());

            $products[] = $product;
        }

        return $products;
    }
}
