<?php

namespace App\Exports;

use App\Models\PurchaseOrder;
use Carbon\Carbon;
use Illuminate\Contracts\Support\Responsable;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Excel;

class ProcurementExport implements FromArray, Responsable, ShouldAutoSize
{
    use Exportable;

    private $procurementStartDate;
    private $procurementEndDate;
    private $receivingStartDate;
    private $receivingEndDate;
    private $quantity;
    private $threshold;

    public function __construct($procurementStartDate, $procurementEndDate, $receivingStartDate, $receivingEndDate, $quantity, $threshold)
    {
        $this->procurementStartDate = $procurementStartDate ? Carbon::parse($procurementStartDate)->startOfDay() : null;
        $this->procurementEndDate = $procurementEndDate ? Carbon::parse($procurementEndDate)->endOfDay() : null;
        $this->receivingStartDate = $receivingStartDate ? Carbon::parse($receivingStartDate)->startOfDay() : null;
        $this->receivingEndDate = $receivingEndDate ? Carbon::parse($receivingEndDate)->endOfDay() : null;
        $this->quantity = $quantity;
        $this->threshold = $threshold;
    }

    /**
     * It's required to define the fileName within
     * the export class when making use of Responsable.
     */
    private $fileName = 'procurements.xlsx';

    /**
     * Optional Writer Type
     */
    private $writerType = Excel::XLSX;

    /**
     * Optional headers
     */
    private $headers = [
        'Content-Type' => 'text/csv',
    ];

    public function array(): array
    {
        $hasProcurementDateRange = isset($this->procurementStartDate) && isset($this->procurementEndDate);
        $hasReceivingDateRange = isset($this->receivingStartDate) && isset($this->receivingEndDate);
        $procurements = PurchaseOrder::query()
            ->withTrashed()
            ->with(['purchaseOrderItems.product'])
            ->when($hasProcurementDateRange, function ($query) {
                return $query->whereBetween('purchase_orders.created_at', [$this->procurementStartDate, $this->procurementEndDate]);
            })
            ->when($hasReceivingDateRange, function ($query) {
                return $query->whereBetween('purchase_orders.expected_receive_date', [$this->receivingStartDate, $this->receivingEndDate]);
            })
            ->get();

        $header = ['Date', 'Received By', 'PO. No', 'Product Code', 'Quantity', 'Packaging Size', 'Total Cost', 'Cost per unit', 'Flagged Reasoning'];
        $data = [$header];

        foreach ($procurements as $procurement) {
            foreach ($procurement->purchaseOrderItems as $purchaseOrderItem) {
                $data[] = [
                    Carbon::parse($procurement->created_at)->setTimezone('Asia/Kuala_Lumpur'),
                    Carbon::parse($procurement->expected_receive_date)->setTimezone('Asia/Kuala_Lumpur'),
                    $procurement->po_number,
                    $purchaseOrderItem->product->product_code,
                    $purchaseOrderItem->quantity / 1000,
                    $purchaseOrderItem->packaging_size,
                    $purchaseOrderItem->total_cost / 100,
                    $purchaseOrderItem->unit_cost / 100,
                    $purchaseOrderItem->flag_reason,
                ];
            }
        }

        return [$data];
    }
}
