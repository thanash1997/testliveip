<?php

namespace App\Exports;

use App\Models\Formula;
use App\Models\Order;
use Carbon\Carbon;
use Illuminate\Contracts\Support\Responsable;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;
use Maatwebsite\Excel\Excel;

class ProductionConsumptionExport implements FromArray, Responsable, ShouldAutoSize, WithColumnFormatting
{
    use Exportable;

    private $startDate;
    private $endDate;
    private $orderId;
    private $formulaTypeId;

    public function __construct($startDate, $endDate, $orderId, $formulaTypeId)
    {
        $this->startDate = $startDate ? Carbon::parse($startDate)->startOfDay() : null;
        $this->endDate = $endDate ? Carbon::parse($endDate)->endOfDay() : null;
        $this->orderId = $orderId;
        $this->formulaTypeId = $formulaTypeId;
    }

    public function columnFormats(): array
    {
        return [
            'C' => '0.0000',
            'D' => '0.0000',
            'E' => '0.0000',
        ];
    }

    /**
     * It's required to define the fileName within
     * the export class when making use of Responsable.
     */
    private $fileName = 'consumptions.xlsx';

    /**
     * Optional Writer Type
     */
    private $writerType = Excel::XLSX;

    /**
     * Optional headers
     */
    private $headers = [
        'Content-Type' => 'text/csv',
    ];

    public function array(): array
    {
        $hasDateRange = isset($this->startDate) && isset($this->endDate);
        $orders = Order::query()
            ->with(['customer.address', 'orderItems.product' => function ($query) {
                return $query->with(['inventories' => function ($query) {
                    return $query->where('inventories.slug', 'production');
                }]);
            }])
            ->when($hasDateRange, function ($query) {
                return $query->whereBetween('created_at', [$this->startDate, $this->endDate]);
            })
            ->when($this->orderId, function ($query) {
                return $query->where('orders.id', $this->orderId);
            })
            ->get();

        $header = ['Date', 'Product Code', 'Initial Quantity', 'Used Quantity', 'Final Quantity', 'Batch No', 'Product Description', 'Customer Name'];
        $data = [$header];

        foreach ($orders as $order) {
            foreach ($order->orderItems as $orderItem) {
                $formula = Formula::query()
                    ->with(['ingredientLists.ingredientListItems.product' => function ($query) {
                        return $query->with(['inventories' => function ($query) {
                            return $query->where('inventories.slug', 'production');
                        }]);
                    }])
                    ->where('product_id', $orderItem->product->id)
                    ->first();

                foreach ($formula->ingredientLists as $ingredientList) {
                    foreach ($ingredientList->ingredientListItems as $ingredientListItem) {
                        $quantity = $ingredientListItem->percentage * 10 * ($orderItem->quantity / 1000) / 1000;

                        $data[] = [
                            Carbon::parse($order->created_at)->setTimezone('Asia/Kuala_Lumpur'),
                            $ingredientListItem->product->product_code,
                            $ingredientListItem->product->inventories[0]->pivot->quantity / 1000 + $quantity,
                            $quantity,
                            $ingredientListItem->product->inventories[0]->pivot->quantity / 1000 == 0 ? '0.0000' : $ingredientListItem->product->inventories[0]->pivot->quantity / 1000,
                            $order->batch_no,
                            $ingredientListItem->product->description,
                            $order->customer->name,
                        ];
                    }
                }
            }
        }

        return [$data];
    }
}
