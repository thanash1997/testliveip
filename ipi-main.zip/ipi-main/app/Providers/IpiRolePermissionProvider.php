<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use IPI\Core\User\SpatieUserRoleAssigner;
use IPI\Core\User\IUserRoleAssigner;
use RuntimeException;

class IpiRolePermissionProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(IUserRoleAssigner::class, function ($app) {
            return match ($app->make('config')->get('ipi.role-permission-lib')) {
                'spatie/laravel-permission' => new SpatieUserRoleAssigner(),
                default => throw new RuntimeException('Unknown role permission library'),
            };
        });
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
