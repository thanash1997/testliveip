<?php

namespace App\Providers;

use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class NavigationViewServiceProvider extends ServiceProvider
{
    private array $pages = [
        'nav.dashboard' => [
            'route_name' => 'dashboard',
            'label' => 'Dashboard',
            'parent' => 'dashboard',
        ],
        'nav.production' => [
            'route_name' => 'production',
            'label' => 'Production',
            'parent' => 'production',
            'children' => [
                [
                    'route_name' => 'production',
                    'label' => 'Orders',
                ],
                [
                    'route_name' => 'production.product-requisitions',
                    'label' => 'Internal Material Req.',
                ],
                [
                    'route_name' => 'production.sub',
                    'label' => 'Sub Inventory',
                ],
                [
                    'route_name' => 'production.internal-do',
                    'label' => 'Internal Delivery Order',
                ],
            ]
        ],
        'nav.warehouse' => [
            'route_name' => 'warehouse',
            'label' => 'Warehouse',
            'parent' => 'warehouse',
            'children' => [
                [
                    'route_name' => 'warehouse',
                    'label' => 'Main Inventory',
                ],
                [
                    'route_name' => 'warehouse.sub',
                    'label' => 'Sub Inventory',
                ],
                [
                    'route_name' => 'warehouse.product-requisitions',
                    'label' => 'Internal Material Req.',
                ],
                [
                    'route_name' => 'warehouse.procurement',
                    'label' => 'Procurement of Material',
                ],
                [
                    'route_name' => 'warehouse.internal-do',
                    'label' => 'Internal Delivery Order',
                ],
                [
                    'route_name' => 'warehouse.external-do',
                    'label' => 'External Delivery Order',
                ],
            ]
        ],
        'nav.formula' => [
            'route_name' => 'formula',
            'label' => 'Formula',
            'parent' => 'formula',
            'children' => [
                [
                    'route_name' => 'formula',
                    'label' => 'Formula List',
                ],
                [
                    'route_name' => 'formula.sampling',
                    'label' => 'Sampling List',
                ],
                [
                    'route_name' => 'formula.type',
                    'label' => 'Formula Type List',
                ],
                [
                    'route_name' => 'formula.create',
                    'label' => 'Add New Formula',
                ],
                [
                    'route_name' => 'formula.sampling.create',
                    'label' => 'Add Sampling Formula',
                ],
            ]
        ],
        'nav.customer' => [
            'route_name' => 'customer',
            'label' => 'Customer',
            'parent' => 'customer',
        ],
        'nav.supplier' => [
            'route_name' => 'supplier',
            'label' => 'Supplier',
            'parent' => 'supplier',
        ],
        'nav.report' => [
            'route_name' => 'report',
            'label' => 'Report',
            'parent' => 'report',
        ],
    ];

    private const DEPARTMENT_PAGES = [
        'warehouse' => [
            'admin' => [
                'nav.dashboard',
                'nav.warehouse',
                'nav.formula',
                'nav.customer',
                'nav.report',
                'nav.supplier'
            ],
            'hod' => [
                'nav.dashboard',
                'nav.warehouse',
            ],
            'staff' => [
                'nav.dashboard',
                'nav.warehouse',
            ]
        ],
        'production' => [
            'admin' => [
                'nav.dashboard',
                'nav.production',
                'nav.formula',
                'nav.customer',
                'nav.report',
                'nav.supplier'
            ],
            'hod' => [
                'nav.dashboard',
                'nav.production',
                'nav.formula',
                'nav.customer',
                'nav.report',
                'nav.supplier'
            ],
            'staff' => [
                'nav.dashboard',
                'nav.production',
                'nav.formula',
                'nav.customer',
                'nav.supplier'
            ],
        ],
        'sales' => [
            'admin' => [
                'nav.dashboard',
                'nav.production',
                'nav.customer',
                'nav.supplier'
            ],
            'hod' => [
                'nav.dashboard',
                'nav.production',
                'nav.customer',
                'nav.supplier'
            ],
            'staff' => [
                'nav.dashboard',
                'nav.production',
                'nav.customer',
                'nav.supplier'
            ],
        ],
        'lab' => [
            'admin' => [
                'nav.dashboard',
                'nav.formula',
            ],
            'hod' => [
                'nav.dashboard',
                'nav.formula',
            ],
            'staff' => [
                'nav.dashboard',
                'nav.formula',
            ],
        ],
        'admin' => [
            'admin' => [
                'nav.dashboard',
                'nav.production',
                'nav.warehouse',
                'nav.formula',
                'nav.customer',
                'nav.report',
                'nav.supplier'
            ],
            'hod' => [
                'nav.dashboard',
                'nav.production',
                'nav.warehouse',
                'nav.formula',
                'nav.customer',
                'nav.supplier'
            ],
            'staff' => [
                'nav.dashboard',
                'nav.production',
                'nav.warehouse',
                'nav.formula',
                'nav.customer',
                'nav.supplier'
            ],
        ],
    ];

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        View::composer('*', function ($view) {
            $user = auth()->user();

            if (!$user) {
                return;
            }

            $department = $user->department;
            $userDepartment = strtolower($department->name);
            $roles = $user->getRoleNames();
            $userRole = $roles[0];

            $navigations = [];
            $navigationPermissions = $user->getPermissionsViaRoles()->filter(function ($permission) {
                return preg_match('/nav\./', $permission->name);
            });

            $path = explode('/', request()->path());
            $pathRegex = implode('\/', $path);

            foreach ($navigationPermissions as $page) {
                if (isset($this->pages[$page->name])) {
                    if ($userRole !== 'super-admin' && !in_array($page->name, self::DEPARTMENT_PAGES[$userDepartment][$userRole])) {
                        continue;
                    }

                    $page = $this->pages[$page->name];
                    $route = route($page['route_name']);
                    $pagePath = implode('/', array_slice(explode('/', $route), 3));
                    $pagePathRegex = str_replace('/', '\/', $pagePath);
                    $isActive = preg_match("/{$pagePathRegex}/", str_replace('\\', '', $pathRegex)) === 1;
                    $children = [];

                    if (isset($page['children'])) {
                        foreach ($page['children'] as $child) {
                            $childRoute = route($child['route_name']);

                            $children[] = [
                                'href' => $childRoute,
                                'label' => $child['label'],
                                'is_active' => preg_match("/{$pathRegex}$/", $childRoute) === 1,
                            ];
                        }
                    }

                    $navigations[] = [
                        'href' => $route,
                        'label' => $page['label'],
                        'is_active' => $isActive,
                        'parent' => $page['parent'],
                        'children' => $children
                    ];
                }
            }

            $view->with('nav', json_encode($navigations));
        });
    }
}
