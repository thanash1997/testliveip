<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Inventory extends Model
{
    use HasFactory;

    public const PRODUCTION = 'production';
    public const WAREHOUSE = 'warehouse';
    public const NAMES = [
        self::PRODUCTION => 'Production',
        self::WAREHOUSE => 'Warehouse',
    ];
    public const DISPLAY_NAMES = [
        self::PRODUCTION => 'Factory',
        self::WAREHOUSE => 'Warehouse',
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'display_name',
        'slug',
    ];

    /**
     * Eloquent relationship declaration for inventory products.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function products(): BelongsToMany
    {
        return $this->belongsToMany(Product::class, 'inventory_products')
            ->withTimestamps()
            ->withPivot(['quantity']);
    }
}
