<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class ExternalDeliveryItem extends Model
{
    use HasFactory;
    use SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'quantity',
        'packaging_size',
        'description',
    ];

    /**
     * Eloquent relationship declaration for EDO.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function externalDeliveryOrder(): BelongsTo
    {
        return $this->belongsTo(ExternalDeliveryOrder::class);
    }

    /**
     * Eloquent relationship declaration for product.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class, 'product_id');
    }

    /**
     * Eloquent relationship declaration for order/batch ticket.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class, 'order_id');
    }
}
