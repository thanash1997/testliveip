<?php

namespace App\Models;

use App\Models\General\HasCreator;
use App\Models\General\HasUUID;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use OwenIt\Auditing\Auditable;
use OwenIt\Auditing\Contracts\Auditable as IAuditable;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;

class Order extends Model implements IAuditable, HasMedia
{
    use HasFactory;
    use SoftDeletes;
    use Auditable;
    use HasCreator;
    use HasUUID;
    use InteractsWithMedia;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'batch_no',
        'description',
        'total_cost',
        'estimated_delivered_at',
        'production_started_at',
        'pending_for_material_at',
        'scheduled_for_planning_at',
        'completed_at',
        'cancelled_at',
        'halted_at',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'estimated_delivered_at' => 'datetime',
        'production_started_at' => 'datetime',
        'pending_for_material_at' => 'datetime',
        'scheduled_for_planning_at' => 'datetime',
        'completed_at' => 'datetime',
        'cancelled_at' => 'datetime',
        'halted_at' => 'datetime',
    ];

    /**
     * Eloquent relationship declaration for customer.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function customer(): BelongsTo
    {
        return $this->belongsTo(Company::class, 'customer_id');
    }

    /**
     * Eloquent relationship declaration for person in charge.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function personInCharge(): BelongsTo
    {
        return $this->belongsTo(User::class, 'pic_id');
    }

    /**
     * Eloquent relationship declaration for shipment details.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function shipment(): BelongsTo
    {
        return $this->belongsTo(Shipment::class);
    }

    /**
     * Eloquent relationship declaration for contact person.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function contactPerson(): BelongsTo
    {
        return $this->belongsTo(User::class, 'contact_person_id');
    }

    /**
     * Eloquent relationship declaration for order items.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function orderItems(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }
}
