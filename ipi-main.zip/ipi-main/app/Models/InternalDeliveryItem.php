<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class InternalDeliveryItem extends Model
{
    use HasFactory;
    use SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'quantity',
        'packaging_size',
        'description',
    ];

    /**
     * Eloquent relationship declaration for IDO.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function internalDeliveryOrder(): BelongsTo
    {
        return $this->belongsTo(InternalDeliveryOrder::class, 'internal_delivery_order_id');
    }

    /**
     * Eloquent relationship declaration for product.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class, 'product_id');
    }
}
