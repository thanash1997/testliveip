<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Country extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'name',
        'iso_3166_alpha_2_code',
        'iso_4217_currency_code',
        'geo_name_id',
    ];

    /**
     * Eloquent relationship declaration for dialing codes.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function dialingCodes(): HasMany
    {
        return $this->hasMany(DialingCode::class);
    }

    /**
     * Eloquent relationship declaration for banks.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function banks(): HasMany
    {
        return $this->hasMany(Bank::class);
    }
}
