<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ChatRoom extends Model
{
    use HasFactory;

    protected $fillable = [
        'first_participant_id',
        'second_participant_id',
    ];

    public function firstParticipant(): BelongsTo
    {
        return $this->belongsTo(User::class, 'first_participant_id');
    }

    public function secondParticipant(): BelongsTo
    {
        return $this->belongsTo(User::class, 'second_participant_id');
    }

    public function chatMessages(): HasMany
    {
        return $this->hasMany(ChatMessage::class, 'room_id');
    }
}
