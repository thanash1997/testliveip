<?php

namespace App\Models;

use App\Models\General\HasCreator;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use OwenIt\Auditing\Auditable;
use OwenIt\Auditing\Contracts\Auditable as IAuditable;

class Remark extends Model implements IAuditable
{
    use HasFactory;
    use SoftDeletes;
    use Auditable;
    use HasCreator;
    
    protected $fillable = ['body'];
    
    public function remarkable(): MorphTo
    {
        return $this->morphTo();
    }
}
