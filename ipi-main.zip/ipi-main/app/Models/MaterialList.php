<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class MaterialList extends Model
{
    use HasFactory;
    use SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'remark',
        'total_cost',
        'position',
    ];

    /**
     * Eloquent relationship declaration for formulas.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function orderItem(): BelongsTo
    {
        return $this->belongsTo(OrderItem::class);
    }

    /**
     * Eloquent relationship declaration for ingredient list.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function ingredientList(): BelongsTo
    {
        return $this->belongsTo(IngredientList::class);
    }

    /**
     * Eloquent relationship declaration for production materials.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function productionMaterials(): HasMany
    {
        return $this->hasMany(ProductionMaterial::class);
    }
}
