<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Address extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'line_1',
        'line_2',
        'city',
        'state',
        'postcode',
        'country_id',
    ];

    /**
     * Eloquent relationship declaration for country.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function country(): BelongsTo
    {
        return $this->belongsTo(Country::class);
    }

    public function getFullAddressAttribute()
    {
        return "{$this->attributes['line_1']}, \n{$this->attributes['line_2']}\n{$this->attributes['city']}, \n{$this->attributes['state']}, \n{$this->attributes['postcode']}";
    }
}
