<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Checkpoint extends Model
{
    use HasFactory;

    public const TYPE_GR_STD = 'gr_std';
    public const TYPE_GR_SAMP = 'gr_samp';
    public const TYPE_SR_STD = 'sr_std';
    public const TYPE_SR_SAMP = 'sr_samp';
    public const TYPE_IR_STD = 'ir_std';
    public const TYPE_IR_SAMP = 'ir_samp';
    public const TYPE_VIS_STD = 'vis_std';
    public const TYPE_VIS_SAMP = 'vis_samp';
    public const ALL_TYPES = [
        self::TYPE_GR_SAMP,
        self::TYPE_GR_STD,
        self::TYPE_IR_SAMP,
        self::TYPE_IR_STD,
        self::TYPE_SR_SAMP,
        self::TYPE_SR_STD,
        self::TYPE_VIS_SAMP,
        self::TYPE_VIS_STD,
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'type',
        'range_min',
        'range_max',
        'tolerance_min',
        'tolerance_max',
        'equipment',
        'remark',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'formula_id',
    ];

    /**
     * Eloquent relationship declaration for formula.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function formula(): BelongsTo
    {
        return $this->belongsTo(Formula::class);
    }
}
