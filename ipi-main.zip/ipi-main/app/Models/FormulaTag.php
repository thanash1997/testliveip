<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class FormulaTag extends Model
{
    use HasFactory;
    use SoftDeletes;

    public const SEMI_FINISHED = 'semi-finished-goods';
    public const FINISHED = 'finished-goods';
    public const ALL_TAGS = [
        self::SEMI_FINISHED,
        self::FINISHED
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'name',
        'slug',
    ];

    /**
     * Eloquent relationship declaration for formulas.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function formulas(): BelongsToMany
    {
        return $this->belongsToMany(Formula::class, 'formula_formula_tags')
            ->withTimestamps();
    }
}
