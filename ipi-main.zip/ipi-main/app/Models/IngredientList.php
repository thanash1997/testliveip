<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class IngredientList extends Model
{
    use HasFactory;
    use SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'remark',
        'total_cost',
        'position',
    ];

    /**
     * Eloquent relationship declaration for formulas.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function formula(): BelongsTo
    {
        return $this->belongsTo(Formula::class);
    }

    /**
     * Eloquent relationship declaration for ingredient list items.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function ingredientListItems(): HasMany
    {
        return $this->hasMany(IngredientListItem::class);
    }
}
