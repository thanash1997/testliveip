<?php

namespace App\Models;

use App\Models\General\HasCreator;
use App\Models\General\HasUUID;
use App\Models\General\Remarkable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use OwenIt\Auditing\Auditable;
use OwenIt\Auditing\Contracts\Auditable as IAuditable;

class ProductRequisition extends Model implements IAuditable
{
    use HasFactory;
    use SoftDeletes;
    use Auditable;
    use HasCreator;
    use HasUUID;
    use Remarkable;

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'material_requisition_no',
        'origin',
        'flag_reason',
        'usage',
        'approved_at',
        'rejected_at',
        'flagged_at',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'approved_at' => 'datetime',
        'rejected_at' => 'datetime',
        'flagged_at' => 'datetime',
    ];

    /**
     * Eloquent relationship declaration for order.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class, 'order_id');
    }

    /**
     * Eloquent relationship declaration for PR destination.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function destination(): BelongsTo
    {
        return $this->belongsTo(Inventory::class, 'destination_id');
    }

    /**
     * Eloquent relationship declaration for PR items.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function productRequisitionItems(): HasMany
    {
        return $this->hasMany(ProductRequisitionItem::class);
    }
}
