<?php

namespace App\Models;

use App\Models\General\HasCreator;
use App\Models\General\HasUUID;
use App\Models\General\Remarkable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use OwenIt\Auditing\Auditable;
use OwenIt\Auditing\Contracts\Auditable as IAuditable;

class ExternalDeliveryOrder extends Model implements IAuditable
{
    use HasFactory;
    use SoftDeletes;
    use Auditable;
    use HasCreator;
    use HasUUID;
    use Remarkable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'batch_no',
        'delivery_order_no',
        'courier_name',
        'vehicle_no',
        'tracking_no',
        'receipt_no',
        'description',
        'flag_reason',
        'estimated_delivery_date',
        'fulfilled_at',
        'cancelled_at',
        'flagged_at',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'estimated_delivery_date' => 'datetime',
        'fulfilled_at' => 'datetime',
        'cancelled_at' => 'datetime',
        'flagged_at' => 'datetime',
    ];

    /**
     * Eloquent relationship declaration for customer.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function customer(): BelongsTo
    {
        return $this->belongsTo(Company::class, 'customer_id');
    }

    /**
     * Eloquent relationship declaration for address.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function address(): BelongsTo
    {
        return $this->belongsTo(Shipment::class, 'address_id');
    }

    /**
     * Eloquent relationship declaration for order items.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function orderItems(): HasMany
    {
        return $this->hasMany(ExternalDeliveryItem::class);
    }
}
