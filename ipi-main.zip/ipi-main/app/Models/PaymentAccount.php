<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PaymentAccount extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'account_name',
        'email',
        'account_holder_name',
        'account_number',
        'phone_number_id',
        'fax_number_id',
        'company_id',
        'address_id',
        'bank_id',
    ];

    /**
     * Eloquent relationship declaration for phone number.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function phoneNumber(): BelongsTo
    {
        return $this->belongsTo(PhoneNumber::class);
    }

    /**
     * Eloquent relationship declaration for fax number.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function faxNumber(): BelongsTo
    {
        return $this->belongsTo(PhoneNumber::class, 'fax_number_id');
    }

    /**
     * Eloquent relationship declaration for address.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function address(): BelongsTo
    {
        return $this->belongsTo(Address::class);
    }

    /**
     * Eloquent relationship declaration for fax number.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    /**
     * Eloquent relationship declaration for fax number.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function paymentMethod(): BelongsTo
    {
        return $this->belongsTo(PaymentMethod::class);
    }

    /**
     * Eloquent relationship declaration for fax number.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function bank(): BelongsTo
    {
        return $this->belongsTo(Bank::class);
    }
}
