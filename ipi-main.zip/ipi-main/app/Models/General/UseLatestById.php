<?php

namespace App\Models\General;

use Illuminate\Database\Eloquent\Builder;

/**
 * @method static latestById()
 */
trait UseLatestById
{
    public function scopeLatestById(Builder $builder): Builder
    {
        return $builder->orderBy('id', 'DESC');
    }
}
