<?php

namespace App\Models\General;

use Illuminate\Support\Str;

trait HasUUID
{
    /**
     * Boot function from Laravel.
     */
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            $key = $model->uuidKey ?? 'uuid';

            $model->{$key} = Str::uuid()->toString();
        });
    }
}
