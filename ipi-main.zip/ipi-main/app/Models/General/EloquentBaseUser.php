<?php

namespace App\Models\General;

use Illuminate\Foundation\Auth\User as Authenticatable;

abstract class EloquentBaseUser extends Authenticatable
{
    public const SUPER_ADMIN_ROLE = 'super-admin';
    public const ADMIN_ROLE = 'admin';
    public const HOD_ROLE = 'hod';
    public const STAFF_ROLE = 'staff';

    public const ALL_ROLES = [
        self::SUPER_ADMIN_ROLE,
        self::ADMIN_ROLE,
        self::HOD_ROLE,
        self::STAFF_ROLE,
    ];

    public const NAV_DASHBOARD_PERMISSION = 'nav.dashboard';
    public const NAV_CUSTOMER_PERMISSION = 'nav.customer';
    public const VIEW_CUSTOMER_INDEX_PERMISSION = 'view.customer.index';
    public const VIEW_CUSTOMER_CREATE_PERMISSION = 'view.customer.create';
    public const VIEW_CUSTOMER_DETAILS_PERMISSION = 'view.customer.details';
    public const CREATE_CUSTOMER_PERMISSION = 'create.customer';
    public const UPDATE_CUSTOMER_PERMISSION = 'update.customer';
    public const NAV_SUPPLIER_PERMISSION = 'nav.supplier';
    public const VIEW_SUPPLIER_INDEX_PERMISSION = 'view.supplier.index';
    public const VIEW_SUPPLIER_DETAILS_PERMISSION = 'view.supplier.details';
    public const VIEW_SUPPLIER_CREATE_PERMISSION = 'view.supplier.create';
    public const CREATE_SUPPLIER_PERMISSION = 'create.supplier';
    public const UPDATE_SUPPLIER_PERMISSION = 'update.supplier';
    public const VIEW_USER_INDEX_PERMISSION = 'view.user.index';
    public const VIEW_USER_CREATE_PERMISSION = 'view.user.create';
    public const VIEW_USER_UPDATE_PERMISSION = 'view.user.update';
    public const VIEW_USER_DETAILS_PERMISSION = 'view.user.details';
    public const CREATE_USER_PERMISSION = 'create.user';
    public const UPDATE_USER_PERMISSION = 'update.user';
    public const DELETE_USER_PERMISSION = 'delete.user';
    public const UPDATE_PASSWORD_PERMISSION = 'update.password';
    public const NAV_FORMULA_PERMISSION = 'nav.formula';
    public const VIEW_FORMULA_INDEX_PERMISSION = 'view.formula.index';
    public const VIEW_FORMULA_CREATE_PERMISSION = 'view.formula.create';
    public const VIEW_FORMULA_DETAILS_PERMISSION = 'view.formula.details';
    public const CREATE_FORMULA_PERMISSION = 'create.formula';
    public const UPDATE_FORMULA_PERMISSION = 'update.formula';
    public const DELETE_FORMULA_PERMISSION = 'delete.formula';
    public const VIEW_FORMULA_SAMPLING_INDEX_PERMISSION = 'view.formula.sampling.index';
    public const VIEW_FORMULA_SAMPLING_CREATE_PERMISSION = 'view.formula.sampling.create';
    public const VIEW_FORMULA_SAMPLING_DETAILS_PERMISSION = 'view.formula.sampling.details';
    public const CREATE_FORMULA_SAMPLING_PERMISSION = 'create.formula.sampling';
    public const UPDATE_FORMULA_SAMPLING_PERMISSION = 'update.formula.sampling';
    public const DELETE_FORMULA_SAMPLING_PERMISSION = 'delete.formula.sampling';
    public const NAV_WAREHOUSE_PERMISSION = 'nav.warehouse';
    public const NAV_PRODUCTION_PERMISSION = 'nav.production';
    public const NAV_REPORT_PERMISSION = 'nav.report';
    
    public const APPROVAL_PERMISSION = 'approval';
}
