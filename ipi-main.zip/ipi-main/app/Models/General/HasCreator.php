<?php

namespace App\Models\General;

use Illuminate\Support\Facades\DB;

/**
 * Trait HasCreator
 * @package App\Models\General
 *
 * @method static withCreator()
 */
trait HasCreator
{
    public function scopeWithCreator($builder)
    {
        return $builder->addSelect(['creator' => function ($query) {
            return $query->select('u1.name')
                ->from('audits')
                ->leftJoin(DB::raw('users u1'), 'audits.user_id', '=', 'u1.id')
                ->where('audits.auditable_id', DB::raw("{$this->getTable()}.{$this->getKeyName()}"))
                ->where('audits.auditable_type', '=', $this::class)
                ->limit(1);
        }]);
    }
}
