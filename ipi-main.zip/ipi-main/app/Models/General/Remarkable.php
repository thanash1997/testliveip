<?php

namespace App\Models\General;

use App\Models\Remark;
use Illuminate\Database\Eloquent\Relations\MorphMany;

trait Remarkable
{
    public function remarks(): MorphMany
    {
        return $this->morphMany(Remark::class, 'remarkable');
    }
}
