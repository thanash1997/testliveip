<?php

namespace App\Models;

use App\Models\General\HasCreator;
use App\Models\General\HasUUID;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use OwenIt\Auditing\Auditable;
use OwenIt\Auditing\Contracts\Auditable as IAuditable;

class Formula extends Model implements IAuditable
{
    use HasFactory;
    use SoftDeletes;
    use Auditable;
    use HasCreator;
    use HasUUID;

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'remark',
        'total_cost',
        'approved_at',
        'rejected_at',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'approved_at' => 'datetime',
        'rejected_at' => 'datetime',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var string[]
     */
    protected $hidden = [
        'formula_id',
    ];

    /**
     * Eloquent relationship declaration for formula engineer.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function engineer(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Eloquent relationship declaration for formula product.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    /**
     * Eloquent relationship declaration for formula type.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function formulaType(): BelongsTo
    {
        return $this->belongsTo(FormulaType::class);
    }

    /**
     * Eloquent relationship declaration for formula tags.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function formulaTags(): BelongsToMany
    {
        return $this->belongsToMany(FormulaTag::class, 'formula_formula_tags')
            ->withTimestamps();
    }

    /**
     * Eloquent relationship declaration for checkpoint.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function checkpoints(): HasMany
    {
        return $this->hasMany(Checkpoint::class);
    }

    /**
     * Eloquent relationship declaration for ingredient list.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function ingredientLists(): HasMany
    {
        return $this->hasMany(IngredientList::class);
    }
}
