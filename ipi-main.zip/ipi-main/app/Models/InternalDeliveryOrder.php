<?php

namespace App\Models;

use App\Models\General\HasCreator;
use App\Models\General\HasUUID;
use App\Models\General\Remarkable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use OwenIt\Auditing\Auditable;
use OwenIt\Auditing\Contracts\Auditable as IAuditable;

class InternalDeliveryOrder extends Model implements IAuditable
{
    use HasFactory;
    use SoftDeletes;
    use Auditable;
    use HasCreator;
    use HasUUID;
    use Remarkable;

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'batch_no',
        'delivery_order_no',
        'usage',
        'origin',
        'description',
        'flag_reason',
        'estimated_delivery_date',
        'fulfilled_at',
        'delivered_at',
        'flagged_at',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'estimated_delivery_date' => 'datetime',
        'fulfilled_at' => 'datetime',
        'delivered_at' => 'datetime',
        'flagged_at' => 'datetime',
    ];

    /**
     * Eloquent relationship declaration for person in charge.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function personInCharge(): BelongsTo
    {
        return $this->belongsTo(User::class, 'pic_id');
    }

    /**
     * Eloquent relationship declaration for IDO destination.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function destination(): BelongsTo
    {
        return $this->belongsTo(Inventory::class, 'destination_id');
    }

    /**
     * Eloquent relationship declaration for IDO origin.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function inventory(): BelongsTo
    {
        return $this->belongsTo(Inventory::class, 'inventory_id');
    }

    /**
     * Eloquent relationship declaration for IDO items.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function orderItems(): HasMany
    {
        return $this->hasMany(InternalDeliveryItem::class);
    }
}
