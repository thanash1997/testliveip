<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Shipment extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'name',
        'receiver_name',
        'email',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var string[]
     */
    protected $hidden = [
        'phone_number_id',
        'fax_number_id',
        'company_id',
        'address_id',
    ];

    /**
     * Eloquent relationship declaration for phone number.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function phoneNumber(): BelongsTo
    {
        return $this->belongsTo(PhoneNumber::class);
    }

    /**
     * Eloquent relationship declaration for fax number.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function faxNumber(): BelongsTo
    {
        return $this->belongsTo(PhoneNumber::class, 'fax_number_id');
    }

    /**
     * Eloquent relationship declaration for address.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function address(): BelongsTo
    {
        return $this->belongsTo(Address::class);
    }

    /**
     * Eloquent relationship declaration for fax number.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }
}
