<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PhoneNumber extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'phone_number',
        'dialing_code_id',
    ];

    protected $appends = ['full_phone_number'];

    /**
     * Eloquent relationship declaration for dialing code.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function dialingCode(): BelongsTo
    {
        return $this->belongsTo(DialingCode::class);
    }

    // TODO: REFACTOR!
    public function getFullPhoneNumberAttribute()
    {
        return "+" . $this->dialingCode->code . $this->attributes['phone_number'];
    }
}
