<?php

namespace App\Models;

use App\Models\General\HasCreator;
use App\Models\General\HasUUID;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use OwenIt\Auditing\Auditable;
use OwenIt\Auditing\Contracts\Auditable as IAuditable;

/**
 * Class Product
 *
 * Product class/model contains all material, formula and formula sample. Product exists
 * in multiple inventories, production and warehouse, with different quantities in each. Internal
 * delivery order will be perform to transfer the products between the inventories.
 *
 * 1. Unit cost is always calculated in equivalent cents value. Example:
 * RM23.50 is 2350 in unit_cost.
 *
 * 2. Type is an enum of the following (material, formula and formula_sample). Always
 * use the const types in entity to compare and assign to avoid confusion.
 *
 * @package App\Models
 */
class Product extends Model implements IAuditable
{
    use HasFactory;
    use SoftDeletes;
    use HasUUID;
    use Auditable;
    use HasCreator;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'product_code',
        'description',
        'name',
        'unit_cost',
        'threshold',
        'packaging_size',
        'type_code',
        'type',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'requester_customer_id',
    ];

    public function scopeWhereInventoryIs($query, $inventoryId)
    {
        return $query->join('inventory_products', function ($query) use ($inventoryId) {
            $query->on('product_id', '=', 'products.id');

            if ($inventoryId !== 0) {
                $query->where('inventory_id', $inventoryId);
            }
        });
    }

    /**
     * Eloquent relationship declaration for requester customer.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function requesterCustomer(): BelongsTo
    {
        return $this->belongsTo(Company::class, 'requester_customer_id');
    }

    /**
     * Eloquent relationship declaration for inventories.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function inventories(): BelongsToMany
    {
        return $this->belongsToMany(Inventory::class, 'inventory_products')
            ->withTimestamps()
            ->withPivot(['quantity']);
    }

    /**
     * Eloquent relationship declaration for product tags.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function productTags(): BelongsToMany
    {
        return $this->belongsToMany(ProductTag::class, 'product_product_tag');
    }
}
