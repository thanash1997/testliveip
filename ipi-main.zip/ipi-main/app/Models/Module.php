<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Module extends Model
{
    use HasFactory;

    public const PRODUCTION = 'production';
    public const WAREHOUSE = 'warehouse';
    public const FORMULA = 'formula';
    public const ALL_MODULES = [
        self::PRODUCTION,
        self::WAREHOUSE,
        self::FORMULA
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'name',
        'slug'
    ];

    /**
     * Eloquent relationship declaration for notifications.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function notifications(): BelongsToMany
    {
        return $this->belongsToMany(Notification::class, 'notification_module')->withTimestamps();
    }

    /**
     * Eloquent relationship declaration for departments.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function departments(): BelongsToMany
    {
        return $this->belongsToMany(Department::class, 'department_module');
    }
}
