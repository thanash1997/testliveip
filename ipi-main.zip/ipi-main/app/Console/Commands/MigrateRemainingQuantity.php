<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class MigrateRemainingQuantity extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:order-items-remaining-quantity';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Migrate remaining quantity for all order items.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle(): void
    {
        DB::statement('UPDATE order_items SET remaining_quantity = quantity WHERE remaining_quantity IS NULL;');
    }
}
