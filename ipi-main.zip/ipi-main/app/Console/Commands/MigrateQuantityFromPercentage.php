<?php

namespace App\Console\Commands;

use App\Models\ProductionMaterial;
use Illuminate\Console\Command;

class MigrateQuantityFromPercentage extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:production-materials-quantity';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Migrate production materials percentage to quantity';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $productionMaterials = ProductionMaterial::query()
            ->with('materialList.orderItem')
            ->cursor();

        foreach ($productionMaterials as $productionMaterial) {
            $orderItem = $productionMaterial->materialList->orderItem;
            $productionMaterial->quantity = (float)$productionMaterial->percentage / 100
                * ($orderItem->quantity / 1000) * 1000;
            $productionMaterial->save();
        }
    }
}
