<?php

namespace App\Console\Commands;

use App\Models\OrderItem;
use Illuminate\Console\Command;
use IPI\Core\Order\ReplicateIngredients;

class MigrateIngredientsToOrderItems extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migration:order-items-ingredients';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Migrate all order items with its ingredients.';

    private ReplicateIngredients $replicateIngredients;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(ReplicateIngredients $replicateIngredients)
    {
        parent::__construct();

        $this->replicateIngredients = $replicateIngredients;
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $orderItems = OrderItem::query()
            ->whereDoesntHave('materialLists')
            ->get(['id']);

        foreach ($orderItems as $orderItem) {
            $this->replicateIngredients->replicateToOrderItem($orderItem->id);
        }
    }
}
