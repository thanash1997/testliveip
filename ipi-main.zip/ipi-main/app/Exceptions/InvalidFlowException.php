<?php

namespace App\Exceptions;

use Exception;

class InvalidFlowException extends Exception
{
    //
}
