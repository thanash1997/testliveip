<?php

namespace App\Http\Requests\Order;

use App\Http\Requests\BaseFormRequest;
use Carbon\Carbon;
use Illuminate\Validation\Rule;
use IPI\Core\DTO\CreateInternalDeliveryItemData;
use IPI\Core\DTO\CreateInternalDeliveryOrderData;
use IPI\Core\Entities\InternalDeliveryOrder;

class CreateInternalDeliveryOrderRequest extends BaseFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        // TODO: Add permission validation
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'pic_id' => 'required|exists:users,id',
            'batch_no' => 'nullable|exists:orders,batch_no',
            'destination_id' => 'required|exists:inventories,id',
            'inventory_id' => 'required|exists:inventories,id',
            'usage' => 'required|string',
            'description' => 'nullable|string',
            'flag_reason' => 'nullable|string',
            'origin' => 'nullable|string',
            'is_flagged' => 'nullable|boolean',
            'estimated_delivery_date' => 'required|date',
            'remark' => 'nullable|string',
            'status' => ['nullable', Rule::in(InternalDeliveryOrder::ALL_STATUSES)],
            'order_items' => 'required|array',
            'order_items.*.product_id' => 'required_without:order_items.*.product_code|exists:products,id',
            'order_items.*.product_code' => 'required_without:order_items.*.product_id|string',
            'order_items.*.quantity' => 'required|numeric',
            'order_items.*.packaging_size' => 'required|string',
            'order_items.*.description' => 'required|string',
        ];
    }

    public function toDTO(): CreateInternalDeliveryOrderData
    {
        $validatedData = $this->validated();

        $createInternalDeliveryOrderData = new CreateInternalDeliveryOrderData();
        $createInternalDeliveryOrderData->picId = $validatedData['pic_id'];
        $createInternalDeliveryOrderData->batchNo = $validatedData['batch_no'] ?? null;
        $createInternalDeliveryOrderData->destinationId = $validatedData['destination_id'];
        $createInternalDeliveryOrderData->inventoryId = $validatedData['inventory_id'];
        $createInternalDeliveryOrderData->usage = $validatedData['usage'];
        $createInternalDeliveryOrderData->description = $validatedData['description'] ?? null;
        $createInternalDeliveryOrderData->flagReason = $validatedData['flag_reason'] ?? null;
        $createInternalDeliveryOrderData->origin = $validatedData['origin'] ?? 'IPI Sdn Bhd';
        $createInternalDeliveryOrderData->isFlagged = $validatedData['is_flagged'] ?? false;
        $createInternalDeliveryOrderData->status = $validatedData['status'] ?? InternalDeliveryOrder::PENDING;
        $createInternalDeliveryOrderData->estimatedDeliveryDate = Carbon::parse($validatedData['estimated_delivery_date']);
        $createInternalDeliveryOrderData->remark = $validatedData['remark'] ?? null;

        $orderItems = [];

        foreach ($validatedData['order_items'] as $item) {
            $createInternalDeliverItem = new CreateInternalDeliveryItemData();
            $createInternalDeliverItem->productId = $item['product_id'] ?? null;
            $createInternalDeliverItem->productCode = $item['product_code'] ?? null;
            $createInternalDeliverItem->quantity = $item['quantity'];
            $createInternalDeliverItem->packagingSize = $item['packaging_size'];
            $createInternalDeliverItem->description = $item['description'];

            $orderItems[] = $createInternalDeliverItem;
        }

        $createInternalDeliveryOrderData->createInternalDeliveryItemData = $orderItems;

        return $createInternalDeliveryOrderData;
    }
}
