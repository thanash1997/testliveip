<?php

namespace App\Http\Requests\Order;

use App\Http\Requests\BaseFormRequest;
use Carbon\Carbon;
use Illuminate\Validation\Rule;
use IPI\Core\DTO\CreateInternalDeliveryItemData;
use IPI\Core\DTO\UpdateInternalDeliveryOrderData;
use IPI\Core\Entities\InternalDeliveryOrder;

class UpdateInternalDeliveryOrderRequest extends BaseFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        // TODO: Add permission validation
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'pic_id' => 'nullable|exists:users,id',
            'batch_no' => 'nullable|exists:orders,batch_no',
            'destination_id' => 'nullable|exists:inventories,id',
            'usage' => 'nullable|string',
            'description' => 'nullable|string',
            'flag_reason' => 'nullable|string',
            'origin' => 'nullable|string',
            'is_flagged' => 'nullable|boolean',
            'estimated_delivery_date' => 'nullable|date',
            'status' => ['nullable', Rule::in(InternalDeliveryOrder::ALL_STATUSES)],
            'remark' => 'nullable|string',
            'order_items' => 'nullable|array',
            'order_items.*.id' => 'nullable|exists:internal_delivery_items,id',
            'order_items.*.product_id' => 'required_without:order_items.*.product_code|exists:products,id',
            'order_items.*.product_code' => 'required_without:order_items.*.product_id|string',
            'order_items.*.quantity' => 'required|numeric',
            'order_items.*.packaging_size' => 'required|string',
            'order_items.*.description' => 'required|string',
        ];
    }

    public function toDTO(): UpdateInternalDeliveryOrderData
    {
        $validatedData = $this->validated();

        $createInternalDeliveryOrderData = new UpdateInternalDeliveryOrderData();
        $createInternalDeliveryOrderData->picId = $validatedData['pic_id'] ?? null;
        $createInternalDeliveryOrderData->batchNo = $validatedData['batch_no'] ?? null;
        $createInternalDeliveryOrderData->destinationId = $validatedData['destination_id'] ?? null;
        $createInternalDeliveryOrderData->usage = $validatedData['usage'] ?? null;
        $createInternalDeliveryOrderData->description = $validatedData['description'] ?? null;
        $createInternalDeliveryOrderData->status = $validatedData['status'] ?? null;
        $createInternalDeliveryOrderData->flagReason = $validatedData['flag_reason'] ?? null;
        $createInternalDeliveryOrderData->origin = $validatedData['origin'] ?? 'IPI Sdn Bhd';
        $createInternalDeliveryOrderData->isFlagged = $validatedData['is_flagged'] ?? null;
        $createInternalDeliveryOrderData->estimatedDeliveryDate = isset($validatedData['estimated_delivery_date']) ? Carbon::parse($validatedData['estimated_delivery_date']) : null;
        $createInternalDeliveryOrderData->remark = $validatedData['remark'] ?? null;

        $orderItems = [];

        foreach ($validatedData['order_items'] as $item) {
            $createInternalDeliverItem = new CreateInternalDeliveryItemData();
            $createInternalDeliverItem->id = $item['id'] ?? null;
            $createInternalDeliverItem->productId = $item['product_id'] ?? null;
            $createInternalDeliverItem->productCode = $item['product_code'] ?? null;
            $createInternalDeliverItem->quantity = $item['quantity'];
            $createInternalDeliverItem->packagingSize = $item['packaging_size'];
            $createInternalDeliverItem->description = $item['description'];

            $orderItems[] = $createInternalDeliverItem;
        }

        $createInternalDeliveryOrderData->createInternalDeliveryItemData = $orderItems;

        return $createInternalDeliveryOrderData;
    }
}
