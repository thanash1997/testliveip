<?php

namespace App\Http\Requests\Order;

use App\Http\Requests\BaseFormRequest;
use Carbon\Carbon;
use Illuminate\Validation\Rule;
use IPI\Core\DTO\CreateExternalDeliveryItemData;
use IPI\Core\DTO\CreateExternalDeliveryOrderData;
use IPI\Core\Entities\ExternalDeliveryOrder;

class CreateExternalDeliveryOrderRequest extends BaseFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'batch_no' => 'nullable|exists:orders,batch_no',
            'address_id' => 'required|exists:addresses,id',
            'customer_id' => 'required|exists:companies,id',
            'courier_name' => 'nullable|string',
            'vehicle_no' => 'nullable|string',
            'tracking_no' => 'nullable|string',
            'receipt_no' => 'nullable|string',
            'description' => 'nullable|string',
            'is_flagged' => 'nullable|boolean',
            'flag_reason' => 'nullable|string',
            'remark' => 'nullable|string',
            'estimated_delivery_date' => 'required|string',
            'status' => ['nullable', Rule::in(ExternalDeliveryOrder::ALL_STATUSES)],
            'order_items' => 'required|array',
            'order_items.*.product_id' => 'required|exists:products,id',
            'order_items.*.order_id' => 'nullable|exists:orders,id',
            'order_items.*.quantity' => 'required|numeric',
            'order_items.*.packaging_size' => 'required|string',
            'order_items.*.description' => 'required|string',
        ];
    }

    public function toDTO(): CreateExternalDeliveryOrderData
    {
        $validatedData = $this->validated();

        $createExternalDeliveryOrderData = new CreateExternalDeliveryOrderData();
        $createExternalDeliveryOrderData->batchNo = $validatedData['batch_no'] ?? null;
        $createExternalDeliveryOrderData->addressId = $validatedData['address_id'];
        $createExternalDeliveryOrderData->customerId = $validatedData['customer_id'];
        $createExternalDeliveryOrderData->courierName = $validatedData['courier_name'] ?? null;
        $createExternalDeliveryOrderData->vehicleNo = $validatedData['vehicle_no'] ?? null;
        $createExternalDeliveryOrderData->trackingNo = $validatedData['tracking_no'] ?? null;
        $createExternalDeliveryOrderData->receiptNo = $validatedData['receipt_no'] ?? null;
        $createExternalDeliveryOrderData->description = $validatedData['description'] ?? null;
        $createExternalDeliveryOrderData->isFlagged = $validatedData['is_flagged'] ?? false;
        $createExternalDeliveryOrderData->flagReason = $validatedData['flag_reason'] ?? null;
        $createExternalDeliveryOrderData->estimatedDeliveryDate = Carbon::parse($validatedData['estimated_delivery_date']);
        $createExternalDeliveryOrderData->remark = $validatedData['remark'] ?? null;
        $createExternalDeliveryOrderData->status = $validatedData['status'] ?? ExternalDeliveryOrder::STATUS_PENDING;

        $orderItems = [];

        foreach ($validatedData['order_items'] as $item) {
            $createExternalDeliverItem = new CreateExternalDeliveryItemData();
            $createExternalDeliverItem->productId = $item['product_id'];
            $createExternalDeliverItem->orderId = $item['order_id'] ?? null;
            $createExternalDeliverItem->quantity = $item['quantity'];
            $createExternalDeliverItem->packagingSize = $item['packaging_size'];
            $createExternalDeliverItem->description = $item['description'];

            $orderItems[] = $createExternalDeliverItem;
        }

        $createExternalDeliveryOrderData->createExternalDeliverOrderItemData = $orderItems;

        return $createExternalDeliveryOrderData;
    }
}
