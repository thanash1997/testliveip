<?php

namespace App\Http\Requests\Order;

use App\Http\Requests\BaseFormRequest;
use Carbon\Carbon;
use Illuminate\Validation\Rule;
use IPI\Core\DTO\CreateOrderItemData;
use IPI\Core\DTO\UpdateOrderData;
use IPI\Core\DTO\UpdateProductionMaterialData;
use IPI\Core\Entities\Order;

class UpdateOrderRequest extends BaseFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'pic_id' => 'nullable|exists:users,id',
            'customer_id' => 'nullable|exists:companies,id',
            'shipment_id' => 'nullable|exists:addresses,id',
            'contact_person_id' => 'nullable|exists:users,id',
            'description' => 'nullable|string',
            'status' => ['nullable', Rule::in(Order::ALL_STATUSES)],
            'total_cost' => 'nullable|int',
            'estimated_delivered_at' => 'nullable|date',
            'files' => 'nullable|array',
            'order_items' => 'nullable|array',
            'order_items.*.product_id' => 'required|exists:products,id',
            'order_items.*.quantity' => 'required|numeric',
            'order_items.*.total_cost' => 'required|numeric',
            'production_materials' => 'nullable|array',
            'production_materials.*.id' => 'required|exists:production_materials,id',
            'production_materials.*.productId' => 'required|exists:products,id',
            'production_materials.*.quantity' => 'required|numeric',
        ];
    }

    public function toDTO(): UpdateOrderData
    {
        $validatedData = $this->validated();
        $createOrderData = new UpdateOrderData();
        $createOrderData->description = $validatedData['description'] ?? null;
        $createOrderData->picId = $validatedData['pic_id'] ?? null;
        $createOrderData->customerId = $validatedData['customer_id'] ?? null;
        $createOrderData->shipmentId = $validatedData['shipment_id'] ?? null;
        $createOrderData->contactPersonId = $validatedData['contact_person_id'] ?? null;
        $createOrderData->estimatedDeliveredAt = isset($validatedData['estimated_delivered_at']) ? Carbon::parse(
            $validatedData['estimated_delivered_at']
        ) : null;
        $createOrderData->totalCost = $validatedData['total_cost'] ?? null;
        $createOrderData->status = $validatedData['status'] ?? null;
        $createOrderData->files = $validatedData['files'] ?? null;

        $orderItems = [];

        foreach ($validatedData['order_items'] as $order_item) {
            $createOrderItemData = new CreateOrderItemData();
            $createOrderItemData->quantity = $order_item['quantity'];
            $createOrderItemData->productId = $order_item['product_id'];
            $createOrderItemData->totalCost = $order_item['total_cost'];

            $orderItems[] = $createOrderItemData;
        }

        $createOrderData->createOrderItems = $orderItems;

        if (!empty($validatedData['production_materials'])) {
            $productionMaterials = [];

            foreach ($validatedData['production_materials'] as $productionMaterial) {
                $productionMaterialData = new UpdateProductionMaterialData();
                $productionMaterialData->id = $productionMaterial['id'];
                $productionMaterialData->productId = $productionMaterial['productId'];
                $productionMaterialData->quantity = $productionMaterial['quantity'];

                $productionMaterials[] = $productionMaterialData;
            }
            $createOrderData->updateProductionMaterialData = $productionMaterials;
        }

        return $createOrderData;
    }
}
