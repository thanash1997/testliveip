<?php

namespace App\Http\Requests\Order;

use App\Http\Requests\BaseFormRequest;
use Carbon\Carbon;
use IPI\Core\DTO\CreateOrderData;
use IPI\Core\DTO\CreateOrderItemData;

class CreateOrderRequest extends BaseFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        // TODO: Add permission check
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'with_approval' => 'nullable|boolean',
            'pic_id' => 'required|exists:users,id',
            'customer_id' => 'required|exists:companies,id',
            'shipment_id' => 'required|exists:addresses,id',
            'contact_person_id' => 'required|exists:users,id',
            'description' => 'nullable|string',
            'total_cost' => 'required|int',
            'estimated_delivered_at' => 'required|date',
            'files' => 'nullable|array',
            'order_items' => 'required|array',
            'order_items.*.product_id' => 'required|exists:products,id',
            'order_items.*.quantity' => 'required|numeric',
            'order_items.*.total_cost' => 'required|numeric',
        ];
    }

    public function toDTO(): CreateOrderData
    {
        $validatedData = $this->validated();
        $createOrderData = new CreateOrderData();
        $createOrderData->withApproval = $validatedData['with_approval'] ?? false;
        $createOrderData->description = $validatedData['description'] ?? null;
        $createOrderData->picId = $validatedData['pic_id'];
        $createOrderData->customerId = $validatedData['customer_id'];
        $createOrderData->shipmentId = $validatedData['shipment_id'];
        $createOrderData->contactPersonId = $validatedData['contact_person_id'];
        $createOrderData->estimatedDeliveredAt = Carbon::parse($validatedData['estimated_delivered_at']);
        $createOrderData->totalCost = $validatedData['total_cost'];
        $createOrderData->files = $validatedData['files'] ?? [];

        $orderItems = [];

        foreach ($validatedData['order_items'] as $order_item) {
            $createOrderItemData = new CreateOrderItemData();
            $createOrderItemData->quantity = $order_item['quantity'];
            $createOrderItemData->productId = $order_item['product_id'];
            $createOrderItemData->totalCost = $order_item['total_cost'];

            $orderItems[] = $createOrderItemData;
        }

        $createOrderData->createOrderItems = $orderItems;

        return $createOrderData;
    }
}
