<?php

namespace App\Http\Requests\Order;

use App\Http\Requests\BaseFormRequest;
use Carbon\Carbon;
use Illuminate\Validation\Rule;
use IPI\Core\DTO\CreateExternalDeliveryItemData;
use IPI\Core\DTO\UpdateExternalDeliveryOrderData;
use IPI\Core\Entities\ExternalDeliveryOrder;

class UpdateExternalDeliveryOrderRequest extends BaseFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'batch_no' => 'nullable|exists:orders,batch_no',
            'address_id' => 'nullable|exists:addresses,id',
            'customer_id' => 'nullable|exists:companies,id',
            'courier_name' => 'nullable|string',
            'vehicle_no' => 'nullable|string',
            'tracking_no' => 'nullable|string',
            'receipt_no' => 'nullable|string',
            'description' => 'nullable|string',
            'is_flagged' => 'nullable|boolean',
            'flag_reason' => 'nullable|string',
            'remark' => 'nullable|string',
            'estimated_delivery_date' => 'nullable|date',
            'status' => ['nullable', Rule::in(ExternalDeliveryOrder::ALL_STATUSES)],
            'order_items' => 'nullable|array',
            'order_items.*.id' => 'nullable|exists:external_delivery_items,id',
            'order_items.*.product_id' => 'required|exists:products,id',
            'order_items.*.order_id' => 'nullable|exists:orders,id',
            'order_items.*.quantity' => 'required|numeric',
            'order_items.*.packaging_size' => 'required|string',
            'order_items.*.description' => 'required|string',
        ];
    }

    public function toDTO(): UpdateExternalDeliveryOrderData
    {
        $validatedData = $this->validated();

        $updateExternalDeliveryOrderData = new UpdateExternalDeliveryOrderData();
        $updateExternalDeliveryOrderData->batchNo = $validatedData['batch_no'] ?? null;
        $updateExternalDeliveryOrderData->addressId = $validatedData['address_id'] ?? null;
        $updateExternalDeliveryOrderData->customerId = $validatedData['customer_id'] ?? null;
        $updateExternalDeliveryOrderData->courierName = $validatedData['courier_name'] ?? null;
        $updateExternalDeliveryOrderData->vehicleNo = $validatedData['vehicle_no'] ?? null;
        $updateExternalDeliveryOrderData->trackingNo = $validatedData['tracking_no'] ?? null;
        $updateExternalDeliveryOrderData->receiptNo = $validatedData['receipt_no'] ?? null;
        $updateExternalDeliveryOrderData->description = $validatedData['description'] ?? null;
        $updateExternalDeliveryOrderData->isFlagged = isset($validatedData['is_flagged']) ? $validatedData['is_flagged'] : null;
        $updateExternalDeliveryOrderData->flagReason = $validatedData['flag_reason'] ?? null;
        $updateExternalDeliveryOrderData->estimatedDeliveryDate = isset($validatedData['estimated_delivery_date']) ? Carbon::parse($validatedData['estimated_delivery_date']) : null;
        $updateExternalDeliveryOrderData->remark = $validatedData['remark'] ?? null;
        $updateExternalDeliveryOrderData->status = $validatedData['status'] ?? null;

        $orderItems = [];

        foreach ($validatedData['order_items'] as $item) {
            $createExternalDeliverItem = new CreateExternalDeliveryItemData();
            $createExternalDeliverItem->id = $item['id'] ?? null;
            $createExternalDeliverItem->productId = $item['product_id'];
            $createExternalDeliverItem->orderId = $item['order_id'] ?? null;
            $createExternalDeliverItem->quantity = $item['quantity'];
            $createExternalDeliverItem->packagingSize = $item['packaging_size'];
            $createExternalDeliverItem->description = $item['description'];

            $orderItems[] = $createExternalDeliverItem;
        }

        $updateExternalDeliveryOrderData->createExternalDeliverOrderItemData = $orderItems;

        return $updateExternalDeliveryOrderData;
    }
}
