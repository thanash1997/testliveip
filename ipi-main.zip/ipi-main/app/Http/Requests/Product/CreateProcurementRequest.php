<?php

namespace App\Http\Requests\Product;

use App\Http\Requests\BaseFormRequest;
use Carbon\Carbon;
use Illuminate\Validation\Rule;
use IPI\Core\DTO\CreateProcurementData;
use IPI\Core\DTO\CreateProcurementItemData;
use IPI\Core\Entities\Procurement;

class CreateProcurementRequest extends BaseFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        // TODO: Add permission checks
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'supplier_id' => 'required|exists:companies,id',
            'destination_id' => 'required|exists:inventories,id',
            'expected_receive_date' => 'required|date',
            'usage' => 'required|string',
            'po_number' => 'required|string|unique:purchase_orders,po_number',
            'is_flagged' => 'nullable|boolean',
            'flag_reason' => 'nullable|required_if:is_flagged,true|string',
            'total_cost' => 'required|numeric',
            'status' => ['nullable', Rule::in(Procurement::ALL_STATUSES)],
            'remark' => 'nullable|string',
            'items' => 'required|array',
            'items.*.product_id' => 'required_without:items.*.product_code|exists:products,id',
            'items.*.product_code' => 'required_without:items.*.product_id|string',
            'items.*.quantity' => 'required|numeric',
            'items.*.packaging_size' => 'required|string',
            'items.*.description' => 'required|string',
            'items.*.total_cost' => 'required|numeric',
            'items.*.unit_cost' => 'required|numeric',
        ];
    }

    public function toDTO(): CreateProcurementData
    {
        $validatedData = $this->validated();
        $createProcurementData = new CreateProcurementData();
        $createProcurementData->supplierId = $validatedData['supplier_id'];
        $createProcurementData->destinationId = $validatedData['destination_id'];
        $createProcurementData->expectedReceiveDate = Carbon::parse($validatedData['expected_receive_date']);
        $createProcurementData->usage = $validatedData['usage'];
        $createProcurementData->poNumber = $validatedData['po_number'];
        $createProcurementData->isFlagged = $validatedData['is_flagged'] ?? false;
        $createProcurementData->flagReason = $validatedData['flag_reason'] ?? null;
        $createProcurementData->totalCost = $validatedData['total_cost'];
        $createProcurementData->status = $validatedData['status'] ?? Procurement::PENDING;
        $createProcurementData->remark = $validatedData['remark'] ?? null;

        $validatedItems = $validatedData['items'];
        $createProcurementItemsData = [];
        foreach ($validatedItems as $validatedItem) {
            $createProcurementItemData = new CreateProcurementItemData();
            $createProcurementItemData->productId = $validatedItem['product_id'] ?? null;
            $createProcurementItemData->productCode = $validatedItem['product_code'] ?? null;
            $createProcurementItemData->quantity = $validatedItem['quantity'];
            $createProcurementItemData->packagingSize = $validatedItem['packaging_size'];
            $createProcurementItemData->description = $validatedItem['description'];
            $createProcurementItemData->totalCost = $validatedItem['total_cost'];
            $createProcurementItemData->unitCost = $validatedItem['unit_cost'];

            array_push($createProcurementItemsData, $createProcurementItemData);
        }

        $createProcurementData->purchaseOrderItems = $createProcurementItemsData;

        return $createProcurementData;
    }
}
