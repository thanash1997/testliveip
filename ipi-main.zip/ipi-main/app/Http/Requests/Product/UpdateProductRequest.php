<?php

namespace App\Http\Requests\Product;

use App\Http\Requests\BaseFormRequest;
use IPI\Core\DTO\UpdateProductData;

class UpdateProductRequest extends BaseFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'requester_customer_id' => 'nullable|exists:companies,id',
            'product_tag_id' => 'nullable|exists:product_tags,id',
            'product_code' => 'nullable|string|unique:products,product_code',
            'description' => 'nullable|string',
            'product_name' => 'nullable|string',
            'quantity' => 'nullable|numeric',
            'unit_cost' => 'nullable|integer',
            'threshold' => 'nullable|integer',
            'type_code' => 'nullable|string',
            'packaging_size' => 'nullable|string',
        ];
    }

    public function toDTO(): UpdateProductData
    {
        $validatedData = $this->validated();
        $updateProductData = new UpdateProductData();
        $updateProductData->requesterCustomerId = $validatedData['requester_customer_id'] ?? null;
        $updateProductData->productTagId = $validatedData['product_tag_id'] ?? null;
        $updateProductData->productCode = $validatedData['product_code'] ?? null;
        $updateProductData->description = $validatedData['description'] ?? null;
        $updateProductData->name = $validatedData['product_name'] ?? null;
        $updateProductData->quantity = $validatedData['quantity'] ?? null;
        $updateProductData->unitCost = $validatedData['unit_cost'] ?? null;
        $updateProductData->threshold = $validatedData['threshold'] ?? null;
        $updateProductData->typeCode = $validatedData['type_code'] ?? null;
        $updateProductData->packagingSize = $validatedData['packaging_size'] ?? null;

        return $updateProductData;
    }
}
