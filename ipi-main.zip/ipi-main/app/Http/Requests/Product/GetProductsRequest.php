<?php

namespace App\Http\Requests\Product;

use App\Http\Requests\BaseFormRequest;
use Carbon\Carbon;
use IPI\Core\DTO\IndexFilter;

class GetProductsRequest extends BaseFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        // TODO: Add permission checks
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'per_page' => 'nullable|integer',
            'search_query' => 'nullable|string',
            'type' => 'nullable|string',
            'sort_order' => 'nullable|in:desc,asc',
            'date_range' => 'nullable|array',
            'date_range.*' => 'required|date',
        ];
    }

    public function toDTO(): IndexFilter
    {
        $validatedData = $this->validated();

        $indexFilter = new IndexFilter();
        $indexFilter->searchQuery = $validatedData['search_query'] ?? null;
        $indexFilter->type = $validatedData['type'] ?? null;
        $indexFilter->perPage = isset($validatedData['per_page']) ? (int)$validatedData['per_page'] : 20;
        $indexFilter->sortOrder = $validatedData['sort_order'] ?? 'asc';
        $indexFilter->startDate = isset($validatedData['date_range']) ? Carbon::parse($validatedData['date_range'][0]) : null;
        $indexFilter->endDate = isset($validatedData['date_range']) ? Carbon::parse($validatedData['date_range'][1]) : null;
        $indexFilter->relationships = ['requesterCustomer', 'inventories', 'productTags'];

        return $indexFilter;
    }
}
