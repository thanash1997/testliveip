<?php

namespace App\Http\Requests\Product;

use App\Http\Requests\BaseFormRequest;
use Illuminate\Validation\Rule;
use IPI\Core\DTO\CreateProductRequisitionItemData;
use IPI\Core\DTO\UpdateProductRequisitionData;
use IPI\Core\Entities\ProductRequisition;

class UpdateProductRequisitionRequest extends BaseFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'destination_id' => 'nullable|exists:inventories,id',
            'usage' => 'nullable|string',
            'is_flagged' => 'nullable|boolean',
            'flag_reason' => 'nullable|required_if:is_flagged,true|string',
            'status' => ['nullable', Rule::in(ProductRequisition::ALL_STATUSES)],
            'remark' => 'nullable|string',
            'items' => 'nullable|array',
            'items.*.id' => 'nullable|exists:product_requisition_items,id',
            'items.*.product_id' => 'required_without:items.*.product_code|exists:products,id',
            'items.*.product_code' => 'required_without:items.*.product_id|string',
            'items.*.quantity' => 'required|numeric',
            'items.*.packaging_size' => 'required|string',
            'items.*.description' => 'required|string',
        ];
    }

    public function toDTO(): UpdateProductRequisitionData
    {
        $validatedData = $this->validated();
        $updateProductRequisitionData = new UpdateProductRequisitionData();
        $updateProductRequisitionData->status = $validatedData['status'] ?? null;
        $updateProductRequisitionData->destinationId = $validatedData['destination_id'] ?? null;
        $updateProductRequisitionData->usage = $validatedData['usage'] ?? null;
        $updateProductRequisitionData->isFlagged = $validatedData['is_flagged'] ?? null;
        $updateProductRequisitionData->flagReason = $validatedData['flag_reason'] ?? null;
        $updateProductRequisitionData->remark = $validatedData['remark'] ?? null;

        $validatedItems = $validatedData['items'];
        $createProductRequisitionItemsData = [];
        foreach ($validatedItems as $validatedItem) {
            $createProductRequisitionItemData = new CreateProductRequisitionItemData();
            $createProductRequisitionItemData->id = $validatedItem['id'] ?? null;
            $createProductRequisitionItemData->productId = $validatedItem['product_id'] ?? null;
            $createProductRequisitionItemData->productCode = $validatedItem['product_code'] ?? null;
            $createProductRequisitionItemData->quantity = $validatedItem['quantity'];
            $createProductRequisitionItemData->packagingSize = $validatedItem['packaging_size'];
            $createProductRequisitionItemData->description = $validatedItem['description'];

            array_push($createProductRequisitionItemsData, $createProductRequisitionItemData);
        }

        $updateProductRequisitionData->createProductRequisitionItemData = $createProductRequisitionItemsData;

        return $updateProductRequisitionData;
    }
}
