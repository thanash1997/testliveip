<?php

namespace App\Http\Requests\Product;

use App\Http\Requests\BaseFormRequest;
use Carbon\Carbon;
use Illuminate\Validation\Rule;
use IPI\Core\DTO\CreateProcurementItemData;
use IPI\Core\DTO\UpdateProcurementData;
use IPI\Core\Entities\Procurement;

class UpdateProcurementRequest extends BaseFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        // TODO: Add permission checks
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'supplier_id' => 'nullable|exists:companies,id',
            'destination_id' => 'nullable|exists:inventories,id',
            'expected_receive_date' => 'nullable|date',
            'usage' => 'nullable|string',
            'po_number' => 'nullable|string',
            'is_flagged' => 'nullable|boolean',
            'flag_reason' => 'nullable|required_if:is_flagged,true|string',
            'total_cost' => 'nullable|integer',
            'status' => ['nullable', Rule::in(Procurement::ALL_STATUSES)],
            'remark' => 'nullable|string',
            'items' => 'nullable|array',
            'items.*.product_id' => 'required_without:items.*.product_code|exists:products,id',
            'items.*.product_code' => 'required_without:items.*.product_id|string',
            'items.*.quantity' => 'required|numeric',
            'items.*.packaging_size' => 'required|string',
            'items.*.description' => 'required|string',
            'items.*.total_cost' => 'required|integer',
            'items.*.unit_cost' => 'required|integer',
        ];
    }

    public function toDTO(): UpdateProcurementData
    {
        $validatedData = $this->validated();
        $createProcurementData = new UpdateProcurementData();
        $createProcurementData->supplierId = $validatedData['supplier_id'] ?? null;
        $createProcurementData->destinationId = $validatedData['destination_id'] ?? null;
        $createProcurementData->expectedReceiveDate = isset($validatedData['expected_receive_date']) ? Carbon::parse($validatedData['expected_receive_date']) : null;
        $createProcurementData->usage = $validatedData['usage'] ?? null;
        $createProcurementData->poNumber = $validatedData['po_number'] ?? null;
        $createProcurementData->isFlagged = $validatedData['is_flagged'] ?? null;
        $createProcurementData->flagReason = $validatedData['flag_reason'] ?? null;
        $createProcurementData->totalCost = $validatedData['total_cost'] ?? null;
        $createProcurementData->status = $validatedData['status'] ?? null;
        $createProcurementData->remark = $validatedData['remark'] ?? null;

        $validatedItems = $validatedData['items'];
        $createProcurementItemsData = [];
        foreach ($validatedItems as $validatedItem) {
            $createProcurementItemData = new CreateProcurementItemData();
            $createProcurementItemData->productId = $validatedItem['product_id'] ?? null;
            $createProcurementItemData->productCode = $validatedItem['product_code'] ?? null;
            $createProcurementItemData->quantity = $validatedItem['quantity'];
            $createProcurementItemData->packagingSize = $validatedItem['packaging_size'];
            $createProcurementItemData->description = $validatedItem['description'];
            $createProcurementItemData->totalCost = $validatedItem['total_cost'];
            $createProcurementItemData->unitCost = $validatedItem['unit_cost'];

            array_push($createProcurementItemsData, $createProcurementItemData);
        }

        $createProcurementData->purchaseOrderItems = $createProcurementItemsData;

        return $createProcurementData;
    }
}
