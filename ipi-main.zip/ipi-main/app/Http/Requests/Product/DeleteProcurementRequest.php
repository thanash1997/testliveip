<?php

namespace App\Http\Requests\Product;

use App\Models\Product;
use App\Models\PurchaseOrder;
use Illuminate\Foundation\Http\FormRequest;
use IPI\Core\DTO\DeleteResourcesData;

class DeleteProcurementRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'procurement_ids' => 'required|array',
            'procurement_ids.*' => 'exists:purchase_orders,uuid'
        ];
    }


    public function toDTO(): DeleteResourcesData
    {
        $validatedData = $this->validated();
        $deleteResourceData = new DeleteResourcesData();
        $deleteResourceData->table = 'purchase_orders';
        $deleteResourceData->resource = PurchaseOrder::class;
        $deleteResourceData->ids = $validatedData['procurement_ids'];

        return $deleteResourceData;
    }
}
