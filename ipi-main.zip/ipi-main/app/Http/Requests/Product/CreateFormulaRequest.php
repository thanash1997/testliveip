<?php

namespace App\Http\Requests\Product;

use App\Http\Requests\BaseFormRequest;
use App\Models\Checkpoint;
use App\Models\User;
use Illuminate\Validation\Rule;
use IPI\Core\DTO\CreateFormulaCheckpointData;
use IPI\Core\DTO\CreateFormulaData;
use IPI\Core\DTO\CreateIngredientItemData;
use IPI\Core\DTO\CreateIngredientListsData;
use IPI\Core\Entities\Product;

class CreateFormulaRequest extends BaseFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return auth()->user()->hasPermissionTo(User::CREATE_FORMULA_PERMISSION);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'requester_customer_id' => 'nullable|exists:companies,id',
            'engineer_id' => 'required|exists:users,id',
            'formula_type_id' => 'required|exists:formula_types,id',
            'formula_tag_id' => 'required|exists:formula_tags,id',
            'product_name' => 'required|string',
            'remark' => 'nullable|string',
            'type' => ['required', Rule::in([Product::TYPE_FORMULA_SAMPLE, Product::TYPE_FORMULA])],
            'ingredient_lists' => 'required|array',
            'ingredient_lists.*.remark' => 'nullable|string',
            'ingredient_lists.*.items' => 'required|array',
            'ingredient_lists.*.items.*.product_id' => 'required_without:ingredient_lists.*.items.*.product_code|exists:products,id',
            'ingredient_lists.*.items.*.product_code' => 'required_without:ingredient_lists.*.items.*.product_id|string',
            'ingredient_lists.*.items.*.remark' => 'nullable|string',
            'ingredient_lists.*.items.*.total_cost' => 'required|numeric',
            'ingredient_lists.*.items.*.percentage' => 'required|numeric',
            'checkpoints' => 'nullable|array',
            'checkpoints.*.type' => ['required', Rule::in(Checkpoint::ALL_TYPES)],
            'checkpoints.*.range_min' => 'nullable|string',
            'checkpoints.*.range_max' => 'nullable|string',
            'checkpoints.*.tolerance_min' => 'nullable|string',
            'checkpoints.*.tolerance_max' => 'nullable|string',
            'checkpoints.*.equipment' => 'nullable|string',
            'checkpoints.*.remark' => 'nullable|string',
        ];
    }

    public function toDTO(): CreateFormulaData
    {
        $validateData = $this->validated();
        $createFormulaData = new CreateFormulaData();
        $createFormulaData->requesterCustomerId = $validateData['requester_customer_id'] ?? null;
        $createFormulaData->engineerId = $validateData['engineer_id'];
        $createFormulaData->formulaTagId = $validateData['formula_tag_id'];
        $createFormulaData->formulaTypeId = $validateData['formula_type_id'];
        $createFormulaData->productName = $validateData['product_name'];
        $createFormulaData->remark = $validateData['remark'] ?? null;
        $createFormulaData->type = $validateData['type'];

        $ingredientLists = [];
        foreach ($validateData['ingredient_lists'] as $ingredientList) {
            $createIngredientListData = new CreateIngredientListsData();
            $createIngredientListData->remark = $ingredientList['remark'] ?? null;
            $ingredientListItems = [];

            foreach ($ingredientList['items'] as $item) {
                $createIngredientItemData = new CreateIngredientItemData();
                $createIngredientItemData->totalCost = $item['total_cost'];
                $createIngredientItemData->percentage = $item['percentage'];
                $createIngredientItemData->remark = $item['remark'] ?? null;
                $createIngredientItemData->productId = $item['product_id'] ?? null;
                $createIngredientItemData->productCode = $item['product_code'] ?? null;

                $ingredientListItems[] = $createIngredientItemData;
            }

            $createIngredientListData->createIngredientItems = $ingredientListItems;
            $ingredientLists[] = $createIngredientListData;
        }

        $checkpoints = [];
        foreach ($validateData['checkpoints'] as $checkpoint) {
            $checkpointData = new CreateFormulaCheckpointData();
            $checkpointData->type = $checkpoint['type'];
            $checkpointData->rangeMin = $checkpoint['range_min'] ?? null;
            $checkpointData->rangeMax = $checkpoint['range_max'] ?? null;
            $checkpointData->toleranceMin = $checkpoint['tolerance_min'] ?? null;
            $checkpointData->toleranceMax = $checkpoint['tolerance_max'] ?? null;
            $checkpointData->equipment = $checkpoint['equipment'] ?? null;
            $checkpointData->remark = $checkpoint['remark'] ?? null;

            $checkpoints[] = $checkpointData;
        }

        $createFormulaData->checkpoints = $checkpoints;
        $createFormulaData->ingredientLists = $ingredientLists;

        return $createFormulaData;
    }
}
