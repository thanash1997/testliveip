<?php

namespace App\Http\Requests\Product;

use App\Http\Requests\BaseFormRequest;
use Illuminate\Validation\Rule;
use IPI\Core\DTO\CreateProductData;
use IPI\Core\Entities\Product;

class CreateProductRequest extends BaseFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        // TODO: Add permission checks
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'requester_customer_id' => 'nullable|exists:companies,id',
            'product_tag_id' => 'required|exists:product_tags,id',
            'product_code' => 'required|string|unique:products,product_code',
            'description' => 'required|string',
            'quantity' => 'required|numeric',
            'unit_cost' => 'required|integer',
            'threshold' => 'required|integer',
            'type_code' => 'nullable|string',
            'packaging_size' => 'nullable|string',
            'type' => ['required', Rule::in(Product::ALL_TYPES)]
        ];
    }

    public function toDTO(): CreateProductData
    {
        $validatedData = $this->validated();
        $createProductData = new CreateProductData();
        $createProductData->requesterCustomerId = $validatedData['requester_customer_id'] ?? null;
        $createProductData->productTagId = $validatedData['product_tag_id'];
        $createProductData->productCode = $validatedData['product_code'];
        $createProductData->description = $validatedData['description'];
        $createProductData->quantity = $validatedData['quantity'];
        $createProductData->unitCost = $validatedData['unit_cost'];
        $createProductData->threshold = $validatedData['threshold'];
        $createProductData->typeCode = $validatedData['type_code'] ?? null;
        $createProductData->packagingSize = $validatedData['packaging_size'] ?? null;

        return $createProductData;
    }
}
