<?php

namespace App\Http\Requests\Product;

use App\Http\Requests\BaseFormRequest;
use Illuminate\Support\Facades\DB;
use IPI\Core\DTO\CreateFormulaTypeData;

class CreateFormulaTypeRequest extends BaseFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        // TODO: Add permission checks
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => ['required', function ($attribute, $value, $fail) {
                if (DB::table('formula_types')->where('type', strtoupper($value))->exists()) {
                    $fail('The ' . $attribute . ' is invalid.');
                }
            }]
        ];
    }

    public function toDTO(): CreateFormulaTypeData
    {
        $validatedData = $this->validated();
        $data = new CreateFormulaTypeData();
        $data->name = $validatedData['name'];

        return $data;
    }
}
