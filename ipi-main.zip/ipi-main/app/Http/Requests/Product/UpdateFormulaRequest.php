<?php

namespace App\Http\Requests\Product;

use App\Http\Requests\BaseFormRequest;
use App\Models\Checkpoint;
use App\Models\User;
use Illuminate\Validation\Rule;
use IPI\Core\DTO\CreateFormulaCheckpointData;
use IPI\Core\DTO\CreateIngredientItemData;
use IPI\Core\DTO\CreateIngredientListsData;
use IPI\Core\DTO\UpdateFormulaData;

class UpdateFormulaRequest extends BaseFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return auth()->user()->hasPermissionTo(User::UPDATE_FORMULA_PERMISSION);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'requester_customer_id' => 'nullable|exists:companies,id',
            'engineer_id' => 'nullable|exists:users,id',
            'formula_type_id' => 'nullable|exists:formula_types,id',
            'formula_tag_id' => 'nullable|exists:formula_tags,id',
            'product_name' => 'nullable|string',
            'remark' => 'nullable|string',
            'ingredient_lists' => 'nullable|array',
            'ingredient_lists.*.id' => 'required|exists:ingredient_lists,id',
            'ingredient_lists.*.remark' => 'nullable|string',
            'ingredient_lists.*.items' => 'required|array',
            'ingredient_lists.*.items.*.id' => 'required|exists:ingredient_list_items,id',
            'ingredient_lists.*.items.*.product_id' => 'required_without:ingredient_lists.*.items.*.product_code|exists:products,id',
            'ingredient_lists.*.items.*.product_code' => 'required_without:ingredient_lists.*.items.*.product_id|string',
            'ingredient_lists.*.items.*.remark' => 'nullable|string',
            'ingredient_lists.*.items.*.total_cost' => 'required|numeric',
            'ingredient_lists.*.items.*.percentage' => 'required|numeric',
            'checkpoints' => 'nullable|array',
            'checkpoints.*.type' => ['required', Rule::in(Checkpoint::ALL_TYPES)],
            'checkpoints.*.range_min' => 'nullable|string',
            'checkpoints.*.range_max' => 'nullable|string',
            'checkpoints.*.tolerance_min' => 'nullable|string',
            'checkpoints.*.tolerance_max' => 'nullable|string',
            'checkpoints.*.equipment' => 'nullable|string',
            'checkpoints.*.remark' => 'nullable|string',
        ];
    }

    public function toDTO(): UpdateFormulaData
    {
        $validateData = $this->validated();
        $updateFormulaData = new UpdateFormulaData();
        $updateFormulaData->requesterCustomerId = $validateData['requester_customer_id'] ?? null;
        $updateFormulaData->engineerId = $validateData['engineer_id'] ?? null;
        $updateFormulaData->formulaTagId = $validateData['formula_tag_id'] ?? null;
        $updateFormulaData->formulaTypeId = $validateData['formula_type_id'] ?? null;
        $updateFormulaData->productName = $validateData['product_name'] ?? null;
        $updateFormulaData->remark = $validateData['remark'] ?? null;

        $ingredientLists = [];
        foreach ($validateData['ingredient_lists'] as $ingredientList) {
            $createIngredientListData = new CreateIngredientListsData();
            $createIngredientListData->id = $ingredientList['id'];
            $createIngredientListData->remark = $ingredientList['remark'] ?? null;
            $ingredientListItems = [];

            foreach ($ingredientList['items'] as $item) {
                $createIngredientItemData = new CreateIngredientItemData();
                $createIngredientItemData->id = $item['id'];
                $createIngredientItemData->totalCost = $item['total_cost'];
                $createIngredientItemData->percentage = $item['percentage'];
                $createIngredientItemData->remark = $item['remark'] ?? null;
                $createIngredientItemData->productId = $item['product_id'] ?? null;
                $createIngredientItemData->productCode = $item['product_code'] ?? null;

                $ingredientListItems[] = $createIngredientItemData;
            }

            $createIngredientListData->createIngredientItems = $ingredientListItems;
            $ingredientLists[] = $createIngredientListData;
        }

        $updateFormulaData->ingredientLists = $ingredientLists;

        $checkpoints = [];
        foreach ($validateData['checkpoints'] as $checkpoint) {
            $checkpointData = new CreateFormulaCheckpointData();
            $checkpointData->type = $checkpoint['type'];
            $checkpointData->rangeMin = $checkpoint['range_min'] ?? null;
            $checkpointData->rangeMax = $checkpoint['range_max'] ?? null;
            $checkpointData->toleranceMin = $checkpoint['tolerance_min'] ?? null;
            $checkpointData->toleranceMax = $checkpoint['tolerance_max'] ?? null;
            $checkpointData->equipment = $checkpoint['equipment'] ?? null;
            $checkpointData->remark = $checkpoint['remark'] ?? null;

            $checkpoints[] = $checkpointData;
        }

        $updateFormulaData->checkpoints = $checkpoints;

        return $updateFormulaData;
    }
}
