<?php

namespace App\Http\Requests\Company;

use App\Models\Company;
use App\Models\User;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Validation\Rule;

class CreateCompanyRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        return auth()->user()->hasPermissionTo(User::CREATE_CUSTOMER_PERMISSION);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => ['required', 'string'],
            'registration_number' => ['required', 'string'],
            'website_url' => ['nullable', 'string'],
            'sst_number' => ['nullable', 'string'],
            'gst_number' => ['nullable', 'string'],
            'type' => ['required', Rule::in(Company::ALL_TYPES)],
            'phone_dialing_code_id' => ['required', 'exists:dialing_codes,id'],
            'phone_number' => ['required', 'string'],
            'fax_dialing_code_id' => ['nullable', 'exists:dialing_codes,id'],
            'fax_number' => ['nullable', 'string'],
            'address' => ['required', 'array'],
            'address.line_1' => ['required', 'string'],
            'address.line_2' => ['nullable', 'string'],
            'address.postcode' => ['required', 'string'],
            'address.city' => ['required', 'string'],
            'address.state' => ['required', 'string'],
            'address.country_id' => ['required', 'exists:countries,id'],
            'employees' => ['required', 'array'],
            'employees.*.name' => ['required', 'string'],
            'employees.*.email' => ['required', 'string'],
            'employees.*.designation' => ['nullable', 'string'],
            'employees.*.phone_dialing_code_id' => ['required', 'exists:dialing_codes,id'],
            'employees.*.phone_number' => ['required', 'string'],
            'employees.*.fax_dialing_code_id' => ['nullable', 'exists:dialing_codes,id'],
            'payment_accounts' => ['required', 'array'],
            'payment_accounts.*.name' => ['required', 'string'],
            'payment_accounts.*.email' => ['required', 'string'],
            'payment_accounts.*.account_holder_name' => ['required', 'string'],
            'payment_accounts.*.account_number' => ['required', 'string'],
            'payment_accounts.*.bank_id' => ['required', 'exists:banks,id'],
            'payment_accounts.*.payment_method_id' => ['nullable', 'exists:payment_methods,id'],
            'payment_accounts.*.phone_dialing_code_id' => ['required', 'exists:dialing_codes,id'],
            'payment_accounts.*.phone_number' => ['required', 'string'],
            'payment_accounts.*.fax_dialing_code_id' => ['nullable', 'exists:dialing_codes,id'],
            'payment_accounts.*.fax_number' => ['nullable', 'string'],
            'payment_accounts.*.address' => ['required', 'array'],
            'payment_accounts.*.address.line_1' => ['required', 'string'],
            'payment_accounts.*.address.line_2' => ['nullable', 'string'],
            'payment_accounts.*.address.postcode' => ['required', 'string'],
            'payment_accounts.*.address.city' => ['required', 'string'],
            'payment_accounts.*.address.state' => ['required', 'string'],
            'payment_accounts.*.address.country_id' => ['required', 'exists:countries,id'],
            'shipment_details' => ['required', 'array'],
            'shipment_details.*.name' => ['required', 'string'],
            'shipment_details.*.email' => ['required', 'string'],
            'shipment_details.*.receiver_name' => ['required', 'string'],
            'shipment_details.*.phone_dialing_code_id' => ['required', 'exists:dialing_codes,id'],
            'shipment_details.*.phone_number' => ['required', 'string'],
            'shipment_details.*.fax_dialing_code_id' => ['nullable', 'exists:dialing_codes,id'],
            'shipment_details.*.fax_number' => ['nullable', 'string'],
            'shipment_details.*.address' => ['required', 'array'],
            'shipment_details.*.address.line_1' => ['required', 'string'],
            'shipment_details.*.address.line_2' => ['nullable', 'string'],
            'shipment_details.*.address.postcode' => ['required', 'string'],
            'shipment_details.*.address.city' => ['required', 'string'],
            'shipment_details.*.address.state' => ['required', 'string'],
            'shipment_details.*.address.country_id' => ['required', 'exists:countries,id'],
        ];
    }

    /**
     * Handle a failed authorization attempt.
     *
     * @void
     * @throws \Illuminate\Http\Exceptions\HttpResponseException
     */
    protected function failedAuthorization(): void
    {
        throw new HttpResponseException(
            response()->json([
                'message' => 'You are not authorized to perform this action.'
            ], 403)
        );
    }

    /**
     * Handle a failed validation attempt.
     *
     * @param \Illuminate\Validation\Validator $validator
     * @return void
     *
     * @throws \Illuminate\Http\Exceptions\HttpResponseException
     */
    protected function failedValidation(Validator $validator): void
    {
        throw new HttpResponseException(
            response()->json([
                'error' => $validator->errors()
            ], 422)
        );
    }
}
