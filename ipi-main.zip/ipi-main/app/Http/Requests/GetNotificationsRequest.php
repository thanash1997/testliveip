<?php

namespace App\Http\Requests;

use App\Models\Module;
use App\Models\User;
use Carbon\Carbon;
use IPI\Core\DTO\IndexFilter;

class GetNotificationsRequest extends BaseFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'per_page' => 'nullable|integer',
            'search_query' => 'nullable|string',
            'sort_order' => 'nullable|in:desc,asc',
            'date_range' => 'nullable|array',
            'date_range.*' => 'required|date',
            'module_ids' => 'nullable|array',
            'module_ids.*' => 'nullable|exists:modules,id',
        ];
    }

    public function toDTO(): IndexFilter
    {
        $validatedData = $this->validated();
        $loggedInUser = auth()->user();
        $isSuperAdmin = $loggedInUser->hasRole(User::SUPER_ADMIN_ROLE);
        $userDepartment = $loggedInUser->department;
        $moduleIds = $validatedData['module_ids'] ?? $this->getModules($isSuperAdmin, $userDepartment);

        $indexFilter = new IndexFilter();
        $indexFilter->searchQuery = $validatedData['search_query'] ?? null;
        $indexFilter->perPage = isset($validatedData['per_page']) ? (int)$validatedData['per_page'] : 20;
        $indexFilter->sortOrder = $validatedData['sort_order'] ?? 'asc';
        $indexFilter->startDate = isset($validatedData['date_range']) ? Carbon::parse($validatedData['date_range'][0]) : null;
        $indexFilter->endDate = isset($validatedData['date_range']) ? Carbon::parse($validatedData['date_range'][1]) : null;
        $indexFilter->moduleIds = $moduleIds;
        $indexFilter->relationships = ['modules' => function ($query) use ($moduleIds) {
            return $query->whereIn('modules.id', $moduleIds);
        }];
        $indexFilter->type = $loggedInUser->hasRole(User::ADMIN_ROLE) || $loggedInUser->hasRole(User::SUPER_ADMIN_ROLE) ? 'with-approval' : 'without-approval';

        return $indexFilter;
    }

    private function getModules($isSuperAdmin, $userDepartment): array
    {
        $modules = Module::query()
            ->when(!$isSuperAdmin, function ($query) use ($userDepartment) {
                $query->whereHas('departments', function ($query) use ($userDepartment) {
                    $query->where('departments.id', $userDepartment->id);
                });
            })
            ->pluck('id');

        return $modules->toArray();
    }
}
