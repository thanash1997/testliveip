<?php

namespace App\Http\Requests;

use App\Models\User;
use Illuminate\Foundation\Http\FormRequest;

class UpdateCompanyRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        return auth()->user()->hasPermissionTo(User::UPDATE_CUSTOMER_PERMISSION);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => ['nullable', 'string'],
            'registration_number' => ['nullable', 'string'],
            'website_url' => ['nullable', 'string'],
            'sst_number' => ['nullable', 'string'],
            'gst_number' => ['nullable', 'string'],
            'phone_dialing_code_id' => ['nullable', 'exists:dialing_codes,id'],
            'phone_number' => ['nullable', 'string'],
            'fax_dialing_code_id' => ['nullable', 'exists:dialing_codes,id'],
            'fax_number' => ['nullable', 'string'],
            'address' => ['nullable', 'array'],
            'address.line_1' => ['nullable', 'string'],
            'address.line_2' => ['nullable', 'string'],
            'address.postcode' => ['nullable', 'string'],
            'address.city' => ['nullable', 'string'],
            'address.state' => ['nullable', 'string'],
            'address.country_id' => ['nullable', 'exists:countries,id'],
            'shipment_details' => ['nullable', 'array'],
            'shipment_details.id' => ['nullable', 'exists:shipments,id'],
            'shipment_details.name' => ['nullable', 'string'],
            'shipment_details.email' => ['nullable', 'string'],
            'shipment_details.receiver_name' => ['nullable', 'string'],
            'shipment_details.phone_dialing_code_id' => ['nullable', 'exists:dialing_codes,id'],
            'shipment_details.phone_number' => ['nullable', 'string'],
            'shipment_details.fax_dialing_code_id' => ['nullable', 'exists:dialing_codes,id'],
            'shipment_details.fax_number' => ['nullable', 'string'],
            'shipment_details.address' => ['nullable', 'array'],
            'shipment_details.address.line_1' => ['nullable', 'string'],
            'shipment_details.address.line_2' => ['nullable', 'string'],
            'shipment_details.address.postcode' => ['nullable', 'string'],
            'shipment_details.address.city' => ['nullable', 'string'],
            'shipment_details.address.state' => ['nullable', 'string'],
            'shipment_details.address.country_id' => ['nullable', 'exists:countries,id'],

            'employees' => ['nullable'],
            'employees.id' => ['nullable', 'exists:employees,id'],
            'employees.name' => ['nullable', 'string'],
            'employees.email' => ['nullable', 'string'],
            'employees.designation' => ['nullable', 'string'],
            'employees.phone_dialing_code_id' => ['nullable', 'exists:dialing_codes,id'],
            'employees.phone_number' => ['nullable', 'string'],
            'employees.fax_dialing_code_id' => ['nullable', 'exists:dialing_codes,id'],
            'employees.fax_number' => ['nullable', 'string'],

            'payment_accounts' => ['nullable', 'array'],
            'payment_accounts.id' => ['nullable', 'exists:payment_accounts,id'],
            'payment_accounts.account_name' => ['nullable', 'string'],
            'payment_accounts.email' => ['nullable', 'string'],
            'payment_accounts.account_holder_name' => ['nullable', 'string'],
            'payment_accounts.account_number' => ['nullable', 'string'],
            'payment_accounts.bank_id' => ['nullable', 'exists:banks,id'],
            'payment_accounts.phone_dialing_code_id' => ['nullable', 'exists:dialing_codes,id'],
            'payment_accounts.phone_number' => ['nullable', 'string'],
            'payment_accounts.fax_dialing_code_id' => ['nullable', 'exists:dialing_codes,id'],
            'payment_accounts.fax_number' => ['nullable', 'string'],
            'payment_accounts.address' => ['nullable', 'array'],
            'payment_accounts.address.line_1' => ['nullable', 'string'],
            'payment_accounts.address.line_2' => ['nullable', 'string'],
            'payment_accounts.address.postcode' => ['nullable', 'string'],
            'payment_accounts.address.city' => ['nullable', 'string'],
            'payment_accounts.address.state' => ['nullable', 'string'],
            'payment_accounts.address.country_id' => ['nullable', 'exists:countries,id'],
        ];
    }
}
