<?php

namespace App\Http\Controllers\Chat;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class GetUserChatsController extends Controller
{
    public function __invoke(Request $request): JsonResponse
    {
        $userId = auth()->user()->id;
        $userChats = User::query()
            ->leftJoin(DB::raw('chat_rooms as r1'), function ($query) use ($userId) {
                return $query->on('r1.first_participant_id', '=', 'users.id')
                    ->on('r1.second_participant_id', '=', DB::raw("{$userId}"));
            })
            ->leftJoin(DB::raw('chat_rooms as r2'), function ($query) use ($userId) {
                return $query->on('r2.second_participant_id', '=', 'users.id')
                    ->on('r2.first_participant_id', '=', DB::raw("{$userId}"));
            })
            ->where('users.id', '!=', $userId)
            ->where('users.can_login', '=', true)
            ->select([
                'users.id AS user_id',
                'users.name',
                DB::raw('(SELECT created_at FROM chat_messages WHERE room_id = IF(r1.id IS NULL, r2.id, r1.id) ORDER BY id DESC LIMIT 1) AS last_message_at'),
                DB::raw('IF(r1.id IS NULL, r2.id, r1.id) AS joined_room_id'),
                DB::raw("(SELECT COUNT(*) FROM chat_messages WHERE chat_messages.room_id = joined_room_id AND user_id != {$userId} AND read_at IS NULL) AS unread_count")
            ])
            ->orderBy('unread_count', 'desc')
            ->orderBy('last_message_at', 'desc')
            ->get();

        return response()->json([
            'data' => $userChats
        ]);
    }
}
