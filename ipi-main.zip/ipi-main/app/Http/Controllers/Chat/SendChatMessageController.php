<?php

namespace App\Http\Controllers\Chat;

use App\Events\NewChatMessage;
use App\Http\Controllers\Controller;
use App\Models\ChatMessage;
use App\Models\ChatRoom;
use Illuminate\Http\Request;

class SendChatMessageController extends Controller
{
    public function __invoke(Request $request, $roomId = null)
    {
        $userId = auth()->user()->id;
        if (!$roomId) {
            $room = ChatRoom::create([
                'first_participant_id' => $userId,
                'second_participant_id' => $request->get('user_id')
            ]);

            $roomId = $room->id;
        } else {
            $room = ChatRoom::find($roomId);
        }

        $participants = [$room->first_participant_id, $room->second_participant_id];
        $chatMessage = ChatMessage::create([
            'user_id' => auth()->user()->id,
            'room_id' => $roomId,
            'message' => $request->get('message')
        ]);

        if ($request->has('file') && !empty($request->get('file'))) {
            $chatMessage->addMediaFromDisk($request->get('file'))->toMediaCollection();
        }

        $resData = [
            'message' => $request->get('message'),
            'room_id' => $roomId,
        ];

        $media = $chatMessage->getFirstMedia();

        if ($media) {
            $resData['file'] = [
                'uuid' => $media->uuid,
                'fileName' => $media->file_name,
            ];
        }

        $receiverId = array_diff($participants, [$userId]);
        NewChatMessage::dispatch($receiverId[0] ?? $receiverId[1], $roomId);

        return response()->json([
            'data' => $resData
        ], 201);
    }
}
