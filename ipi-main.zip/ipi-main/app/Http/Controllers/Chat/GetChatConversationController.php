<?php

namespace App\Http\Controllers\Chat;

use App\Http\Controllers\Controller;
use App\Models\ChatMessage;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class GetChatConversationController extends Controller
{
    public function __invoke(Request $request, $roomId): JsonResponse
    {
        $validation = Validator::make($request->all(), [
            'unread' => 'nullable|boolean'
        ]);

        $validatedData = $validation->validated();

        $readMessages = [];
        $userId = auth()->user()->id;
        $chatMessages = ChatMessage::query()
            ->with(['media'])
            ->where('room_id', '=', $roomId)
            ->when($validatedData['unread'] == 1, function ($query) {
                $query->whereNull('read_at');
            })
            ->orderBy('id', 'desc')
            ->get()
            ->map(function ($message) use ($userId, &$readMessages) {
                if ($message->read_at === null) {
                    $readMessages[] = $message->id;
                }

                if ($userId === $message->user_id) {
                    $data = [
                        'to' => $message->message ?? ''
                    ];
                } else {
                    $data = [
                        'from' => $message->message ?? ''
                    ];
                }


                if (!empty($message->media[0])) {
                    $data['file'] = [
                        'uuid' => $message->media[0]->uuid,
                        'fileName' => $message->media[0]->file_name,
                    ];
                }

                return $data;
            });

        ChatMessage::query()->whereIn('id', $readMessages)->update([
            'read_at' => now()
        ]);

        return response()->json([
            'data' => $chatMessages
        ]);
    }
}
