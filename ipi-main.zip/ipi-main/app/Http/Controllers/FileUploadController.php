<?php

namespace App\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class FileUploadController extends Controller
{
    public function __invoke(Request $request): JsonResponse
    {
        $requestedFileName = $request->get('file_name');
        $fileName = uniqid() . "_$requestedFileName";
        $request->file('image')->storePubliclyAs('files', $fileName);

        return response()->json([
            'data' => [
                'url' => "/files/$fileName"
            ]
        ]);
    }
}
