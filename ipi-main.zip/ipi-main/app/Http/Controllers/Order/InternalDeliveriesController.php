<?php

namespace App\Http\Controllers\Order;

use App\Exceptions\InsufficientInventoryQuantity;
use App\Http\Controllers\Controller;
use App\Http\Requests\Order\CreateInternalDeliveryOrderRequest;
use App\Http\Requests\Order\GetInternalDeliveryOrdersRequest;
use App\Http\Requests\Order\UpdateInternalDeliveryOrderRequest;
use Illuminate\Http\JsonResponse;
use IPI\Core\Order\GetInternalDeliveryOrders;
use IPI\Core\Order\InternalDeliveryOrderCreator;
use IPI\Core\Order\UpdateSingleInternalDeliveryOrder;

class InternalDeliveriesController extends Controller
{
    public function index(GetInternalDeliveryOrders $getInternalDeliveryOrders, GetInternalDeliveryOrdersRequest $request): JsonResponse
    {
        [$internalDeliveryOrders, $meta] = $getInternalDeliveryOrders->getInternalDeliveryOrders($request->toDTO());

        return response()->json(array_merge($meta, [
            'data' => $internalDeliveryOrders
        ]));
    }

    /**
     * @param InternalDeliveryOrderCreator $internalDeliveryOrderCreator
     * @param CreateInternalDeliveryOrderRequest $request
     *
     * @return JsonResponse
     * @throws InsufficientInventoryQuantity
     */
    public function store(InternalDeliveryOrderCreator $internalDeliveryOrderCreator, CreateInternalDeliveryOrderRequest $request): JsonResponse
    {
        $internalDeliveryOrder = $internalDeliveryOrderCreator->createInternalDeliveryOrder($request->toDTO());

        return response()->json([
            'data' => $internalDeliveryOrder
        ], 201);
    }

    public function show($id)
    {
        //
    }

    public function update(UpdateSingleInternalDeliveryOrder $updateSingleInternalDeliveryOrder, UpdateInternalDeliveryOrderRequest $request, $uuid): JsonResponse
    {
        $internalDeliveryOrder = $updateSingleInternalDeliveryOrder->updateInternalDeliveryOrder($request->toDTO(), $uuid);

        return response()->json([
            'data' => $internalDeliveryOrder
        ]);
    }

    public function destroy($id)
    {
        //
    }
}
