<?php

namespace App\Http\Controllers\Order;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;
use IPI\Core\Order\SendProductQaNotification;

class SendProductQaNotificationController extends Controller
{
    public function __invoke(SendProductQaNotification $notification, Request $request)
    {
        $lastOrder = Order::query()
            ->leftJoin('order_items', 'order_items.order_id', '=', 'orders.id')
            ->leftJoin('products', 'products.id', '=', 'order_items.product_id')
            ->where('products.uuid', $request->get('product_uuid'))
            ->orderBy('orders.completed_at', 'desc')
            ->select(['orders.uuid'])
            ->first();

        if ($lastOrder) {
            $notification->sendNotification($request->get('product_code'), $lastOrder->uuid);
        }

        return response()->json([], 204);
    }
}
