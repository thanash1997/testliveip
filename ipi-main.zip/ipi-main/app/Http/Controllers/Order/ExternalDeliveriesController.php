<?php

namespace App\Http\Controllers\Order;

use App\Exceptions\InsufficientInventoryQuantity;
use App\Http\Controllers\Controller;
use App\Http\Requests\Order\CreateExternalDeliveryOrderRequest;
use App\Http\Requests\Order\GetExternalDeliveryOrdersRequest;
use App\Http\Requests\Order\UpdateExternalDeliveryOrderRequest;
use Illuminate\Http\JsonResponse;
use IPI\Core\Order\ExternalDeliveryOrderCreator;
use IPI\Core\Order\GetExternalDeliverOrders;
use IPI\Core\Order\UpdateSingleExternalDeliveryOrder;

class ExternalDeliveriesController extends Controller
{
    public function index(GetExternalDeliverOrders $getExternalDeliverOrders, GetExternalDeliveryOrdersRequest $request): JsonResponse
    {
        [$externalDeliveryOrders, $meta] = $getExternalDeliverOrders->getExternalDeliveryOrders($request->toDTO());

        return response()->json(array_merge($meta, [
            'data' => $externalDeliveryOrders
        ]));
    }

    /**
     * @param CreateExternalDeliveryOrderRequest $request
     * @param ExternalDeliveryOrderCreator $orderCreator
     *
     * @return JsonResponse
     * @throws InsufficientInventoryQuantity
     */
    public function store(CreateExternalDeliveryOrderRequest $request, ExternalDeliveryOrderCreator $orderCreator): JsonResponse
    {
        $externalDeliveryOrder = $orderCreator->createExternalDeliveryOrder($request->toDTO());

        return response()->json([
            'data' => $externalDeliveryOrder
        ], 201);
    }

    public function show($id)
    {
        //
    }

    public function update(UpdateSingleExternalDeliveryOrder $updateSingleExternalDeliveryOrder, UpdateExternalDeliveryOrderRequest $request, $uuid): JsonResponse
    {
        $externalDeliveryOrder = $updateSingleExternalDeliveryOrder->updateExternalDeliveryOrder($request->toDTO(), $uuid);

        return response()->json([
            'data' => $externalDeliveryOrder
        ]);
    }

    public function destroy($id)
    {
        //
    }
}
