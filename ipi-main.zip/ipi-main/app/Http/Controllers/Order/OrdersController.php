<?php

namespace App\Http\Controllers\Order;

use App\Http\Controllers\Controller;
use App\Http\Requests\Order\CreateOrderRequest;
use App\Http\Requests\Order\GetOrdersRequest;
use App\Http\Requests\Order\UpdateOrderRequest;
use Illuminate\Http\JsonResponse;
use IPI\Core\Order\GetOrders;
use IPI\Core\Order\OrderCreator;
use IPI\Core\Order\UpdateSingleOrder;

class OrdersController extends Controller
{
    public function index(GetOrders $getOrders, GetOrdersRequest $request): JsonResponse
    {
        [$orders, $meta] = $getOrders->getOrders($request->toDTO());

        return response()->json(array_merge($meta, [
            'data' => $orders
        ]));
    }

    public function store(OrderCreator $orderCreator, CreateOrderRequest $request): JsonResponse
    {
        $order = $orderCreator->createOrder($request->toDTO());

        return response()->json([
            'data' => $order
        ], 201);
    }

    public function show($id)
    {
        //
    }

    public function update(UpdateSingleOrder $updateSingleOrder, UpdateOrderRequest $request, $uuid): JsonResponse
    {
        $order = $updateSingleOrder->updateOrder($request->toDTO(), $uuid);

        return response()->json([
            'data' => $order
        ]);
    }

    public function destroy($id)
    {
        //
    }
}
