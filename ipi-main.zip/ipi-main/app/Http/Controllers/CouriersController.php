<?php

namespace App\Http\Controllers;

use App\Models\Courier;
use Carbon\Carbon;
use Illuminate\Http\Request;

class CouriersController extends Controller
{
    public function index(Request $request)
    {
        return Courier::query()
            ->when($request->get('search_query'), function ($query, $searchQuery) {
                return $query->where('name', 'LIKE', "%$searchQuery%")
                    ->orWhere('code', 'LIKE', "%$searchQuery%");
            })
            ->when($request->get('date_range'), function ($query, $dateRange) {
                $startDate = Carbon::parse($dateRange[0])->startOfDay();
                $endDate = Carbon::parse($dateRange[1])->endOfDay();

                return $query->whereBetween('created_at', [
                    $startDate,
                    $endDate,
                ]);
            })
            ->orderBy('created_at', $request->get('sort') ?? 'DESC')
            ->paginate($request->get('per_page') ?? 15);
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string',
            'code' => 'required|string',
        ]);

        $courier = new Courier($request->only(['name', 'code']));
        $courier->save();

        return response()->json(['data' => $courier], 201);
    }


    public function update(Request $request, $courierId)
    {
        $courier = Courier::query()->find($courierId);
        $courier->update($request->only(['name', 'code']));

        return response()->json(['data' => $courier]);
    }

    public function destroy(Request $request)
    {
        $request->validate([
            'ids' => 'required|array',
            'ids.*' => 'required|exists:couriers,id',
        ]);

        Courier::query()->whereIn('id', $request->get('ids'))->delete();

        return response()->json([], 204);
    }
}
