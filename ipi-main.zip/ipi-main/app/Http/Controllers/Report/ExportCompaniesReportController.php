<?php

namespace App\Http\Controllers\Report;

use App\Exports\CompanyExport;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ExportCompaniesReportController extends Controller
{
    public function __invoke(Request $request)
    {
        return new CompanyExport(
            $request->get('type'),
            $request->get('startDate'),
            $request->get('endDate'),
            $request->get('companyId'),
        );
    }
}
