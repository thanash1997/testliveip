<?php

namespace App\Http\Controllers\Report;

use App\Exports\ProcurementExport;
use App\Exports\WarehouseEdoExport;
use App\Exports\WarehouseIdoExport;
use App\Exports\WarehouseInventoryExport;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ExportWarehouseReportController extends Controller
{
    public function __invoke(Request $request)
    {
        $request->validate([
            'type' => ['required', 'in:inventory,procurement,ido,edo']
        ]);

        if ($request->get('type') === 'inventory') {
            return new WarehouseInventoryExport(
                $request->get('startDate'),
                $request->get('endDate'),
                $request->get('productType'),
                $request->get('productTagId'),
                $request->get('quantity'),
                $request->get('threshold'),
            );
        }

        if ($request->get('type') === 'procurement') {
            return new ProcurementExport(
                $request->get('procurementStartDate'),
                $request->get('procurementEndDate'),
                $request->get('receivingStartDate'),
                $request->get('receivingEndDate'),
                $request->get('quantity'),
                $request->get('threshold'),
            );
        }

        if ($request->get('type') === 'ido') {
            return new WarehouseIdoExport(
                $request->get('startDate'),
                $request->get('endDate'),
                $request->get('deliveryStartDate'),
                $request->get('deliveryEndDate'),
                $request->get('orderId'),
            );
        }

        if ($request->get('type') === 'edo') {
            return new WarehouseEdoExport(
                $request->get('startDate'),
                $request->get('endDate'),
                $request->get('deliveryStartDate'),
                $request->get('deliveryEndDate'),
                $request->get('customerId'),
            );
        }
    }
}
