<?php

namespace App\Http\Controllers\Report;

use App\Exports\ProducedStockExport;
use App\Exports\ProductionConsumptionExport;
use App\Exports\ProductMovementExport;
use App\Exports\ProductProducedExport;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ExportProductionReportController extends Controller
{
    public function __invoke(Request $request)
    {
        $request->validate([
            'type' => ['required', 'in:produced,movement,produced-stock,consumption']
        ]);

        if ($request->get('type') === 'produced') {
            return new ProductProducedExport(
                $request->get('startDate'),
                $request->get('endDate'),
                $request->get('companyId'),
            );
        }

        if ($request->get('type') === 'movement') {
            return new ProductMovementExport(
                $request->get('startDate'),
                $request->get('endDate'),
                $request->get('orderId'),
            );
        }

        if ($request->get('type') === 'produced-stock') {
            return new ProducedStockExport(
                $request->get('startDate'),
                $request->get('endDate'),
                $request->get('companyId'),
                $request->get('formulaTypeId'),
            );
        }

        if ($request->get('type') === 'consumption') {
            return new ProductionConsumptionExport(
                $request->get('startDate'),
                $request->get('endDate'),
                $request->get('orderId'),
                $request->get('formulaTypeId'),
            );
        }

        return response();
    }
}
