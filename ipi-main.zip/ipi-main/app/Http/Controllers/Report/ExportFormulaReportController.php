<?php

namespace App\Http\Controllers\Report;

use App\Exports\FormulaExport;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ExportFormulaReportController extends Controller
{
    public function __invoke(Request $request)
    {
        return new FormulaExport(
            $request->get('type'),
            $request->get('startDate'),
            $request->get('endDate'),
            $request->get('formulaTypeId'),
            $request->get('customerId'),
            $request->get('productTagId'),
        );
    }
}
