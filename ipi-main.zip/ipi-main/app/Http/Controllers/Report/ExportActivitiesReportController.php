<?php

namespace App\Http\Controllers\Report;

use App\Exports\ActivityExport;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ExportActivitiesReportController extends Controller
{
    public function __invoke(Request $request)
    {
        return new ActivityExport(
            $request->get('moduleId'),
            $request->get('startDate'),
            $request->get('endDate'),
            $request->get('roleId'),
            $request->get('userId'),
            $request->get('actionType'),
        );
    }
}
