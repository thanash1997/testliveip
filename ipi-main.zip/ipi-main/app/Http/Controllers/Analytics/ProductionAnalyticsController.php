<?php

namespace App\Http\Controllers\Analytics;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class ProductionAnalyticsController extends Controller
{
    public function __invoke(): JsonResponse
    {
        $fastestTime = DB::select('SELECT TIMESTAMPDIFF(SECOND, production_started_at, completed_at) AS total_time_in_sec 
                                        FROM orders
                                        WHERE completed_at IS NOT NULL
                                        ORDER BY total_time_in_sec ASC LIMIT 1');

        $slowestTime = DB::select('SELECT TIMESTAMPDIFF(SECOND, production_started_at, completed_at) AS total_time_in_sec 
                                        FROM orders
                                        WHERE completed_at IS NOT NULL
                                        ORDER BY total_time_in_sec DESC LIMIT 1');

        $forAverage = DB::select('SELECT COUNT(*) AS total_orders, SUM(TIMESTAMPDIFF(SECOND, production_started_at, completed_at)) AS total_time_in_sec 
                                        FROM orders
                                        WHERE completed_at IS NOT NULL');

        $monthlyAverage = DB::select('SELECT MONTH(completed_at) AS completed_month, SUM(TIMESTAMPDIFF(SECOND, production_started_at, completed_at)) / COUNT(*) AS total_time_in_sec 
                                        FROM orders
                                        WHERE completed_at IS NOT NULL
                                        GROUP BY MONTH(completed_at) ORDER BY completed_month');

        return response()->json([
            'fastest_time' => count($fastestTime) > 0 ? number_format($fastestTime[0]->total_time_in_sec / 3600, 2) : 0,
            'slowest_time' => count($slowestTime) > 0 ? number_format($slowestTime[0]->total_time_in_sec / 3600, 2) : 0,
            'average_time' => $forAverage[0]->total_orders > 0 ? number_format($forAverage[0]->total_time_in_sec / $forAverage[0]->total_orders / 3600 ?? 0, 2) : 0,
            'monthly_average' => $monthlyAverage,
        ]);
    }
}
