<?php

namespace App\Http\Controllers\Analytics;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class SalesAnalyticsController extends Controller
{
    public function __invoke(): JsonResponse
    {
        $analytics = DB::select('SELECT MONTH(fulfilled_at) AS fulfilled_month, COUNT(*) AS total FROM external_delivery_orders
                                        WHERE fulfilled_at IS NOT NULL
                                        GROUP BY MONTH(fulfilled_at) ORDER BY fulfilled_month');

        return response()->json([
            'data' => $analytics
        ]);
    }
}
