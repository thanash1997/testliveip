<?php

namespace App\Http\Controllers\Analytics;

use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StockMovementAnalyticsController extends Controller
{
    public function __invoke(Request $request): JsonResponse
    {
        $inventories = DB::select('SELECT i.name, i.slug, SUM(ip.quantity) AS total_stocks FROM inventory_products ip
                                            LEFT JOIN inventories i ON i.id = ip.inventory_id
                                            GROUP BY ip.inventory_id');

        $analyticsQuery = 'SELECT i.name, i.slug, SUM(idi.quantity) AS stock_quantity FROM internal_delivery_items idi
                                        LEFT JOIN internal_delivery_orders ido ON ido.id = idi.internal_delivery_order_id
                                        LEFT JOIN inventories i ON i.id = ido.destination_id
                                        WHERE ido.fulfilled_at IS NOT NULL';

        if ($request->has('start_date') && $request->has('end_date')) {
            $startDate = Carbon::parse($request->get('start_date'))->startOfDay();
            $endDate = Carbon::parse($request->get('end_date'))->endOfDay();
            $analyticsQuery .= " AND fulfilled_at BETWEEN '$startDate' AND '$endDate'";
        }

        $analyticsQuery .= ' GROUP BY ido.destination_id';
        $analytics = DB::select($analyticsQuery);

        return response()->json([
            'stats' => $inventories,
            'analytics' => $analytics
        ]);
    }
}
