<?php

namespace App\Http\Controllers\Analytics;

use App\Http\Controllers\Controller;
use App\Models\Formula;
use App\Models\Order;
use App\Models\ProductRequisition;

class MainAnalyticsController extends Controller
{
    public function __invoke()
    {
        return response()->json([
            'data' => [
                'total_pending_orders' => Order::query()->whereNull([
                    'completed_at',
                    'cancelled_at',
                    'halted_at',
                ])->count(),
                'total_orders_pending_approval' => Formula::query()->whereNull(['approved_at', 'rejected_at'])->count(),
                'total_material_requisitions' => ProductRequisition::query()->whereNull(['approved_at', 'rejected_at'])->count(),
            ]
        ]);
    }
}
