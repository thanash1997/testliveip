<?php

namespace App\Http\Controllers;

use App\Models\Module;
use App\Models\Notification;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class GetTotalUnreadNotificationsController extends Controller
{
    public function __invoke(Request $request): JsonResponse
    {
        $user = User::find($request->get('user_id')) ?? auth()->user();
        $isSuperAdmin = $user->hasRole(User::SUPER_ADMIN_ROLE);
        $userDepartment = $user->department;
        $totalUnreadQuery = Notification::query()->whereNull('read_at');

        if (!$isSuperAdmin) {
            $moduleIds = Module::query()
                ->when(!$isSuperAdmin, function ($query) use ($userDepartment) {
                    $query->whereHas('departments', function ($query) use ($userDepartment) {
                        $query->where('departments.id', $userDepartment->id);
                    });
                })
                ->pluck('id')
                ->toArray();

            $totalUnreadQuery->whereHas('modules', function ($query) use ($moduleIds) {
                return $query->whereIn('module_id', $moduleIds);
            });
        }

        return response()->json([
            'data' => [
                'total_unread' => $totalUnreadQuery->count()
            ]
        ]);
    }
}
