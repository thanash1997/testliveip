<?php

namespace App\Http\Controllers;

use App\Http\Requests\Company\CreateCompanyRequest;
use App\Http\Requests\Company\GetCompaniesRequest;
use App\Http\Requests\UpdateCompanyRequest;
use App\Models\Company;
use App\Models\PhoneNumber;
use IPI\Core\Company\Filters\CompanyFilter;
use IPI\Core\Company\Services\CompanyService;

class CompaniesController extends Controller
{
    private CompanyService $service;

    public function __construct(CompanyService $companyService)
    {
        $this->service = $companyService;
    }

    public function index(GetCompaniesRequest $request)
    {
        $validatedRequestData = $request->validated();

        return $this->service->getCompanies(
            new CompanyFilter([
                'per_page' => $validatedRequestData['per_page'] ?? 20,
                'type' => $validatedRequestData['type'],
                'search_query' => $validatedRequestData['search_query'] ?? null,
                'sort_order' => $validatedRequestData['sort_order'] ?? null,
                'date_range' => $validatedRequestData['date_range'] ?? null,
            ])
        );
    }

    public function create(CreateCompanyRequest $request)
    {
        return response()->json([
            'data' => $this->service->createCompany($request->validated()),
        ], 201);
    }

    public function update($uuid, UpdateCompanyRequest $request)
    {
        $validatedRequest = $request->validated();
        $entitiesToUnset = ['address', 'shipment_details', 'employees', 'payment_accounts'];
        $address = $validatedRequest['address'] ?? null;
        $shipmentDetails = $validatedRequest['shipment_details'] ?? null;
        $employees = $validatedRequest['employees'] ?? null;
        $paymentAccounts = $validatedRequest['payment_accounts'] ?? null;

        foreach ($entitiesToUnset as $entity) {
            unset($validatedRequest[$entity]);
        }

        $company = Company::where('uuid', $uuid)->first();
        $company->update($validatedRequest);

        $updatedData = [];
        if (isset($validatedRequest['phone_number'])) {
            $updatedData['phone_number'] = $validatedRequest['phone_number'];
        }

        if (isset($validatedRequest['phone_dialing_code_id'])) {
            $updatedData['dialing_code_id'] = $validatedRequest['phone_dialing_code_id'];
        }

        if (!empty($updatedData)) {
            if ($company->phoneNumber()->exists()) {
                $company->phoneNumber()->update($updatedData);
            } else {
                $phoneNumber = new PhoneNumber($updatedData);
                $phoneNumber->save();

                $company->phoneNumber()->associate($phoneNumber);
            }
        }

        $faxUpdatedData = [];
        if (isset($validatedRequest['fax_number'])) {
            $faxUpdatedData['phone_number'] = $validatedRequest['fax_number'];
        }

        if (isset($validatedRequest['fax_dialing_code_id'])) {
            $faxUpdatedData['dialing_code_id'] = $validatedRequest['fax_dialing_code_id'];
        }

        if (!empty($faxUpdatedData)) {
            if ($company->faxNumber()->exists()) {
                $company->faxNumber()->update($faxUpdatedData);
            } else {
                $faxNumber = new PhoneNumber($faxUpdatedData);
                $faxNumber->save();

                $company->faxNumber()->associate($faxNumber);
            }
        }

        if ($address) {
            $company->address()->update($address);
        }

        if ($shipmentDetails) {
            $shipmentDetailsId = $shipmentDetails['id'];
            unset($shipmentDetails['id']);

            $shipment = $company->shipments()->where('id', $shipmentDetailsId)->first();

            $shipmentPhoneData = [];
            if (isset($shipmentDetails['phone_number'])) {
                $shipmentPhoneData['phone_number'] = $shipmentDetails['phone_number'];
                unset($shipmentDetails['phone_number']);
            }

            if (isset($shipmentDetails['phone_dialing_code_id'])) {
                $shipmentPhoneData['dialing_code_id'] = $shipmentDetails['phone_dialing_code_id'];
                unset($shipmentDetails['phone_dialing_code_id']);
            }

            if (!empty($shipmentPhoneData)) {
                if ($shipment->phoneNumber()->exists()) {
                    $shipment->phoneNumber()->update($shipmentPhoneData);
                } else {
                    $faxNumber = new PhoneNumber($shipmentPhoneData);
                    $faxNumber->save();

                    $shipment->phoneNumber()->associate($faxNumber);
                }
            }

            $shipmentFaxData = [];
            if (isset($shipmentDetails['fax_number'])) {
                $shipmentFaxData['phone_number'] = $shipmentDetails['fax_number'];
                unset($shipmentDetails['fax_number']);
            }

            if (isset($shipmentDetails['fax_dialing_code_id'])) {
                $shipmentFaxData['dialing_code_id'] = $shipmentDetails['fax_dialing_code_id'];
                unset($shipmentDetails['fax_dialing_code_id']);
            }

            if (!empty($shipmentFaxData)) {
                if ($shipment->faxNumber()->exists()) {
                    $shipment->faxNumber()->update($shipmentFaxData);
                } else {
                    $faxNumber = new PhoneNumber($shipmentFaxData);
                    $faxNumber->save();

                    $shipment->faxNumber()->associate($faxNumber);
                }
            }

            $shipment->update($shipmentDetails);
            $shipment->address()->update($shipmentDetails['address']);
        }

        if ($employees) {
            $employeeId = $employees['id'];
            unset($employees['id']);
            $employee = $company->employees()->where('id', $employeeId)->first();

            $employeePhoneData = [];
            if (isset($employees['phone_number'])) {
                $employeePhoneData['phone_number'] = $employees['phone_number'];
                unset($employees['phone_number']);
            }

            if (isset($employees['phone_dialing_code_id'])) {
                $employeePhoneData['dialing_code_id'] = $employees['phone_dialing_code_id'];
                unset($employees['phone_dialing_code_id']);
            }

            if (!empty($employeePhoneData)) {
                if ($employee->phoneNumber()->exists()) {
                    $employee->phoneNumber()->update($employeePhoneData);
                } else {
                    $faxNumber = new PhoneNumber($employeePhoneData);
                    $faxNumber->save();

                    $employee->phoneNumber()->associate($faxNumber);
                }
            }

            $employeeFaxData = [];
            if (isset($employees['fax_number'])) {
                $employeeFaxData['phone_number'] = $employees['fax_number'];
                unset($employees['fax_number']);
            }

            if (isset($employees['fax_dialing_code_id'])) {
                $employeeFaxData['dialing_code_id'] = $employees['fax_dialing_code_id'];
                unset($employees['fax_dialing_code_id']);
            }

            if (!empty($employeeFaxData)) {
                if ($employee->faxNumber()->exists()) {
                    $employee->faxNumber()->update($employeeFaxData);
                } else {
                    $faxNumber = new PhoneNumber($employeeFaxData);
                    $faxNumber->save();

                    $employee->faxNumber()->associate($faxNumber);
                }
            }

            $employee->update($employees);
            unset($employees['designation']);
            $employee->user()->update($employees);
        }

        if ($paymentAccounts) {
            $paymentAccountId = $paymentAccounts['id'];
            unset($paymentAccounts['id']);
            $paymentAccount = $company->paymentAccounts()->where('id', $paymentAccountId)->first();

            $accountPhoneData = [];
            if (isset($paymentAccounts['phone_number'])) {
                $accountPhoneData['phone_number'] = $paymentAccounts['phone_number'];
                unset($paymentAccounts['phone_number']);
            }

            if (isset($paymentAccounts['phone_dialing_code_id'])) {
                $accountPhoneData['dialing_code_id'] = $paymentAccounts['phone_dialing_code_id'];
                unset($paymentAccounts['phone_dialing_code_id']);
            }

            if (!empty($accountPhoneData)) {
                if ($paymentAccount->phoneNumber()->exists()) {
                    $paymentAccount->phoneNumber()->update($accountPhoneData);
                } else {
                    $faxNumber = new PhoneNumber($accountPhoneData);
                    $faxNumber->save();

                    $paymentAccount->phoneNumber()->associate($faxNumber);
                }
            }

            $accountFaxData = [];
            if (isset($paymentAccounts['fax_number'])) {
                $accountFaxData['phone_number'] = $paymentAccounts['fax_number'];
                unset($paymentAccounts['fax_number']);
            }

            if (isset($paymentAccounts['fax_number'])) {
                $accountFaxData['dialing_code_id'] = $paymentAccounts['fax_dialing_code_id'];
                unset($paymentAccounts['fax_number']);
            }

            if (!empty($faxUpdatedData)) {
                if ($paymentAccount->faxNumber()->exists()) {
                    $paymentAccount->faxNumber()->update($faxUpdatedData);
                } else {
                    $faxNumber = new PhoneNumber($faxUpdatedData);
                    $faxNumber->save();

                    $paymentAccount->faxNumber()->associate($faxNumber);
                }
            }

            $paymentAccount->update($paymentAccounts);
            $paymentAccount->address()->update($paymentAccounts['address']);
        }

        $company->save();
        $company->loadMissing(['faxNumber', 'phoneNumber', 'address', 'shipments', 'paymentAccounts', 'employees']);

        return response()->json(['data' => $company]);
    }
}
