<?php

namespace App\Http\Controllers;

use Spatie\MediaLibrary\MediaCollections\Models\Media;

class FileDeleteController extends Controller
{
    public function __invoke($mediaUuid)
    {
        Media::query()->where('uuid', $mediaUuid)->delete();
        return response()->json();
    }
}
