<?php

namespace App\Http\Controllers\Formula;

use App\Http\Controllers\Controller;
use App\Models\Formula;
use App\Models\Notification;
use Illuminate\Http\JsonResponse;

class RejectFormulaController extends Controller
{
    // TODO: Refactor controller
    public function __invoke($uuid): JsonResponse
    {
        Formula::query()->where('uuid', $uuid)
            ->update([
                'rejected_at' => now()
            ]);

        Notification::query()->where('id', request()->get('notification_id'))
            ->update([
                'read_at' => now(),
                'action_taken_at' => now(),
            ]);

        return response()->json();
    }
}
