<?php

namespace App\Http\Controllers\Formula;

use App\Http\Controllers\Controller;
use App\Models\Formula;
use App\Models\Notification;
use Illuminate\Http\JsonResponse;
use IPI\Core\Entities\Product;

class ApproveFormulaController extends Controller
{
    // TODO: Refactor controller
    public function __invoke($uuid): JsonResponse
    {
        $formula = Formula::query()->where('uuid', $uuid)->first();
        $formula->update([
            'approved_at' => now(),
        ]);

        $product = $formula->product;

        if ($product->type === Product::TYPE_FORMULA_SAMPLE) {
            $product->update([
                'type' => Product::TYPE_FORMULA,
            ]);
        }

        Notification::query()->where('id', request()->get('notification_id'))
            ->update([
                'read_at' => now(),
                'action_taken_at' => now(),
            ]);

        return response()->json();
    }
}
