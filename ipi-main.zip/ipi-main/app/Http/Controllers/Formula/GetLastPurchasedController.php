<?php

namespace App\Http\Controllers\Formula;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderItem;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\App;

class GetLastPurchasedController extends Controller
{
    public function __invoke($uuid): JsonResponse
    {
        $customerId = request()->get('customer_id');

        $lastOrder = Order::query()
            ->leftJoin('order_items', 'order_items.order_id', '=', 'orders.id')
            ->leftJoin('products', 'products.id', '=', 'order_items.product_id')
            ->where('products.uuid', $uuid)
            ->when($customerId, function ($query, $customerId) {
                return $query->where('orders.customer_id', $customerId);
            })
            ->whereNotNull('orders.completed_at')
            ->orderBy('orders.completed_at', 'desc')
            ->select(['orders.completed_at'])
            ->first();

        return response()->json([
            'data' => [
                'lastPurchased' => $lastOrder->completed_at ?? null
            ]
        ]);
    }
}
