<?php

namespace App\Http\Controllers;

use Illuminate\Contracts\Support\Responsable;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class FileDownloadController extends Controller
{
    public function __invoke($mediaUuid): Responsable
    {
        return Media::where('uuid', $mediaUuid)->first();
    }
}
