<?php

namespace App\Http\Controllers;

use App\Http\Requests\GetActivityLogsRequest;
use Illuminate\Http\JsonResponse;
use IPI\Core\General\GetActivityLogs;

class GetActivityLogsController extends Controller
{
    public function __invoke(GetActivityLogs $getActivityLogs, GetActivityLogsRequest $request): JsonResponse
    {
        [$activityLogs, $meta] = $getActivityLogs->getActivityLogs($request->toDTO());

        return response()->json(array_merge($meta, [
            'data' => $activityLogs
        ]));
    }
}
