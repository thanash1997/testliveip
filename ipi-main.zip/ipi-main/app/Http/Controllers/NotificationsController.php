<?php

namespace App\Http\Controllers;

use App\Http\Requests\GetNotificationsRequest;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use IPI\Core\General\GetNotifications;

class NotificationsController extends Controller
{
    public function index(GetNotifications $getNotifications, GetNotificationsRequest $request): JsonResponse
    {
        [$notifications, $meta] = $getNotifications->getNotifications($request->toDTO());

        return response()->json(array_merge($meta, [
            'data' => $notifications
        ]));
    }

    public function store(Request $request)
    {
        //
    }

    public function show($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }
}
