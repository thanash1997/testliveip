<?php

namespace App\Http\Controllers\Options;

use App\Http\Controllers\Controller;
use App\Models\Country;

class GetCountryOptionsController extends Controller
{
    public function __invoke()
    {
        return Country::with(['dialingCodes', 'banks'])->get();
    }
}
