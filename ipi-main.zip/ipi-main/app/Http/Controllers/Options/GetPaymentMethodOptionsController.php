<?php

namespace App\Http\Controllers\Options;

use App\Http\Controllers\Controller;
use App\Models\PaymentMethod;

class GetPaymentMethodOptionsController extends Controller
{
    public function __invoke()
    {
        return PaymentMethod::get();
    }
}
