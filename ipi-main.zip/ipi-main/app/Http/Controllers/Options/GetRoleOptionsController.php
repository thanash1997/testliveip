<?php

namespace App\Http\Controllers\Options;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;

class GetRoleOptionsController extends Controller
{
    public function __invoke(Request $request)
    {
        return response()->json(['data' => Role::all()]);
    }
}
