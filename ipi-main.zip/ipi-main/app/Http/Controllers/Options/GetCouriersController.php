<?php

namespace App\Http\Controllers\Options;

use App\Http\Controllers\Controller;
use App\Models\Courier;
use Illuminate\Http\JsonResponse;

class GetCouriersController extends Controller
{
    public function __invoke(): JsonResponse
    {
        return response()->json([
            'data' => Courier::query()->select(['name', 'code'])->get()
        ]);
    }
}
