<?php

namespace App\Http\Controllers\Options;

use App\Http\Controllers\Controller;
use App\Models\Inventory;

class GetInventoryOptionsController extends Controller
{
    public function __invoke()
    {
        return response()->json(['data' => Inventory::all()]);

    }
}
