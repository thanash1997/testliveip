<?php

namespace App\Http\Controllers\Options;

use App\Http\Controllers\Controller;
use App\Models\Module;
use App\Models\User;
use Illuminate\Http\JsonResponse;

class GetModulesController extends Controller
{
    public function __invoke(): JsonResponse
    {
        $user = auth()->user();
        $userDepartment = $user->department;
        $isSuperAdmin = $user->hasRole(User::SUPER_ADMIN_ROLE);
        $modules = Module::query()
            ->when(!$isSuperAdmin, function ($query) use ($userDepartment) {
                $query->whereHas('departments', function ($query) use ($userDepartment) {
                    $query->where('departments.id', $userDepartment->id);
                });
            })
            ->get();

        return response()->json([
            'data' => $modules
        ]);
    }
}
