<?php

namespace App\Http\Controllers\Views;

use App\Http\Controllers\Controller;
use App\Models\Formula;

class PrintFormulaController extends Controller
{
    public function __invoke($uuid)
    {
        $formula = Formula::query()
            ->with(['checkpoints', 'ingredientLists.ingredientListItems.product', 'product.requesterCustomer', 'engineer'])
            ->where('uuid', $uuid)
            ->first();
        return view('exports.print.formula', ['formula' => $formula, 'type' => request()->get('type') ?? 'Master']);
    }
}
