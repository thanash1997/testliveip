<?php

namespace App\Http\Controllers\Views;

use App\Http\Controllers\Controller;
use App\Models\Courier;
use Illuminate\Http\Request;

class ViewDeliveryCourierEditPageController extends Controller
{
    public function __invoke(Request $request, $id)
    {
        return view('couriers.edit', [
            'courier' => Courier::query()->find($id)
        ]);
    }
}
