<?php

namespace App\Http\Controllers\Views;

use App\Http\Controllers\Controller;
use App\Models\Inventory;
use App\Models\Product;

class PrintInventoryController extends Controller
{
    public function __invoke($inventory, $uuid)
    {
        $inventory = Inventory::query()->where('slug', $inventory)->first();
        $inventoryId = $inventory->id;
        $product = Product::query()
            ->with(['requesterCustomer', 'inventories' => function ($query) use ($inventoryId) {
                return $query->where('inventories.id', $inventoryId);
            }, 'productTags'])
            ->whereHas('inventories', function ($query) use ($inventoryId) {
                return $query->where('inventories.id', $inventoryId);
            })
            ->where('uuid', $uuid)
            ->first();

        return view('exports.print.inventory', ['product' => $product]);
    }
}
