<?php

namespace App\Http\Controllers\Views;

use App\Http\Controllers\Controller;
use IPI\Core\Order\GetSingleOrder;

class ViewProductionOrdersEditPageController extends Controller
{
    public function __invoke(GetSingleOrder $getSingleOrder, $uuid)
    {
        $order = $getSingleOrder->getOrder($uuid);

        return view('production.orders.edit')->with(['order' => json_encode($order)]);
    }
}
