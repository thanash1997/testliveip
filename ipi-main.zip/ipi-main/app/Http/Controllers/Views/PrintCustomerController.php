<?php

namespace App\Http\Controllers\Views;

use App\Http\Controllers\Controller;
use App\Models\Company;

class PrintCustomerController extends Controller
{
    public function __invoke($uuid)
    {
        $company = Company::withCreator()->with(['address.country', 'phoneNumber', 'faxNumber',
            'employees' => function ($query) {
                return $query->with(['phoneNumber', 'faxNumber', 'user']);
            }, 'paymentAccounts' => function ($query) {
                return $query->with(['address.country', 'paymentMethod', 'phoneNumber', 'bank']);
            }, 'shipments' => function ($query) {
                return $query->with(['company', 'address.country', 'phoneNumber']);
            }])->where('uuid', $uuid)->first();

        return view('exports.print.customer', ['company' => $company]);
    }
}
