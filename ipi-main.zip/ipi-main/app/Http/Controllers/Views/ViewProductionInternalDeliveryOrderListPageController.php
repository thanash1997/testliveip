<?php

namespace App\Http\Controllers\Views;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ViewProductionInternalDeliveryOrderListPageController extends Controller
{
    public function __invoke(Request $request)
    {
        return view('production.internal-delivery.index');
    }
}
