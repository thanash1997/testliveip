<?php

namespace App\Http\Controllers\Views;

use App\Http\Controllers\Controller;
use IPI\Core\Product\GetSingleProductRequisition;

class ViewWarehouseInternalMaterialReqViewPageController extends Controller
{
    public function __invoke(GetSingleProductRequisition $getSingleProductRequisition, $uuid)
    {
        $productRequisition = $getSingleProductRequisition->getProductRequisition($uuid);

        return view('warehouse.internal-material-req.details')
            ->with(['product_requisition' => json_encode($productRequisition)]);
    }
}
