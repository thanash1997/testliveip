<?php

namespace App\Http\Controllers\Views;

use App\Http\Controllers\Controller;
use IPI\Core\Product\GetSingleProcurement;

class ViewWarehouseProcurementEditPageController extends Controller
{
    public function __invoke(GetSingleProcurement $getSingleProcurement, $uuid)
    {
        $procurement = $getSingleProcurement->getProcurement($uuid);

        return view('warehouse.procurement.edit')->with([
            'procurement' => json_encode($procurement)
        ]);
    }
}
