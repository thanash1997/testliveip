<?php

namespace App\Http\Controllers\Views;

use App\Http\Controllers\Controller;
use IPI\Core\Order\GetSingleExternalDeliveryOrder;

class ViewWarehouseExternalDeliveryOrderEditPageController extends Controller
{
    public function __invoke(GetSingleExternalDeliveryOrder $getSingleExternalDeliveryOrder, $uuid)
    {
        $externalDeliverOrder = $getSingleExternalDeliveryOrder->getExternalDeliveryOrder($uuid);

        return view('warehouse.external-delivery.edit')
            ->with(['external_delivery_order' => json_encode($externalDeliverOrder)]);
    }
}
