<?php

namespace App\Http\Controllers\Views;

use App\Http\Controllers\Controller;
use Illuminate\Contracts\View\View;

class ViewCreateCompanyPageController extends Controller
{
    public function __invoke(): View
    {
        return view('customer.add');
    }
}
