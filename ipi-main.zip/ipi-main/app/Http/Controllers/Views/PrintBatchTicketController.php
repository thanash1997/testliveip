<?php

namespace App\Http\Controllers\Views;

use App\Http\Controllers\Controller;
use App\Models\Formula;
use App\Models\Order;

class PrintBatchTicketController extends Controller
{
    public function __invoke($uuid)
    {
        $order = Order::query()
            ->with([
                'customer',
                'orderItems' => function ($query) {
                    return $query->with([
                        'product',
                        'materialLists.productionMaterials',
                    ]);
                },
            ])
            ->where('uuid', $uuid)
            ->first();
        $formula = Formula::query()
            ->with(['checkpoints',])
            ->whereHas('product', function ($query) use ($order) {
                return $query->where(
                    'products.id',
                    $order->orderItems[0]->product_id
                );
            })
            ->first();
        $date = now()->addHours(8)->format('d-m-Y h:i a');
        $totalQuantity = 0;
        $position = 1;

        foreach ($order->orderItems->first()->materialLists as $materialList) {
            foreach ($materialList->productionMaterials as $productionMaterial) {
                $productionMaterial->pos = $position;
                $totalQuantity += $productionMaterial->quantity;
                $position++;
            }
        }

        return view(
            'exports.print.batch-ticket',
            ['order' => $order, 'formula' => $formula, 'date' => $date, 'totalQuantity' => $totalQuantity]
        );
    }
}
