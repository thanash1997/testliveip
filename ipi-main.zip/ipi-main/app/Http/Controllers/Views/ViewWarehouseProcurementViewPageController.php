<?php

namespace App\Http\Controllers\Views;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use IPI\Core\Product\GetSingleProcurement;

class ViewWarehouseProcurementViewPageController extends Controller
{
    public function __invoke(Request $request, GetSingleProcurement $getSingleProcurement, $uuid)
    {
        $procurement = $getSingleProcurement->getProcurement($uuid, $request->hasValidSignature());

        return view('warehouse.procurement.details')->with([
            'procurement' => json_encode($procurement),
        ]);
    }
}
