<?php

namespace App\Http\Controllers\Views;

use App\Http\Controllers\Controller;
use IPI\Core\Order\GetSingleOrder;

class ViewProductionOrdersViewPageController extends Controller
{
    public function __invoke(GetSingleOrder $getSingleOrder, $uuid)
    {
        $order = $getSingleOrder->getOrder($uuid);

        return view('production.orders.details')->with(['order' => json_encode($order)]);
    }
}
