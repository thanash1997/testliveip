<?php

namespace App\Http\Controllers\Views;

use App\Http\Controllers\Controller;
use App\Models\ExternalDeliveryOrder;

class PrintExternalDeliveryController extends Controller
{
    public function __invoke($uuid)
    {
        $edo = ExternalDeliveryOrder::query()
            ->with(['orderItems.product', 'customer', 'address.address'])
            ->where('uuid', $uuid)
            ->first();
        return view('exports.print.external-delivery', ['edo' => $edo]);
    }
}
