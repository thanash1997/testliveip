<?php

namespace App\Http\Controllers\Views;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ViewProductionOrdersListPageController extends Controller
{
    public function __invoke(Request $request)
    {
        return view('production.orders.index');
    }
}
