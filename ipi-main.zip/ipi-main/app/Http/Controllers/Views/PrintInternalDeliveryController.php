<?php

namespace App\Http\Controllers\Views;

use App\Http\Controllers\Controller;
use App\Models\InternalDeliveryOrder;

class PrintInternalDeliveryController extends Controller
{
    public function __invoke($uuid)
    {
        $ido = InternalDeliveryOrder::query()
            ->with(['orderItems.product', 'destination'])
            ->where('uuid', $uuid)
            ->first();
        return view('exports.print.internal-delivery', ['ido' => $ido]);
    }
}
