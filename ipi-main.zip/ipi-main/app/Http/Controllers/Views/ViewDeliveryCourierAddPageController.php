<?php

namespace App\Http\Controllers\Views;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ViewDeliveryCourierAddPageController extends Controller
{
    public function __invoke(Request $request)
    {
        return view('couriers.add');
    }
}
