<?php

namespace App\Http\Controllers\Views;

use App\Http\Controllers\Controller;
use IPI\Core\Order\GetSingleInternalDeliveryOrder;

class ViewWarehouseInternalDeliveryOrderEditPageController extends Controller
{
    public function __invoke(GetSingleInternalDeliveryOrder $getSingleInternalDeliveryOrder, $uuid)
    {
        $internalDeliveryOrder = $getSingleInternalDeliveryOrder->getInternalDeliveryOrder($uuid);

        return view('warehouse.internal-delivery.edit')
            ->with(['internal_delivery_order' => json_encode($internalDeliveryOrder)]);
    }
}
