<?php

namespace App\Http\Controllers\Views;

use App\Http\Controllers\Controller;
use App\Models\User;

class ViewAccountEditPageController extends Controller
{
    public function __invoke($uuid)
    {
        $user = User::query()
            ->with(['department', 'phoneNumber', 'roles'])
            ->where('uuid', $uuid)->first();

        return view('account.edit')->with('user', json_encode($user));
    }
}
