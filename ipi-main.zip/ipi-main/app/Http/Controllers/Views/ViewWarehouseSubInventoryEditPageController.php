<?php

namespace App\Http\Controllers\Views;

use App\Http\Controllers\Controller;
use App\Models\Inventory;
use IPI\Core\Product\GetSingleProduct;

class ViewWarehouseSubInventoryEditPageController extends Controller
{
    public function __invoke(GetSingleProduct $getSingleProduct, $uuid)
    {
        $inventory = Inventory::query()->where('slug', Inventory::PRODUCTION)->first(['id']);
        $product = $getSingleProduct->getProduct($uuid, $inventory->id);

        return view('warehouse.sub-inventory.edit', ['product' => json_encode($product)]);
    }
}
