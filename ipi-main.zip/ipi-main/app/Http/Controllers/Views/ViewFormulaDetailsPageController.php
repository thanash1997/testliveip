<?php

namespace App\Http\Controllers\Views;

use App\Http\Controllers\Controller;
use IPI\Core\Product\GetSingleFormula;

class ViewFormulaDetailsPageController extends Controller
{
    public function __invoke(GetSingleFormula $getSingleFormula, $uuid)
    {
        $formula = $getSingleFormula->getFormula($uuid);

        return view('formula.details')->with('formula', json_encode($formula));
    }
}
