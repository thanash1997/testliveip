<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\ResetPasswordRequest;
use Illuminate\Support\Facades\Hash;

class ResetPasswordController extends Controller
{
    public function __invoke(ResetPasswordRequest $request)
    {
        $validatedData = $request->validated();
        $user = auth()->user();
        $user->update([
            'password' => Hash::make($validatedData['password'])
        ]);

        return response()->json([], 204);
    }
}
