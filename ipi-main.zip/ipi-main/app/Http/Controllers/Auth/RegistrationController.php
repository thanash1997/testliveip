<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\RegistrationRequest;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use IPI\Core\Auth\RegistrationService;

class RegistrationController extends Controller
{
    public function __invoke(RegistrationRequest $request): JsonResponse
    {
        $user = DB::transaction(function () use ($request) {
            $service = new RegistrationService($request->validated());

            return $service->handle();
        });

        return response()->json([
            'data' => $user
        ], 201);
    }
}
