<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use IPI\Core\Auth\LoginService;

class LoginController extends Controller
{
    public function __invoke(LoginRequest $request): JsonResponse
    {
        $user = DB::transaction(function () use ($request) {
            $service = new LoginService($request->validated());

            return $service->handle();
        });

        return response()->json(['data' => $user]);
    }
}
