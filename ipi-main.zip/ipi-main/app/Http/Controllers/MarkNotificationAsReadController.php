<?php

namespace App\Http\Controllers;

use App\Events\NewNotificationSent;
use App\Models\Notification;
use Illuminate\Http\JsonResponse;

class MarkNotificationAsReadController extends Controller
{
    public function __invoke(Notification $notification): JsonResponse
    {
        $notification->update(['read_at' => now()]);
        $moduleIds = $notification->modules()->pluck('modules.id');

        foreach ($moduleIds as $moduleId) {
            NewNotificationSent::dispatch($moduleId);
        }

        return response()->json([], 204);
    }
}
