<?php

namespace App\Http\Controllers\Product;

use App\Http\Controllers\Controller;
use App\Http\Requests\GetFormulasRequest;
use App\Http\Requests\Product\CreateFormulaRequest;
use App\Http\Requests\Product\UpdateFormulaRequest;
use Illuminate\Http\JsonResponse;
use IPI\Core\Product\FormulaCreator;
use IPI\Core\Product\GetFormulas;
use IPI\Core\Product\UpdateSingleFormula;

class FormulasController extends Controller
{
    public function index(GetFormulas $getFormulas, GetFormulasRequest $request): JsonResponse
    {
        [$formulas, $meta] = $getFormulas->getFormulas($request->toDTO());

        return response()->json(array_merge($meta, [
            'data' => $formulas
        ]));
    }

    public function store(FormulaCreator $formulaCreator, CreateFormulaRequest $request)
    {
        $formula = $formulaCreator->createFormula($request->toDTO());

        return response()->json([
            'data' => $formula
        ], 201);
    }

    public function show($id)
    {
        //
    }

    public function update(UpdateSingleFormula $updateSingleFormula, UpdateFormulaRequest $request, $uuid): JsonResponse
    {
        $formula = $updateSingleFormula->updateFormula($request->toDTO(), $uuid);

        return response()->json([
            'data' => $formula
        ]);
    }

    public function destroy($id)
    {
        //
    }
}
