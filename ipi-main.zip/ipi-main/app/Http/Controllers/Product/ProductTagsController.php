<?php

namespace App\Http\Controllers\Product;

use App\Http\Controllers\Controller;
use App\Http\Requests\Product\GetProductTagsRequest;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use IPI\Core\Product\GetProductTags;

class ProductTagsController extends Controller
{
    public function index(GetProductTags $getProductTags, GetProductTagsRequest $request): JsonResponse
    {
        [$productTags, $meta] = $getProductTags->getProductTags($request->toDTO());

        return response()->json(array_merge($meta, [
            'data' => $productTags
        ]));
    }

    public function store(Request $request)
    {
        //
    }

    public function show($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }
}
