<?php

namespace App\Http\Controllers\Product;

use App\Http\Controllers\Controller;
use App\Http\Requests\Product\CreateFormulaTypeRequest;
use App\Http\Requests\Product\GetFormulaTypesRequest;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use IPI\Core\Product\FormulaTypeCreator;
use IPI\Core\Product\GetFormulaTypes;

class FormulaTypesController extends Controller
{
    public function index(GetFormulaTypes $getFormulaTypes, GetFormulaTypesRequest $request): JsonResponse
    {
        [$formulaTypes, $meta] = $getFormulaTypes->getFormulaTypes($request->toDTO());

        return response()->json(array_merge($meta, [
            'data' => $formulaTypes
        ]));
    }

    public function store(FormulaTypeCreator $formulaTypeCreator, CreateFormulaTypeRequest $request): JsonResponse
    {
        $formulaType = $formulaTypeCreator->execute($request->toDTO());

        return response()->json([
            'data' => $formulaType
        ], 201);
    }

    public function show($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }
}
