<?php

namespace App\Http\Controllers\Product;

use App\Http\Controllers\Controller;
use App\Http\Requests\Product\CreateProcurementRequest;
use App\Http\Requests\Product\DeleteProcurementRequest;
use App\Http\Requests\Product\GetProcurementsRequest;
use App\Http\Requests\Product\UpdateProcurementRequest;
use Illuminate\Http\JsonResponse;
use IPI\Core\Product\DeleteProcurements;
use IPI\Core\Product\GetProcurements;
use IPI\Core\Product\GetSingleProcurement;
use IPI\Core\Product\ProcurementCreator;
use IPI\Core\Product\UpdateSingleProcurement;

class ProcurementController extends Controller
{
    public function index(GetProcurements $getProcurements, GetProcurementsRequest $request): JsonResponse
    {
        [$procurements, $meta] = $getProcurements->getProcurements($request->toDTO());

        return response()->json(
            array_merge($meta, [
                'data' => $procurements,
            ])
        );
    }

    public function store(ProcurementCreator $procurementCreator, CreateProcurementRequest $request): JsonResponse
    {
        $procurement = $procurementCreator->createProcurement($request->toDTO());

        return response()->json([
            'data' => $procurement,
        ], 201);
    }

    public function show(GetSingleProcurement $getSingleProcurement, $uuid): JsonResponse
    {
        $procurement = $getSingleProcurement->getProcurement($uuid);

        return response()->json([
            'data' => $procurement,
        ]);
    }

    public function update(
        UpdateSingleProcurement $updateSingleProcurement,
        UpdateProcurementRequest $request,
        $uuid
    ): JsonResponse {
        $procurement = $updateSingleProcurement->updateProcurement($request->toDTO(), $uuid);

        return response()->json([
            'data' => $procurement,
        ]);
    }

    public function destroy(DeleteProcurementRequest $request, DeleteProcurements $deleteProcurements): JsonResponse
    {
        [$payload, $code] = $deleteProcurements->deleteProcurements($request->toDTO());

        return response()->json($payload, $code);
    }
}
