<?php

namespace App\Http\Controllers\Product;

use App\Http\Controllers\Controller;
use App\Http\Requests\Product\CreateProductRequest;
use App\Http\Requests\Product\DeleteProductsRequest;
use App\Http\Requests\Product\GetProductsRequest;
use App\Http\Requests\Product\UpdateProductRequest;
use App\Models\Formula;
use App\Models\IngredientListItem;
use App\Models\Inventory;
use App\Models\Product;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use IPI\Core\Product\GetProducts;
use IPI\Core\Product\GetSingleProduct;
use IPI\Core\Product\ProductCreator;
use IPI\Core\Product\UpdateSingleProduct;

class ProductsController extends Controller
{
    public function index(GetProducts $getProducts, GetProductsRequest $request, $inventoryId): JsonResponse
    {
        [$products, $meta] = $getProducts->getProducts($request->toDTO(), $inventoryId);

        return response()->json(
            array_merge($meta, [
                'data' => $products,
            ])
        );
    }

    public function store(ProductCreator $productCreator, CreateProductRequest $request, $inventoryId): JsonResponse
    {
        $inventory = Inventory::query()->find($inventoryId);
        $isWarehouse = $inventory->slug === Inventory::WAREHOUSE;
        $product = $productCreator->createProduct($request->toDTO(), $isWarehouse, !$isWarehouse);

        return response()->json([
            'data' => $product,
        ], 201);
    }

    public function show(GetSingleProduct $getSingleProduct, $inventoryId, $uuid): JsonResponse
    {
        $product = $getSingleProduct->getProduct($uuid, $inventoryId);

        return response()->json([
            'data' => $product,
        ]);
    }

    public function update(
        UpdateSingleProduct $updateSingleProduct,
        UpdateProductRequest $request,
        $inventoryId,
        $uuid
    ): JsonResponse {
        $product = $updateSingleProduct->updateProduct($request->toDTO(), $uuid, $inventoryId);

        return response()->json([
            'data' => $product,
        ]);
    }

    public function destroy(DeleteProductsRequest $request): JsonResponse
    {
        $deleteRequest = $request->toDTO();
        $errors = [];
        $products = Product::query()->whereIn('uuid', $deleteRequest->ids)->get();
        $productIds = $products->pluck('id');

        foreach ($productIds as $key => $id) {
            $queryResult = DB::select(
                'SELECT NOT EXISTS(SELECT * FROM order_items WHERE product_id = ?) AND NOT EXISTS(SELECT * FROM product_requisition_items WHERE product_id = ?) AND NOT EXISTS(SELECT * FROM internal_delivery_items WHERE product_id = ?) AND NOT EXISTS(SELECT * FROM external_delivery_items WHERE product_id = ?) AS not_in_use',
                [
                    $id,
                    $id,
                    $id,
                    $id,
                ]
            );
            $notIsUse = $queryResult[0]->not_in_use === 1;

            if ($notIsUse === false) {
                $productCode = $products[$key]->product_code;
                $errors[] = "Product {$productCode} is currently being used in other resources";
            }
        }

        if (!empty($errors)) {
            return response()->json([
                'errors' => $errors,
            ], 422);
        }

        foreach ($productIds as $productId) {
            $product = Product::query()->where('id', $productId)->first();

            if ($product->type === \IPI\Core\Entities\Product::TYPE_MATERIAL) {
                $product->delete();
            } else {
                $product->inventories()->update([
                    'quantity' => 0,
                ]);
            }
        }

        return response()->json([], 204);
    }
}
