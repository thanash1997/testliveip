<?php

namespace App\Http\Controllers\Product;

use App\Exceptions\InsufficientInventoryQuantity;
use App\Http\Controllers\Controller;
use App\Models\Notification;
use App\Models\ProductRequisition;
use Illuminate\Http\JsonResponse;
use IPI\Core\Order\GenerateInternalDeliveryOrder;
use IPI\Core\Product\GetSingleProductRequisition;

class ApproveProductRequisitionController extends Controller
{
    private GenerateInternalDeliveryOrder $generateInternalDeliveryOrder;

    public function __construct(GenerateInternalDeliveryOrder $generateInternalDeliveryOrder)
    {
        $this->generateInternalDeliveryOrder = $generateInternalDeliveryOrder;
    }

    /**
     * @param GetSingleProductRequisition $getSingleProductRequisition
     * @param $uuid
     * @return JsonResponse
     *
     * @throws InsufficientInventoryQuantity
     */
    public function __invoke(GetSingleProductRequisition $getSingleProductRequisition, $uuid): JsonResponse
    {
        $productRequisition = $getSingleProductRequisition->getProductRequisition($uuid);
        $this->generateInternalDeliveryOrder->generate($productRequisition);

        ProductRequisition::query()->where('uuid', $uuid)
            ->update([
                'approved_at' => now()
            ]);

        Notification::query()->where('id', request()->get('notification_id'))
            ->update([
                'read_at' => now(),
                'action_taken_at' => now(),
            ]);

        return response()->json();
    }
}
