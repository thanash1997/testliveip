<?php

namespace App\Http\Controllers\Product;

use App\Http\Controllers\Controller;
use App\Http\Requests\Product\GetProductRequisitionsRequest;
use App\Http\Requests\Product\UpdateProductRequisitionRequest;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use IPI\Core\Product\GetProductRequisitions;
use IPI\Core\Product\UpdateSingleProductRequisition;
use App\Exceptions\InsufficientInventoryQuantity;

class ProductRequisitionsController extends Controller
{
    public function index(GetProductRequisitions $getProductRequisitions, GetProductRequisitionsRequest $request): JsonResponse
    {
        [$productRequisitions, $meta] = $getProductRequisitions->getProductRequisitions($request->toDTO());

        return response()->json(array_merge($meta, [
            'data' => $productRequisitions
        ]));
    }

    public function store(Request $request)
    {
        //
    }

    public function show(string $uuid)
    {
        //
    }

    /**
     * @param UpdateSingleProductRequisition $updateSingleProductRequisition
     * @param UpdateProductRequisitionRequest $request
     * @param string $uuid
     *
     * @return JsonResponse
     * @throws InsufficientInventoryQuantity
     */
    public function update(UpdateSingleProductRequisition $updateSingleProductRequisition, UpdateProductRequisitionRequest $request, string $uuid): JsonResponse
    {
        $productRequisition = $updateSingleProductRequisition->updateProductRequisition($request->toDTO(), $uuid);

        return response()->json([
            'data' => $productRequisition
        ]);
    }

    public function destroy($id)
    {
        //
    }
}
