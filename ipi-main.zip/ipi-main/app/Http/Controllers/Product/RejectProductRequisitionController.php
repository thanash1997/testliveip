<?php

namespace App\Http\Controllers\Product;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use App\Models\ProductRequisition;
use Illuminate\Http\JsonResponse;

class RejectProductRequisitionController extends Controller
{
    // TODO: Refactor controller
    public function __invoke($uuid): JsonResponse
    {
        ProductRequisition::query()->where('uuid', $uuid)
            ->update([
                'rejected_at' => now()
            ]);

        Notification::query()->where('id', request()->get('notification_id'))
            ->update([
                'read_at' => now(),
                'action_taken_at' => now(),
            ]);

        return response()->json();
    }
}
