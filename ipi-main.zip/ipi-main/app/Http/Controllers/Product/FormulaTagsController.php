<?php

namespace App\Http\Controllers\Product;

use App\Http\Controllers\Controller;
use App\Http\Requests\Product\GetFormulaTagsRequest;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use IPI\Core\Product\GetFormulaTags;

class FormulaTagsController extends Controller
{
    public function index(GetFormulaTags $getFormulaTags, GetFormulaTagsRequest $request): JsonResponse
    {
        [$formulaTags, $meta] = $getFormulaTags->getFormulaTags($request->toDTO());

        return response()->json(array_merge($meta, [
            'data' => $formulaTags
        ]));
    }

    public function store(Request $request)
    {
        //
    }

    public function show($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }
}
