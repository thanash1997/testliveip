<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Http\Requests\CreateUserRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use IPI\Core\General\PhoneNumberCreator;
use IPI\Core\User\UserCreator;

//TODO: REFACTOR, MESSY CODE
class UsersController extends Controller
{
    public function index(Request $request)
    {
        return User::query()
            ->with(['roles', 'department'])
            ->where('can_login', true)
            ->when($request->get('search_query'), function ($query, $searchQuery) {
                return $query->where(function ($query) use ($searchQuery) {
                    return $query->where('name', 'LIKE', "%$searchQuery%")
                        ->orWhere('email', 'LIKE', "%$searchQuery%");
                });
            })
            ->when($request->get('sort_order'), function ($query, $sortOrder) {
                $query->orderBy('id', $sortOrder);
            })
            ->when($request->get('date_range'), function ($query, $dateRange) {
                $startDate = Carbon::parse($dateRange[0])->startOfDay();
                $endDate = Carbon::parse($dateRange[1])->endOfDay();

                if ($startDate !== null) {
                    $query->whereBetween('created_at', [
                        $startDate,
                        $endDate,
                    ]);
                }
            })
            ->paginate(request()->get('per_page') ?? 10);
    }

    public function create(CreateUserRequest $request)
    {
        $validatedRequest = $request->validated();

        $userCreator = new UserCreator();
        $phoneNumberCreator = new PhoneNumberCreator();

        $user = $userCreator->storeUser([
            'name' => $validatedRequest['name'],
            'username' => $validatedRequest['username'],
            'email' => $validatedRequest['email'],
            'password' => $validatedRequest['password'],
        ], true);

        $phoneNumber = $phoneNumberCreator->storePhoneNumber(
            $validatedRequest['phone_dialing_code_id'],
            $validatedRequest['phone_number']
        );
        $user->phoneNumber()->associate($phoneNumber);
        $user->department()->associate($validatedRequest['department_id']);
        $user->save();

        $user->assignRole($validatedRequest['role_id']);

        return response()->json([
            'data' => $user,
        ], 201);
    }

    public function update($uuid, UpdateUserRequest $request)
    {
        $validatedRequest = $request->validated();
        $user = User::query()->where('uuid', $uuid)->first();
        $entitiesToUnset = [
            'department_id',
            'role_id',
            'phone_dialing_code_id',
            'phone_number',
        ];
        $departmentId = $validatedRequest['department_id'] ?? null;
        $roleId = $validatedRequest['role_id'] ?? null;
        $phoneDialingCodeId = $validatedRequest['phone_dialing_code_id'] ?? null;
        $phoneNumber = $validatedRequest['phone_number'] ?? null;

        foreach ($entitiesToUnset as $entity) {
            unset($validatedRequest[$entity]);
        }

        $user->update($validatedRequest);

        if ($phoneNumber) {
            $phoneNumberCreator = new PhoneNumberCreator();
            $newPhoneNumber = $phoneNumberCreator->storePhoneNumber($phoneDialingCodeId, $phoneNumber);

            $user->phoneNumber()->associate($newPhoneNumber);
        }

        if ($departmentId) {
            $user->department()->associate($departmentId);
        }

        if ($roleId) {
            $user->syncRoles([$roleId]);
        }

        $user->save();

        return response()->json([
            'data' => $user,
        ], 201);
    }
}
