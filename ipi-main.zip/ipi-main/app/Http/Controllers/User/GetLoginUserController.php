<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\User;

class GetLoginUserController extends Controller
{
    public function __invoke()
    {
        $user = auth()->user();

        return response()->json([
            'data' => User::query()->with(['department.modules', 'roles'])->find($user->id)
        ]);
    }
}
